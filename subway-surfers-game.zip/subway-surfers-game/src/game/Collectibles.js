// Collectibles system for the game

class CollectibleManager {
    constructor(scene) {
        this.scene = scene;
        this.collectibles = [];
        this.activeCollectibles = new Map();
        this.collectibleTypes = {
            coin: this.createCoin,
            powerup: this.createPowerup,
            gem: this.createGem,
            boost: this.createBoost,
            key: this.createKey
        };
        
        // Power-up effects
        this.activeEffects = new Map();
        this.effectDurations = {
            magnet: 10000,
            jetpack: 8000,
            shield: 12000,
            boost: 5000,
            invincibility: 15000
        };
        
        this.pool = {
            coin: [],
            powerup: [],
            gem: [],
            boost: [],
            key: []
        };
        
        this.init();
    }

    /**
     * Initialize collectible manager
     */
    init() {
        DebugUtils.log('Collectible manager initialized');
    }

    /**
     * Create collectible
     */
    createCollectible(type, position, options = {}) {
        const createFunction = this.collectibleTypes[type];
        if (!createFunction) {
            console.warn(`Unknown collectible type: ${type}`);
            return null;
        }
        
        // Check object pool first
        if (this.pool[type].length > 0 && !options.forceCreate) {
            const collectible = this.pool[type].pop();
            collectible.mesh.position.copy(position);
            collectible.isActive = true;
            collectible.position.copy(position);
            
            // Reset material opacity
            if (collectible.mesh.material) {
                collectible.mesh.material.opacity = 1;
            }
            
            if (!collectible.mesh.parent) {
                this.scene.add(collectible.mesh);
            }
            
            this.collectibles.push(collectible);
            this.activeCollectibles.set(collectible.id, collectible);
            
            return collectible;
        }
        
        const collectible = createFunction.call(this, position, options);
        if (collectible) {
            this.collectibles.push(collectible);
            this.activeCollectibles.set(collectible.id, collectible);
            
            // Add to scene
            this.scene.add(collectible.mesh);
            
            DebugUtils.log(`Created ${type} collectible at`, position);
        }
        
        return collectible;
    }

    /**
     * Create coin collectible
     */
    createCoin(position, options = {}) {
        const radius = options.radius || 0.3;
        const geometry = new THREE.TorusGeometry(radius, 0.1, 8, 16);
        const material = new THREE.MeshLambertMaterial({
            color: options.color || 0xffd700,
            emissive: 0xffd700,
            emissiveIntensity: 0.2
        });
        
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.copy(position);
        mesh.castShadow = true;
        
        const collectible = {
            id: `coin_${Date.now()}_${Math.random()}`,
            type: 'coin',
            mesh: mesh,
            position: position.clone(),
            isActive: true,
            value: options.value || 10,
            animation: null,
            collected: false
        };
        
        // Add spinning animation
        this.addCoinAnimation(collectible);
        
        return collectible;
    }

    /**
     * Create power-up collectible
     */
    createPowerup(position, options = {}) {
        const powerupType = options.powerupType || Random.pick(['magnet', 'jetpack', 'shield']);
        let geometry, material, color;
        
        switch (powerupType) {
            case 'magnet':
                geometry = new THREE.SphereGeometry(0.4);
                color = 0xff6b35;
                break;
            case 'jetpack':
                geometry = new THREE.ConeGeometry(0.3, 0.8);
                color = 0x9b59b6;
                break;
            case 'shield':
                geometry = new THREE.OctahedronGeometry(0.4);
                color = 0x3498db;
                break;
            case 'speed':
                geometry = new THREE.TetrahedronGeometry(0.35);
                color = 0x2ecc71;
                break;
            case 'multiplier':
                geometry = new THREE.DodecahedronGeometry(0.35);
                color = 0xf39c12;
                break;
        }
        
        material = new THREE.MeshLambertMaterial({
            color: color,
            emissive: color,
            emissiveIntensity: 0.3
        });
        
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.copy(position);
        mesh.castShadow = true;
        
        const collectible = {
            id: `powerup_${Date.now()}_${Math.random()}`,
            type: 'powerup',
            powerupType: powerupType,
            mesh: mesh,
            position: position.clone(),
            isActive: true,
            animation: null,
            collected: false
        };
        
        // Add floating animation
        this.addPowerupAnimation(collectible);
        
        return collectible;
    }

    /**
     * Create gem collectible
     */
    createGem(position, options = {}) {
        const geometry = new THREE.OctahedronGeometry(0.3);
        const material = new THREE.MeshLambertMaterial({
            color: options.color || Random.pick([0xe74c3c, 0x3498db, 0x2ecc71, 0xf39c12]),
            transparent: true,
            opacity: 0.9
        });
        
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.copy(position);
        mesh.castShadow = true;
        
        const collectible = {
            id: `gem_${Date.now()}_${Math.random()}`,
            type: 'gem',
            mesh: mesh,
            position: position.clone(),
            isActive: true,
            value: options.value || 50,
            animation: null,
            collected: false
        };
        
        // Add rotating animation
        this.addGemAnimation(collectible);
        
        return collectible;
    }

    /**
     * Create boost collectible
     */
    createBoost(position, options = {}) {
        const geometry = new THREE.CylinderGeometry(0.2, 0.2, 0.8);
        const material = new THREE.MeshLambertMaterial({
            color: 0x00ff00,
            emissive: 0x00ff00,
            emissiveIntensity: 0.5
        });
        
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.copy(position);
        mesh.castShadow = true;
        
        const collectible = {
            id: `boost_${Date.now()}_${Math.random()}`,
            type: 'boost',
            mesh: mesh,
            position: position.clone(),
            isActive: true,
            duration: options.duration || 5000,
            animation: null,
            collected: false
        };
        
        // Add pulsing animation
        this.addBoostAnimation(collectible);
        
        return collectible;
    }

    /**
     * Create key collectible
     */
    createKey(position, options = {}) {
        // Create key shape
        const group = new THREE.Group();
        
        // Key ring
        const ringGeometry = new THREE.TorusGeometry(0.2, 0.05, 8, 16);
        const ringMaterial = new THREE.MeshLambertMaterial({ color: 0xffff00 });
        const ring = new THREE.Mesh(ringGeometry, ringMaterial);
        group.add(ring);
        
        // Key shaft
        const shaftGeometry = new THREE.CylinderGeometry(0.05, 0.05, 0.6);
        const shaftMaterial = new THREE.MeshLambertMaterial({ color: 0xffff00 });
        const shaft = new THREE.Mesh(shaftGeometry, shaftMaterial);
        shaft.position.y = -0.4;
        group.add(shaft);
        
        // Key teeth
        const toothGeometry = new THREE.BoxGeometry(0.1, 0.2, 0.05);
        const tooth1 = new THREE.Mesh(toothGeometry, shaftMaterial);
        tooth1.position.set(0, -0.6, 0.025);
        group.add(tooth1);
        
        const tooth2 = new THREE.Mesh(toothGeometry, shaftMaterial);
        tooth2.position.set(0, -0.7, 0.025);
        group.add(tooth2);
        
        group.position.copy(position);
        
        const collectible = {
            id: `key_${Date.now()}_${Math.random()}`,
            type: 'key',
            mesh: group,
            position: position.clone(),
            isActive: true,
            value: options.value || 100,
            animation: null,
            collected: false
        };
        
        // Add key animation
        this.addKeyAnimation(collectible);
        
        return collectible;
    }

    /**
     * Add coin animation
     */
    addCoinAnimation(collectible) {
        const animateCoin = () => {
            if (collectible.isActive && collectible.mesh.parent) {
                collectible.mesh.rotation.y += 0.1;
                collectible.mesh.position.y = collectible.position.y + Math.sin(Date.now() * 0.003) * 0.2;
                requestAnimationFrame(animateCoin);
            }
        };
        animateCoin();
    }

    /**
     * Add power-up animation
     */
    addPowerupAnimation(collectible) {
        const animatePowerup = () => {
            if (collectible.isActive && collectible.mesh.parent) {
                collectible.mesh.rotation.y += 0.05;
                collectible.mesh.position.y = collectible.position.y + Math.sin(Date.now() * 0.004) * 0.3;
                
                // Pulsing glow effect
                const intensity = 0.2 + Math.sin(Date.now() * 0.005) * 0.2;
                if (collectible.mesh.material.emissiveIntensity !== undefined) {
                    collectible.mesh.material.emissiveIntensity = intensity;
                }
                
                requestAnimationFrame(animatePowerup);
            }
        };
        animatePowerup();
    }

    /**
     * Add gem animation
     */
    addGemAnimation(collectible) {
        const animateGem = () => {
            if (collectible.isActive && collectible.mesh.parent) {
                collectible.mesh.rotation.x += 0.02;
                collectible.mesh.rotation.y += 0.03;
                collectible.mesh.position.y = collectible.position.y + Math.sin(Date.now() * 0.002) * 0.15;
                
                // Color cycling effect
                if (collectible.mesh.material.color) {
                    const hue = (Date.now() * 0.001) % 1;
                    collectible.mesh.material.color.setHSL(hue, 0.8, 0.6);
                }
                
                requestAnimationFrame(animateGem);
            }
        };
        animateGem();
    }

    /**
     * Add boost animation
     */
    addBoostAnimation(collectible) {
        const animateBoost = () => {
            if (collectible.isActive && collectible.mesh.parent) {
                collectible.mesh.rotation.y += 0.15;
                collectible.mesh.position.y = collectible.position.y + Math.sin(Date.now() * 0.006) * 0.25;
                
                // Pulsing effect
                const scale = 1 + Math.sin(Date.now() * 0.008) * 0.2;
                collectible.mesh.scale.set(scale, scale, scale);
                
                requestAnimationFrame(animateBoost);
            }
        };
        animateBoost();
    }

    /**
     * Add key animation
     */
    addKeyAnimation(collectible) {
        const animateKey = () => {
            if (collectible.isActive && collectible.mesh.parent) {
                collectible.mesh.rotation.z += 0.03;
                collectible.mesh.position.y = collectible.position.y + Math.sin(Date.now() * 0.003) * 0.1;
                
                // Glow effect
                if (collectible.mesh.material && collectible.mesh.material.emissiveIntensity !== undefined) {
                    const intensity = 0.3 + Math.sin(Date.now() * 0.007) * 0.2;
                    collectible.mesh.material.emissiveIntensity = intensity;
                }
                
                requestAnimationFrame(animateKey);
            }
        };
        animateKey();
    }

    /**
     * Update collectibles
     */
    update(deltaTime) {
        const player = window.game?.player;
        if (!player) return;
        
        const playerPos = player.group.position;
        const playerSpeed = player.speed;
        
        // Update all active collectibles
        this.collectibles.forEach(collectible => {
            if (!collectible.isActive) return;
            
            // Check magnet effect
            if (this.activeEffects.has('magnet') && collectible.type === 'coin') {
                this.applyMagnetEffect(collectible, playerPos);
            }
            
            // Check collection
            const distance = Vector3Utils.distance(playerPos, collectible.mesh.position);
            const collectionRadius = this.getCollectionRadius(collectible, player);
            
            if (distance < collectionRadius) {
                this.collect(collectible, player);
            }
            
            // Remove collectibles that are too far behind
            const removeThreshold = playerPos.z - 50;
            if (collectible.position.z < removeThreshold) {
                this.removeCollectible(collectible);
            }
        });
        
        // Update active effects
        this.updateEffects(deltaTime);
    }

    /**
     * Get collection radius for collectible
     */
    getCollectionRadius(collectible, player) {
        let baseRadius = 1;
        
        // Magnet effect increases collection radius
        if (this.activeEffects.has('magnet')) {
            baseRadius *= 3;
        }
        
        // Jetpack effect creates attraction field
        if (this.activeEffects.has('jetpack') && collectible.type !== 'powerup') {
            baseRadius *= 2;
        }
        
        // Speed boost might affect collection
        if (this.activeEffects.has('boost') && collectible.type === 'coin') {
            baseRadius *= 1.5;
        }
        
        return baseRadius;
    }

    /**
     * Apply magnet effect to coin
     */
    applyMagnetEffect(collectible, playerPos) {
        const distance = Vector3Utils.distance(playerPos, collectible.mesh.position);
        
        if (distance < 10) { // Magnet range
            const direction = new THREE.Vector3()
                .subVectors(playerPos, collectible.mesh.position)
                .normalize();
            
            const magnetStrength = 5 * (10 - distance) / 10; // Stronger when closer
            
            collectible.mesh.position.add(direction.multiplyScalar(magnetStrength * 0.016));
        }
    }

    /**
     * Collect collectible
     */
    collect(collectible, player) {
        if (collectible.collected) return;
        
        collectible.collected = true;
        collectible.isActive = false;
        
        DebugUtils.log(`Collected ${collectible.type}`, collectible);
        
        // Handle different collectible types
        switch (collectible.type) {
            case 'coin':
                this.collectCoin(collectible, player);
                break;
            case 'powerup':
                this.collectPowerup(collectible, player);
                break;
            case 'gem':
                this.collectGem(collectible, player);
                break;
            case 'boost':
                this.collectBoost(collectible, player);
                break;
            case 'key':
                this.collectKey(collectible, player);
                break;
        }
        
        // Create collection effect
        this.createCollectionEffect(collectible);
        
        // Remove collectible after effect
        setTimeout(() => {
            this.removeCollectible(collectible);
        }, 500);
    }

    /**
     * Collect coin
     */
    collectCoin(collectible, player) {
        const baseValue = collectible.value;
        const multiplier = player.multiplier || 1;
        const finalValue = baseValue * multiplier;
        
        // Add to score
        player.score += finalValue;
        
        // Show score popup
        this.showScorePopup(collectible.mesh.position, `+${finalValue}`);
    }

    /**
     * Collect power-up
     */
    collectPowerup(collectible, player) {
        const powerupType = collectible.powerupType;
        
        // Apply power-up effect
        this.activatePowerup(powerupType, player);
        
        // Show power-up activation
        this.showPowerupActivation(powerupType);
    }

    /**
     * Collect gem
     */
    collectGem(collectible, player) {
        const value = collectible.value;
        player.score += value;
        
        // Gems give bonus multiplier
        player.comboCount += 3;
        player.multiplier = GameUtils.calculateCombo(player.comboCount);
        
        this.showScorePopup(collectible.mesh.position, `+${value} GEM!`);
    }

    /**
     * Collect boost
     */
    collectBoost(collectible, player) {
        this.activatePowerup('boost', player);
        this.showPowerupActivation('BOOST');
    }

    /**
     * Collect key
     */
    collectKey(collectible, player) {
        const value = collectible.value;
        player.score += value;
        
        // Keys unlock special areas or bonus multipliers
        player.keyCount = (player.keyCount || 0) + 1;
        
        this.showScorePopup(collectible.mesh.position, `KEY +${value}`);
    }

    /**
     * Activate power-up
     */
    activatePowerup(powerupType, player) {
        const now = Date.now();
        const duration = this.effectDurations[powerupType] || 5000;
        
        // Store effect
        this.activeEffects.set(powerupType, {
            startTime: now,
            duration: duration,
            player: player
        });
        
        // Apply effect based on type
        switch (powerupType) {
            case 'magnet':
                this.applyMagnetEffect(player, true);
                break;
            case 'jetpack':
                this.applyJetpackEffect(player, true);
                break;
            case 'shield':
                this.applyShieldEffect(player, true);
                break;
            case 'boost':
                this.applyBoostEffect(player, true);
                break;
            case 'invincibility':
                this.applyInvincibilityEffect(player, true);
                break;
        }
        
        DebugUtils.log(`Activated ${powerupType} power-up`);
    }

    /**
     * Apply magnet effect
     */
    applyMagnetEffect(player, activate) {
        if (activate) {
            player.magnetActive = true;
            // Visual effect
            this.createMagnetEffect(player.group.position);
        } else {
            player.magnetActive = false;
        }
    }

    /**
     * Apply jetpack effect
     */
    applyJetpackEffect(player, activate) {
        if (activate) {
            player.jetpackActive = true;
            // Auto-jump enabled
            this.createJetpackEffect(player.group.position);
        } else {
            player.jetpackActive = false;
        }
    }

    /**
     * Apply shield effect
     */
    applyShieldEffect(player, activate) {
        if (activate) {
            player.shieldActive = true;
            this.createShieldEffect(player.group.position);
        } else {
            player.shieldActive = false;
        }
    }

    /**
     * Apply boost effect
     */
    applyBoostEffect(player, activate) {
        if (activate) {
            player.boostActive = true;
            player.speed *= 1.5;
            this.createBoostEffect(player.group.position);
        } else {
            player.boostActive = false;
            player.speed /= 1.5;
        }
    }

    /**
     * Apply invincibility effect
     */
    applyInvincibilityEffect(player, activate) {
        if (activate) {
            player.invincible = true;
            this.createInvincibilityEffect(player.group.position);
        } else {
            player.invincible = false;
        }
    }

    /**
     * Update active effects
     */
    updateEffects(deltaTime) {
        const now = Date.now();
        const effectsToRemove = [];
        
        this.activeEffects.forEach((effect, powerupType) => {
            const elapsed = now - effect.startTime;
            const remaining = effect.duration - elapsed;
            
            if (remaining <= 0) {
                // Effect expired
                this.deactivatePowerup(powerupType, effect.player);
                effectsToRemove.push(powerupType);
            } else {
                // Update effect progress
                this.updateEffectProgress(powerupType, effect, remaining / effect.duration);
            }
        });
        
        // Remove expired effects
        effectsToRemove.forEach(powerupType => {
            this.activeEffects.delete(powerupType);
        });
    }

    /**
     * Deactivate power-up
     */
    deactivatePowerup(powerupType, player) {
        switch (powerupType) {
            case 'magnet':
                this.applyMagnetEffect(player, false);
                break;
            case 'jetpack':
                this.applyJetpackEffect(player, false);
                break;
            case 'shield':
                this.applyShieldEffect(player, false);
                break;
            case 'boost':
                this.applyBoostEffect(player, false);
                break;
            case 'invincibility':
                this.applyInvincibilityEffect(player, false);
                break;
        }
        
        DebugUtils.log(`Deactivated ${powerupType} power-up`);
    }

    /**
     * Update effect progress
     */
    updateEffectProgress(powerupType, effect, progress) {
        // Visual feedback for effect duration
        const player = effect.player;
        if (!player) return;
        
        switch (powerupType) {
            case 'shield':
                // Fade shield visual
                const shieldScale = 1 + progress * 0.5;
                player.group.scale.set(shieldScale, shieldScale, shieldScale);
                break;
            case 'boost':
                // Speed lines effect
                this.createSpeedLines(player.group.position);
                break;
        }
    }

    /**
     * Create collection effect
     */
    createCollectionEffect(collectible) {
        const effectGeometry = new THREE.SphereGeometry(0.5);
        const effectMaterial = new THREE.MeshBasicMaterial({
            color: 0x00ff00,
            transparent: true,
            opacity: 0.8
        });
        
        const effect = new THREE.Mesh(effectGeometry, effectMaterial);
        effect.position.copy(collectible.mesh.position);
        
        this.scene.add(effect);
        
        // Animate effect
        const animateEffect = () => {
            effect.scale.multiplyScalar(1.1);
            effect.material.opacity -= 0.02;
            
            if (effect.material.opacity > 0) {
                requestAnimationFrame(animateEffect);
            } else {
                if (effect.parent) {
                    effect.parent.remove(effect);
                }
            }
        };
        
        animateEffect();
    }

    /**
     * Show score popup
     */
    showScorePopup(position, text) {
        const popup = document.createElement('div');
        popup.textContent = text;
        popup.style.position = 'absolute';
        popup.style.left = (position.x + window.innerWidth / 2) + 'px';
        popup.style.top = (window.innerHeight / 2 - position.y * 50) + 'px';
        popup.style.color = '#ffd700';
        popup.style.fontSize = '24px';
        popup.style.fontWeight = 'bold';
        popup.style.pointerEvents = 'none';
        popup.style.zIndex = '1000';
        popup.style.animation = 'scoreIncrease 0.8s ease-out';
        
        document.body.appendChild(popup);
        
        setTimeout(() => {
            if (popup.parentNode) {
                popup.parentNode.removeChild(popup);
            }
        }, 800);
    }

    /**
     * Show power-up activation
     */
    showPowerupActivation(powerupType) {
        const activation = document.createElement('div');
        activation.textContent = `${powerupType.toUpperCase()}!`;
        activation.style.position = 'absolute';
        activation.style.top = '20%';
        activation.style.left = '50%';
        activation.style.transform = 'translateX(-50%)';
        activation.style.color = '#ff6b35';
        activation.style.fontSize = '32px';
        activation.style.fontWeight = 'bold';
        activation.style.pointerEvents = 'none';
        activation.style.zIndex = '1000';
        activation.style.animation = 'comboDisplay 1.5s ease-out forwards';
        
        document.body.appendChild(activation);
        
        setTimeout(() => {
            if (activation.parentNode) {
                activation.parentNode.removeChild(activation);
            }
        }, 1500);
    }

    /**
     * Create visual effects for power-ups
     */
    createMagnetEffect(position) {
        // Create magnetic field visualization
        const fieldGeometry = new THREE.RingGeometry(2, 3, 16);
        const fieldMaterial = new THREE.MeshBasicMaterial({
            color: 0xff6b35,
            transparent: true,
            opacity: 0.3
        });
        
        const field = new THREE.Mesh(fieldGeometry, fieldMaterial);
        field.position.copy(position);
        field.rotation.x = Math.PI / 2;
        
        this.scene.add(field);
        
        // Animate field
        const animateField = () => {
            if (this.activeEffects.has('magnet')) {
                field.scale.setScalar(1 + Math.sin(Date.now() * 0.005) * 0.1);
                requestAnimationFrame(animateField);
            } else {
                if (field.parent) {
                    field.parent.remove(field);
                }
            }
        };
        animateField();
    }

    createJetpackEffect(position) {
        // Create jetpack flames
        for (let i = 0; i < 3; i++) {
            const flame = new THREE.Mesh(
                new THREE.ConeGeometry(0.2, 1, 8),
                new THREE.MeshBasicMaterial({ color: 0xff4500, transparent: true, opacity: 0.7 })
            );
            
            flame.position.copy(position);
            flame.position.x += (i - 1) * 0.3;
            flame.position.y -= 1;
            
            this.scene.add(flame);
            
            // Animate flame
            const animateFlame = () => {
                if (this.activeEffects.has('jetpack')) {
                    flame.scale.y = 1 + Math.random() * 0.5;
                    flame.material.opacity = 0.5 + Math.random() * 0.3;
                    requestAnimationFrame(animateFlame);
                } else {
                    if (flame.parent) {
                        flame.parent.remove(flame);
                    }
                }
            };
            animateFlame();
        }
    }

    createShieldEffect(position) {
        // Create protective shield
        const shieldGeometry = new THREE.SphereGeometry(1.2);
        const shieldMaterial = new THREE.MeshBasicMaterial({
            color: 0x3498db,
            transparent: true,
            opacity: 0.2,
            wireframe: true
        });
        
        const shield = new THREE.Mesh(shieldGeometry, shieldMaterial);
        shield.position.copy(position);
        
        this.scene.add(shield);
        
        // Animate shield
        const animateShield = () => {
            if (this.activeEffects.has('shield')) {
                shield.rotation.y += 0.02;
                shield.material.opacity = 0.1 + Math.sin(Date.now() * 0.003) * 0.1;
                requestAnimationFrame(animateShield);
            } else {
                if (shield.parent) {
                    shield.parent.remove(shield);
                }
            }
        };
        animateShield();
    }

    createBoostEffect(position) {
        // Create speed lines
        this.createSpeedLines(position);
    }

    createInvincibilityEffect(position) {
        // Create golden aura
        const auraGeometry = new THREE.SphereGeometry(1.5);
        const auraMaterial = new THREE.MeshBasicMaterial({
            color: 0xffff00,
            transparent: true,
            opacity: 0.3
        });
        
        const aura = new THREE.Mesh(auraGeometry, auraMaterial);
        aura.position.copy(position);
        
        this.scene.add(aura);
        
        // Animate aura
        const animateAura = () => {
            if (this.activeEffects.has('invincibility')) {
                aura.scale.setScalar(1 + Math.sin(Date.now() * 0.004) * 0.1);
                requestAnimationFrame(animateAura);
            } else {
                if (aura.parent) {
                    aura.parent.remove(aura);
                }
            }
        };
        animateAura();
    }

    createSpeedLines(position) {
        // Create speed effect lines
        for (let i = 0; i < 5; i++) {
            const line = new THREE.Mesh(
                new THREE.CylinderGeometry(0.02, 0.02, 3),
                new THREE.MeshBasicMaterial({ color: 0x00ff00 })
            );
            
            line.position.copy(position);
            line.position.x += (Math.random() - 0.5) * 4;
            line.position.y += (Math.random() - 0.5) * 2;
            line.position.z += (Math.random() - 0.5) * 2;
            
            this.scene.add(line);
            
            // Animate line
            const animateLine = () => {
                if (this.activeEffects.has('boost')) {
                    line.position.z -= 2;
                    if (line.position.z < position.z - 10) {
                        line.position.z = position.z + 5;
                    }
                    requestAnimationFrame(animateLine);
                } else {
                    if (line.parent) {
                        line.parent.remove(line);
                    }
                }
            };
            animateLine();
        }
    }

    /**
     * Remove collectible
     */
    removeCollectible(collectible) {
        // Return to pool if possible
        if (this.pool[collectible.type] && this.pool[collectible.type].length < 10) {
            collectible.isActive = false;
            collectible.collected = false;
            collectible.mesh.position.set(0, -10, 0); // Move off-screen
            if (collectible.mesh.parent) {
                collectible.mesh.parent.remove(collectible.mesh);
            }
            this.pool[collectible.type].push(collectible);
        } else {
            // Remove completely
            if (collectible.mesh.parent) {
                collectible.mesh.parent.remove(collectible.mesh);
            }
        }
        
        this.activeCollectibles.delete(collectible.id);
        
        // Remove from main array
        const index = this.collectibles.indexOf(collectible);
        if (index > -1) {
            this.collectibles.splice(index, 1);
        }
    }

    /**
     * Clear all collectibles
     */
    clear() {
        this.collectibles.forEach(collectible => {
            this.removeCollectible(collectible);
        });
        
        this.collectibles = [];
        this.activeCollectibles.clear();
        this.activeEffects.clear();
        
        // Clear pools
        Object.keys(this.pool).forEach(type => {
            this.pool[type] = [];
        });
    }

    /**
     * Create collectible pattern
     */
    createCollectiblePattern(patternType, startPosition, options = {}) {
        const patterns = {
            coinLine: this.createCoinLine,
            coinArc: this.createCoinArc,
            coinSpiral: this.createCoinSpiral,
            powerupTrail: this.createPowerupTrail,
            gemCluster: this.createGemCluster,
            mixedPattern: this.createMixedPattern
        };
        
        const patternFunction = patterns[patternType];
        if (patternFunction) {
            patternFunction.call(this, startPosition, options);
        }
    }

    /**
     * Create coin line pattern
     */
    createCoinLine(startPosition, options = {}) {
        const count = options.count || 10;
        const spacing = options.spacing || 2;
        const lane = options.lane || Random.int(0, 2);
        const x = (lane - 1) * 3;
        
        for (let i = 0; i < count; i++) {
            const position = new THREE.Vector3(
                x,
                startPosition.y + 1.5,
                startPosition.z + i * spacing
            );
            
            this.createCollectible('coin', position, options);
        }
    }

    /**
     * Create coin arc pattern
     */
    createCoinArc(startPosition, options = {}) {
        const points = options.points || 8;
        const radius = options.radius || 3;
        const height = options.height || 2;
        
        for (let i = 0; i < points; i++) {
            const t = (i / (points - 1)) * Math.PI;
            const x = Math.sin(t) * radius;
            const y = Math.cos(t) * height;
            const position = new THREE.Vector3(
                x,
                startPosition.y + y,
                startPosition.z + i * 1.5
            );
            
            this.createCollectible('coin', position, options);
        }
    }

    /**
     * Create coin spiral pattern
     */
    createCoinSpiral(startPosition, options = {}) {
        const turns = options.turns || 3;
        const pointsPerTurn = options.pointsPerTurn || 8;
        const radius = options.radius || 2;
        const height = options.height || 5;
        
        const totalPoints = turns * pointsPerTurn;
        
        for (let i = 0; i < totalPoints; i++) {
            const t = (i / totalPoints) * turns * Math.PI * 2;
            const x = Math.cos(t) * radius;
            const z = Math.sin(t) * radius;
            const y = (i / totalPoints) * height;
            
            const position = new THREE.Vector3(
                x,
                startPosition.y + y,
                startPosition.z + z * 2
            );
            
            this.createCollectible('coin', position, options);
        }
    }

    /**
     * Create power-up trail pattern
     */
    createPowerupTrail(startPosition, options = {}) {
        const count = options.count || 3;
        const spacing = options.spacing || 5;
        
        const types = ['magnet', 'jetpack', 'shield', 'boost', 'multiplier'];
        
        for (let i = 0; i < count; i++) {
            const type = types[i % types.length];
            const position = new THREE.Vector3(
                Random.pick([-3, 0, 3]),
                startPosition.y + 2,
                startPosition.z + i * spacing
            );
            
            this.createCollectible('powerup', position, {
                ...options,
                powerupType: type
            });
        }
    }

    /**
     * Create gem cluster pattern
     */
    createGemCluster(startPosition, options = {}) {
        const clusterSize = options.clusterSize || 5;
        const spacing = options.spacing || 1.5;
        
        for (let row = 0; row < clusterSize; row++) {
            for (let col = 0; col < clusterSize; col++) {
                const x = (col - (clusterSize - 1) / 2) * spacing;
                const z = (row - (clusterSize - 1) / 2) * spacing;
                
                const position = new THREE.Vector3(
                    x,
                    startPosition.y + 1.5,
                    startPosition.z + z
                );
                
                this.createCollectible('gem', position, options);
            }
        }
    }

    /**
     * Create mixed pattern
     */
    createMixedPattern(startPosition, options = {}) {
        const elements = options.elements || 15;
        const spacing = options.spacing || 3;
        
        for (let i = 0; i < elements; i++) {
            const type = Random.pick(['coin', 'gem', 'powerup']);
            const position = new THREE.Vector3(
                Random.pick([-3, 0, 3]),
                startPosition.y + Random.float(1, 3),
                startPosition.z + i * spacing
            );
            
            const collectibleOptions = { ...options };
            if (type === 'powerup') {
                collectibleOptions.powerupType = Random.pick(['magnet', 'jetpack', 'shield']);
            }
            
            this.createCollectible(type, position, collectibleOptions);
        }
    }

    /**
     * Get collectible count by type
     */
    getCollectibleCountByType() {
        const counts = {};
        this.collectibles.forEach(collectible => {
            if (collectible.isActive) {
                const type = collectible.type === 'powerup' ? `powerup_${collectible.powerupType}` : collectible.type;
                counts[type] = (counts[type] || 0) + 1;
            }
        });
        return counts;
    }

    /**
     * Get active effects
     */
    getActiveEffects() {
        return Array.from(this.activeEffects.keys());
    }

    /**
     * Get collectible info
     */
    getInfo() {
        return {
            totalCollectibles: this.collectibles.length,
            activeCollectibles: this.activeCollectibles.size,
            countsByType: this.getCollectibleCountByType(),
            activeEffects: this.getActiveEffects(),
            poolSizes: Object.keys(this.pool).reduce((acc, type) => {
                acc[type] = this.pool[type].length;
                return acc;
            }, {})
        };
    }
}

// Export for use in other modules
window.CollectibleManager = CollectibleManager;