// Player character controller

class Player {
    constructor(scene) {
        this.scene = scene;
        this.group = new THREE.Group();
        this.isRunning = false;
        this.isJumping = false;
        this.isSliding = false;
        this.isDead = false;
        
        // Character properties
        this.speed = 0;
        this.maxSpeed = 12;
        this.acceleration = 0.5;
        this.jumpForce = 8;
        this.slideDuration = 0.6;
        this.laneWidth = 3;
        this.currentLane = 1; // 0: left, 1: center, 2: right
        
        // Character states
        this.state = 'idle'; // idle, running, jumping, sliding, dead
        this.health = 3;
        this.score = 0;
        this.distance = 0;
        this.comboCount = 0;
        this.multiplier = 1;
        
        // Physics
        this.body = null;
        this.velocity = new THREE.Vector3();
        this.isGrounded = true;
        
        // Animation
        this.animationMixer = null;
        this.currentAnimation = null;
        this.animationClock = new THREE.Clock();
        
        // Effects
        this.trailEffect = null;
        this.particleEffects = [];
        
        // Input
        this.inputQueue = [];
        this.inputCooldown = 0;
        this.maxInputCooldown = 0.2;
        
        this.init();
    }

    /**
     * Initialize player character
     */
    init() {
        // Create player model
        this.createCharacterModel();
        
        // Add to scene
        this.scene.add(this.group);
        
        // Setup physics
        this.setupPhysics();
        
        // Setup animation
        this.setupAnimations();
        
        // Setup effects
        this.setupEffects();
        
        DebugUtils.log('Player initialized');
    }

    /**
     * Create 3D character model
     */
    createCharacterModel() {
        // Create character group
        const characterGroup = new THREE.Group();
        
        // Body
        const bodyGeometry = new THREE.BoxGeometry(1, 2, 0.5);
        const bodyMaterial = new THREE.MeshLambertMaterial({ color: 0x4a90e2 });
        const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
        body.position.y = 1;
        characterGroup.add(body);
        
        // Head
        const headGeometry = new THREE.SphereGeometry(0.5);
        const headMaterial = new THREE.MeshLambertMaterial({ color: 0xffdbac });
        const head = new THREE.Mesh(headGeometry, headMaterial);
        head.position.y = 2.5;
        characterGroup.add(head);
        
        // Arms
        const armGeometry = new THREE.BoxGeometry(0.3, 1.5, 0.3);
        const armMaterial = new THREE.MeshLambertMaterial({ color: 0xffdbac });
        
        const leftArm = new THREE.Mesh(armGeometry, armMaterial);
        leftArm.position.set(-0.8, 1.5, 0);
        characterGroup.add(leftArm);
        
        const rightArm = new THREE.Mesh(armGeometry, armMaterial);
        rightArm.position.set(0.8, 1.5, 0);
        characterGroup.add(rightArm);
        
        // Legs
        const legGeometry = new THREE.BoxGeometry(0.4, 1.5, 0.4);
        const legMaterial = new THREE.MeshLambertMaterial({ color: 0x2c3e50 });
        
        const leftLeg = new THREE.Mesh(legGeometry, legMaterial);
        leftLeg.position.set(-0.3, 0.25, 0);
        characterGroup.add(leftLeg);
        
        const rightLeg = new THREE.Mesh(legGeometry, legMaterial);
        rightLeg.position.set(0.3, 0.25, 0);
        characterGroup.add(rightLeg);
        
        // Add accessories
        this.addAccessories(characterGroup);
        
        this.group = characterGroup;
        
        // Set initial position
        this.group.position.set(0, 1, 0);
        
        // Store body parts for animation
        this.bodyParts = {
            body: body,
            head: head,
            leftArm: leftArm,
            rightArm: rightArm,
            leftLeg: leftLeg,
            rightLeg: rightLeg
        };
    }

    /**
     * Add character accessories
     */
    addAccessories(group) {
        // Backpack
        const backpackGeometry = new THREE.BoxGeometry(0.8, 1, 0.3);
        const backpackMaterial = new THREE.MeshLambertMaterial({ color: 0xe74c3c });
        const backpack = new THREE.Mesh(backpackGeometry, backpackMaterial);
        backpack.position.set(0, 1.5, -0.4);
        group.add(backpack);
        
        // Shoes
        const shoeGeometry = new THREE.BoxGeometry(0.5, 0.2, 0.8);
        const shoeMaterial = new THREE.MeshLambertMaterial({ color: 0x2c3e50 });
        
        const leftShoe = new THREE.Mesh(shoeGeometry, shoeMaterial);
        leftShoe.position.set(-0.3, -0.6, 0.2);
        group.add(leftShoe);
        
        const rightShoe = new THREE.Mesh(shoeGeometry, shoeMaterial);
        rightShoe.position.set(0.3, -0.6, 0.2);
        group.add(rightShoe);
    }

    /**
     * Setup physics for player
     */
    setupPhysics() {
        // Create physics body
        this.body = physicsEngine.addBody('player', this.group, {
            mass: 1,
            material: 'player',
            linearDamping: 0.1,
            angularDamping: 0.1,
            position: { x: 0, y: 1, z: 0 }
        });
        
        if (this.body) {
            // Set physics properties
            this.body.fixedRotation = true;
            this.body.updateMassProperties();
        }
    }

    /**
     * Setup character animations
     */
    setupAnimations() {
        // Simple procedural animations
        this.animationStates = {
            idle: this.createIdleAnimation(),
            running: this.createRunningAnimation(),
            jumping: this.createJumpingAnimation(),
            sliding: this.createSlidingAnimation(),
            falling: this.createFallingAnimation(),
            landing: this.createLandingAnimation()
        };
        
        this.setState('idle');
    }

    /**
     * Create idle animation
     */
    createIdleAnimation() {
        return {
            duration: 3,
            loop: true,
            update: (time, deltaTime) => {
                if (this.isDead) return;
                
                // Gentle breathing motion
                const breath = Math.sin(time * 2) * 0.02;
                this.bodyParts.body.position.y = 1 + breath;
                this.bodyParts.head.position.y = 2.5 + breath;
            }
        };
    }

    /**
     * Create running animation
     */
    createRunningAnimation() {
        return {
            duration: 0.6,
            loop: true,
            update: (time, deltaTime) => {
                if (this.isDead) return;
                
                const runCycle = Math.sin(time * 10);
                const legSwing = runCycle * 0.3;
                const armSwing = runCycle * 0.2;
                
                // Leg movements
                this.bodyParts.leftLeg.rotation.x = legSwing;
                this.bodyParts.rightLeg.rotation.x = -legSwing;
                
                // Arm movements
                this.bodyParts.leftArm.rotation.x = -armSwing;
                this.bodyParts.rightArm.rotation.x = armSwing;
                
                // Body bobbing
                const bob = Math.abs(runCycle) * 0.1;
                this.bodyParts.body.position.y = 1 + bob;
                this.bodyParts.head.position.y = 2.5 + bob;
                
                // Forward lean
                this.group.rotation.z = runCycle * 0.05;
            }
        };
    }

    /**
     * Create jumping animation
     */
    createJumpingAnimation() {
        return {
            duration: 0.8,
            loop: false,
            update: (time, deltaTime) => {
                const elapsed = time % 0.8;
                const progress = elapsed / 0.8;
                
                // Parabolic jump arc
                const jumpHeight = Math.sin(progress * Math.PI) * 2;
                this.group.position.y = Math.max(1, jumpHeight);
                
                // Arm positioning
                this.bodyParts.leftArm.rotation.x = -0.5;
                this.bodyParts.rightArm.rotation.x = -0.5;
                
                // Leg positioning
                this.bodyParts.leftLeg.rotation.x = 0.2;
                this.bodyParts.rightLeg.rotation.x = 0.2;
                
                // Rotation
                this.group.rotation.x = -progress * 0.1;
            }
        };
    }

    /**
     * Create sliding animation
     */
    createSlidingAnimation() {
        return {
            duration: 0.6,
            loop: false,
            update: (time, deltaTime) => {
                const elapsed = time % 0.6;
                const progress = elapsed / 0.6;
                
                // Scale down
                const scale = 1 - progress * 0.4;
                this.group.scale.y = scale;
                
                // Position adjustment
                this.group.position.y = 1 * scale;
                
                // Arm positioning
                this.bodyParts.leftArm.rotation.x = -0.3;
                this.bodyParts.rightArm.rotation.x = -0.3;
                
                // Leg positioning
                this.bodyParts.leftLeg.rotation.x = 0.1;
                this.bodyParts.rightLeg.rotation.x = 0.1;
            }
        };
    }

    /**
     * Create falling animation
     */
    createFallingAnimation() {
        return {
            duration: 1.5,
            loop: false,
            update: (time, deltaTime) => {
                const elapsed = time % 1.5;
                const progress = elapsed / 1.5;
                
                // Falling motion
                this.group.position.y = 1 - progress * 5;
                
                // Rotation
                this.group.rotation.z = progress * Math.PI;
                this.group.rotation.x = progress * Math.PI * 0.5;
            }
        };
    }

    /**
     * Create landing animation
     */
    createLandingAnimation() {
        return {
            duration: 0.4,
            loop: false,
            update: (time, deltaTime) => {
                const elapsed = time % 0.4;
                const progress = elapsed / 0.4;
                
                // Bounce effect
                const bounce = Math.sin(progress * Math.PI) * 0.3;
                this.group.position.y = 1 + bounce;
                
                // Scale effect
                const scale = 1 + Math.sin(progress * Math.PI) * 0.1;
                this.group.scale.y = scale;
            }
        };
    }

    /**
     * Setup visual effects
     */
    setupEffects() {
        // Speed trail effect
        this.createSpeedTrail();
        
        // Landing effect
        this.landingParticles = this.createParticleSystem(20, 0x4a90e2);
    }

    /**
     * Create speed trail effect
     */
    createSpeedTrail() {
        // Create trail geometry
        const trailGeometry = new THREE.ConeGeometry(0.1, 2, 8);
        const trailMaterial = new THREE.MeshBasicMaterial({
            color: 0x4a90e2,
            transparent: true,
            opacity: 0.5
        });
        
        this.trailEffect = new THREE.Mesh(trailGeometry, trailMaterial);
        this.trailEffect.rotation.x = Math.PI;
        this.trailEffect.visible = false;
        this.group.add(this.trailEffect);
    }

    /**
     * Create particle system
     */
    createParticleSystem(count, color) {
        const geometry = new THREE.BufferGeometry();
        const positions = new Float32Array(count * 3);
        const velocities = new Float32Array(count * 3);
        
        for (let i = 0; i < count; i++) {
            const i3 = i * 3;
            positions[i3] = 0;
            positions[i3 + 1] = 0;
            positions[i3 + 2] = 0;
            
            velocities[i3] = (Math.random() - 0.5) * 2;
            velocities[i3 + 1] = Math.random() * 2;
            velocities[i3 + 2] = (Math.random() - 0.5) * 2;
        }
        
        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geometry.setAttribute('velocity', new THREE.BufferAttribute(velocities, 3));
        
        const material = new THREE.PointsMaterial({
            color: color,
            size: 0.1,
            transparent: true,
            opacity: 0.8
        });
        
        const particles = new THREE.Points(geometry, material);
        this.scene.add(particles);
        
        return particles;
    }

    /**
     * Set character state
     */
    setState(newState) {
        if (this.state === newState) return;
        
        this.state = newState;
        this.currentAnimation = this.animationStates[newState];
        
        DebugUtils.log(`Player state changed to: ${newState}`);
        
        // Handle state-specific logic
        switch (newState) {
            case 'running':
                this.isRunning = true;
                break;
            case 'jumping':
                this.isJumping = true;
                this.isGrounded = false;
                this.performJump();
                break;
            case 'sliding':
                this.isSliding = true;
                this.performSlide();
                break;
            case 'dead':
                this.isDead = true;
                this.isRunning = false;
                break;
        }
    }

    /**
     * Handle jump action
     */
    performJump() {
        if (!this.isGrounded || this.isDead) return;
        
        // Apply jump force
        if (this.body) {
            physicsEngine.applyImpulse('player', { x: 0, y: this.jumpForce, z: 0 });
        }
        
        // Create jump effect
        this.createJumpEffect();
    }

    /**
     * Handle slide action
     */
    performSlide() {
        if (this.isDead) return;
        
        // Temporary slide effect
        setTimeout(() => {
            this.isSliding = false;
            this.setState('running');
        }, this.slideDuration * 1000);
    }

    /**
     * Create jump effect
     */
    createJumpEffect() {
        const effect = new THREE.ParticleEmitter();
        // Implementation would depend on particle system
        this.particleEffects.push(effect);
    }

    /**
     * Move to lane
     */
    moveToLane(lane) {
        if (this.isDead || lane < 0 || lane > 2) return;
        
        this.currentLane = lane;
        const targetX = (lane - 1) * this.laneWidth;
        
        // Smooth lane transition
        const currentX = this.group.position.x;
        const duration = 0.2;
        const startTime = performance.now();
        
        const animateLaneChange = () => {
            const elapsed = performance.now() - startTime;
            const progress = Math.min(elapsed / (duration * 1000), 1);
            const easedProgress = MathUtils.smoothstep(0, 1, progress);
            
            this.group.position.x = currentX + (targetX - currentX) * easedProgress;
            
            if (progress < 1) {
                requestAnimationFrame(animateLaneChange);
            }
        };
        
        animateLaneChange();
    }

    /**
     * Handle input
     */
    handleInput(input) {
        if (this.isDead || this.inputCooldown > 0) return;
        
        this.inputQueue.push(input);
        this.inputCooldown = this.maxInputCooldown;
        
        // Process input immediately for responsive feel
        this.processInput(input);
    }

    /**
     * Process input
     */
    processInput(input) {
        switch (input) {
            case 'jump':
                this.setState('jumping');
                break;
            case 'slide':
                this.setState('sliding');
                break;
            case 'left':
                this.moveToLane(this.currentLane - 1);
                break;
            case 'right':
                this.moveToLane(this.currentLane + 1);
                break;
        }
        
        // Increment combo for successful inputs
        this.comboCount++;
        this.multiplier = GameUtils.calculateCombo(this.comboCount);
    }

    /**
     * Update player
     */
    update(deltaTime) {
        if (this.isDead) return;
        
        // Handle input cooldown
        if (this.inputCooldown > 0) {
            this.inputCooldown -= deltaTime;
        }
        
        // Process queued inputs
        if (this.inputQueue.length > 0) {
            const input = this.inputQueue.shift();
            this.processInput(input);
        }
        
        // Update running speed
        if (this.isRunning && !this.isJumping && !this.isSliding) {
            this.speed = MathUtils.lerp(this.speed, this.maxSpeed, deltaTime * this.acceleration);
        }
        
        // Move forward
        this.group.position.z += this.speed * deltaTime;
        this.distance = this.group.position.z;
        
        // Update score
        this.updateScore(deltaTime);
        
        // Update animations
        this.updateAnimations(deltaTime);
        
        // Check ground contact
        this.checkGroundContact();
        
        // Update effects
        this.updateEffects(deltaTime);
        
        // Update trail effect
        this.updateSpeedTrail();
    }

    /**
     * Update animations
     */
    updateAnimations(deltaTime) {
        if (!this.currentAnimation) return;
        
        const time = this.animationClock.getElapsedTime();
        
        try {
            this.currentAnimation.update(time, deltaTime);
        } catch (error) {
            console.error('Animation update error:', error);
        }
    }

    /**
     * Check ground contact
     */
    checkGroundContact() {
        const playerPos = this.group.position;
        if (playerPos.y <= 1 && this.velocity.y <= 0) {
            if (!this.isGrounded) {
                this.land();
            }
            this.isGrounded = true;
            this.isJumping = false;
            if (this.state === 'jumping' || this.state === 'falling') {
                this.setState('running');
            }
        } else {
            this.isGrounded = false;
        }
    }

    /**
     * Handle landing
     */
    land() {
        this.setState('landing');
        
        // Create landing effect
        this.createLandingEffect();
        
        // Reset combo on landing
        this.comboCount = 0;
        this.multiplier = 1;
    }

    /**
     * Create landing effect
     */
    createLandingEffect() {
        // Particle burst effect
        const particleCount = 15;
        for (let i = 0; i < particleCount; i++) {
            const particle = new THREE.Mesh(
                new THREE.SphereGeometry(0.1),
                new THREE.MeshBasicMaterial({ color: 0x4a90e2, transparent: true })
            );
            
            particle.position.copy(this.group.position);
            particle.position.y = 0.5;
            
            // Random velocity
            particle.userData.velocity = new THREE.Vector3(
                (Math.random() - 0.5) * 4,
                Math.random() * 3,
                (Math.random() - 0.5) * 4
            );
            
            this.scene.add(particle);
            
            // Animate particle
            const animateParticle = () => {
                particle.position.add(particle.userData.velocity);
                particle.userData.velocity.y -= 9.8 * 0.016; // gravity
                particle.material.opacity -= 0.02;
                
                if (particle.material.opacity > 0) {
                    requestAnimationFrame(animateParticle);
                } else {
                    this.scene.remove(particle);
                }
            };
            
            animateParticle();
        }
    }

    /**
     * Update score
     */
    updateScore(deltaTime) {
        const scoreIncrease = this.speed * deltaTime * this.multiplier;
        this.score += scoreIncrease;
    }

    /**
     * Update effects
     */
    updateEffects(deltaTime) {
        // Update particles
        this.particleEffects = this.particleEffects.filter(effect => {
            effect.update(deltaTime);
            return !effect.isDead;
        });
    }

    /**
     * Update speed trail
     */
    updateSpeedTrail() {
        if (this.speed > 5 && this.isRunning) {
            this.trailEffect.visible = true;
            this.trailEffect.material.opacity = (this.speed - 5) / 10;
        } else {
            this.trailEffect.visible = false;
        }
    }

    /**
     * Take damage
     */
    takeDamage() {
        if (this.isDead) return;
        
        this.health--;
        
        // Flash effect
        this.flash(0xff0000, 200);
        
        if (this.health <= 0) {
            this.die();
        }
    }

    /**
     * Flash effect
     */
    flash(color, duration) {
        const originalColor = new THREE.Color(0x4a90e2);
        const flashColor = new THREE.Color(color);
        
        let flashTime = 0;
        const flashInterval = setInterval(() => {
            flashTime += 50;
            const progress = flashTime / duration;
            
            if (progress < 0.5) {
                // Flash on
                this.bodyParts.body.material.color.copy(flashColor);
            } else {
                // Flash off
                this.bodyParts.body.material.color.copy(originalColor);
            }
            
            if (flashTime >= duration) {
                clearInterval(flashInterval);
                this.bodyParts.body.material.color.copy(originalColor);
            }
        }, 50);
    }

    /**
     * Die
     */
    die() {
        this.isDead = true;
        this.setState('falling');
        
        // Stop movement
        this.speed = 0;
        
        DebugUtils.log('Player died');
    }

    /**
     * Reset player
     */
    reset() {
        // Reset states
        this.isRunning = false;
        this.isJumping = false;
        this.isSliding = false;
        this.isDead = false;
        this.isGrounded = true;
        
        // Reset properties
        this.speed = 0;
        this.health = 3;
        this.score = 0;
        this.distance = 0;
        this.comboCount = 0;
        this.multiplier = 1;
        this.currentLane = 1;
        this.state = 'idle';
        
        // Reset position
        this.group.position.set(0, 1, 0);
        this.group.rotation.set(0, 0, 0);
        this.group.scale.set(1, 1, 1);
        
        // Reset physics
        if (this.body) {
            physicsEngine.setVelocity('player', { x: 0, y: 0, z: 0 });
            physicsEngine.setPosition('player', { x: 0, y: 1, z: 0 });
        }
        
        // Set initial animation
        this.setState('idle');
    }

    /**
     * Get player info
     */
    getInfo() {
        return {
            position: this.group.position.toArray(),
            state: this.state,
            speed: this.speed,
            health: this.health,
            score: Math.floor(this.score),
            distance: this.distance,
            isDead: this.isDead,
            isGrounded: this.isGrounded,
            comboCount: this.comboCount,
            multiplier: this.multiplier,
            currentLane: this.currentLane
        };
    }

    /**
     * Dispose resources
     */
    dispose() {
        // Remove from scene
        if (this.group.parent) {
            this.group.parent.remove(this.group);
        }
        
        // Remove physics
        physicsEngine.removeBody('player');
        
        // Dispose animations
        if (this.animationMixer) {
            this.animationMixer.stopAllAction();
        }
        
        // Dispose effects
        this.particleEffects.forEach(effect => {
            if (effect.dispose) effect.dispose();
        });
        
        DebugUtils.log('Player disposed');
    }
}

// Export for use in other modules
window.Player = Player;