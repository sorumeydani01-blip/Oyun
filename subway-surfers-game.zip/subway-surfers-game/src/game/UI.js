// UI Manager for the game

class UIManager {
    constructor() {
        this.elements = {};
        this.animations = new Map();
        this.notifications = [];
        this.isVisible = true;
        
        // UI states
        this.currentScreen = 'loading'; // loading, menu, playing, paused, gameover
        this.score = 0;
        this.coins = 0;
        this.multiplier = 1;
        this.combo = 0;
        this.health = 3;
        
        // Power-up indicators
        this.activePowerUps = new Map();
        this.powerUpTimers = new Map();
        
        // Achievement system
        this.achievements = [];
        this.unlockedAchievements = new Set();
        
        this.init();
    }

    /**
     * Initialize UI manager
     */
    init() {
        this.getUIElements();
        this.setupEventListeners();
        this.loadGameData();
        this.showLoadingScreen();
        
        DebugUtils.log('UI Manager initialized');
    }

    /**
     * Get UI elements
     */
    getUIElements() {
        this.elements = {
            // Screens
            loadingScreen: document.getElementById('loading-screen'),
            mainMenu: document.getElementById('main-menu'),
            gameHud: document.getElementById('game-hud'),
            gameOver: document.getElementById('game-over'),
            pauseMenu: document.getElementById('pause-menu'),
            settingsModal: document.getElementById('settings-modal'),
            instructionsModal: document.getElementById('instructions-modal'),
            
            // Loading
            progressBar: document.getElementById('progress-bar'),
            
            // Menu
            playButton: document.getElementById('play-btn'),
            settingsButton: document.getElementById('settings-btn'),
            leaderboardButton: document.getElementById('leaderboard-btn'),
            bestScoreDisplay: document.getElementById('best-score'),
            
            // HUD
            scoreDisplay: document.getElementById('score'),
            coinsDisplay: document.getElementById('coins'),
            multiplierDisplay: document.getElementById('multiplier'),
            pauseButton: document.getElementById('pause-btn'),
            
            // Game Over
            finalScoreDisplay: document.getElementById('final-score'),
            bestScoreGameOver: document.getElementById('best-score-gameover'),
            newRecordDisplay: document.getElementById('new-record'),
            restartButton: document.getElementById('restart-btn'),
            menuButton: document.getElementById('menu-btn'),
            
            // Pause Menu
            resumeButton: document.getElementById('resume-btn'),
            
            // Settings
            volumeSlider: document.getElementById('volume-slider'),
            qualitySelector: document.getElementById('quality-selector'),
            closeSettingsButton: document.getElementById('close-settings'),
            
            // Instructions
            closeInstructionsButton: document.getElementById('close-instructions')
        };
    }

    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Menu buttons
        this.elements.playButton?.addEventListener('click', () => this.startGame());
        this.elements.settingsButton?.addEventListener('click', () => this.showSettings());
        this.elements.leaderboardButton?.addEventListener('click', () => this.showLeaderboard());
        
        // Game controls
        this.elements.pauseButton?.addEventListener('click', () => this.pauseGame());
        this.elements.restartButton?.addEventListener('click', () => this.restartGame());
        this.elements.menuButton?.addEventListener('click', () => this.goToMenu());
        this.elements.resumeButton?.addEventListener('click', () => this.resumeGame());
        
        // Settings
        this.elements.closeSettingsButton?.addEventListener('click', () => this.hideSettings());
        this.elements.volumeSlider?.addEventListener('input', (e) => this.setVolume(e.target.value));
        this.elements.qualitySelector?.addEventListener('change', (e) => this.setQuality(e.target.value));
        
        // Instructions
        this.elements.closeInstructionsButton?.addEventListener('click', () => this.hideInstructions());
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyPress(e));
    }

    /**
     * Load game data
     */
    loadGameData() {
        // Load high score
        const highScore = StorageUtils.load('highScore', 0);
        if (this.elements.bestScoreDisplay) {
            this.elements.bestScoreDisplay.textContent = StringUtils.formatNumber(highScore);
        }
        
        // Load settings
        const settings = StorageUtils.load('settings', {
            volume: 50,
            quality: 'medium',
            showInstructions: true
        });
        
        if (this.elements.volumeSlider) {
            this.elements.volumeSlider.value = settings.volume;
        }
        
        if (this.elements.qualitySelector) {
            this.elements.qualitySelector.value = settings.quality;
        }
        
        // Load achievements
        this.achievements = this.getAchievements();
        const unlockedAchievements = StorageUtils.load('unlockedAchievements', []);
        unlockedAchievements.forEach(id => this.unlockedAchievements.add(id));
        
        // Show instructions if not seen before
        if (settings.showInstructions) {
            setTimeout(() => this.showInstructions(), 1000);
        }
    }

    /**
     * Get achievements list
     */
    getAchievements() {
        return [
            {
                id: 'first_run',
                name: 'İlk Koşu',
                description: 'İlk oyununuzu tamamlayın',
                icon: '🏃',
                condition: (game) => game.player.distance > 100
            },
            {
                id: 'coin_collector',
                name: 'Para Toplayıcı',
                description: '100 para toplayın',
                icon: '🪙',
                condition: (game) => game.player.score > 1000
            },
            {
                id: 'speed_demon',
                name: 'Hız Şeytanı',
                description: 'Maksimum hıza ulaşın',
                icon: '💨',
                condition: (game) => game.player.speed >= game.player.maxSpeed
            },
            {
                id: 'combo_master',
                name: 'Combo Ustası',
                description: '10 combo yapın',
                icon: '🔥',
                condition: (game) => game.player.comboCount >= 10
            },
            {
                id: 'survivor',
                name: 'Hayatta Kalan',
                description: '5000 puan alın',
                icon: '🏆',
                condition: (game) => game.player.score > 5000
            },
            {
                id: 'power_user',
                name: 'Güç Kullanıcısı',
                description: 'Tüm power-up\'ları deneyin',
                icon: '⚡',
                condition: (game) => {
                    const powerUps = ['magnet', 'jetpack', 'shield'];
                    return powerUps.every(powerUp => game.ui.activePowerUps.has(powerUp));
                }
            }
        ];
    }

    /**
     * Show loading screen
     */
    showLoadingScreen() {
        this.showScreen('loading');
        this.updateProgress(0);
    }

    /**
     * Update loading progress
     */
    updateProgress(progress) {
        if (this.elements.progressBar) {
            this.elements.progressBar.style.width = `${Math.min(progress, 100)}%`;
        }
    }

    /**
     * Hide loading screen
     */
    hideLoadingScreen() {
        setTimeout(() => {
            this.showMainMenu();
        }, 500);
    }

    /**
     * Show main menu
     */
    showMainMenu() {
        this.showScreen('menu');
        this.updateHighScore();
        
        // Update play button animation
        this.animatePlayButton();
    }

    /**
     * Show game HUD
     */
    showGameHUD() {
        this.showScreen('playing');
        this.resetHUD();
    }

    /**
     * Show game over screen
     */
    showGameOver(finalScore, isNewRecord = false) {
        this.showScreen('gameover');
        
        if (this.elements.finalScoreDisplay) {
            this.elements.finalScoreDisplay.textContent = StringUtils.formatNumber(Math.floor(finalScore));
        }
        
        if (this.elements.bestScoreGameOver) {
            const highScore = StorageUtils.load('highScore', 0);
            this.elements.bestScoreGameOver.textContent = StringUtils.formatNumber(highScore);
        }
        
        if (this.elements.newRecordDisplay) {
            this.elements.newRecordDisplay.classList.toggle('hidden', !isNewRecord);
        }
        
        // Show achievement notifications
        this.checkAchievements(window.game);
    }

    /**
     * Show pause menu
     */
    showPauseMenu() {
        this.showScreen('paused');
    }

    /**
     * Hide pause menu
     */
    hidePauseMenu() {
        if (this.currentScreen === 'paused') {
            this.showScreen('playing');
        }
    }

    /**
     * Show settings modal
     */
    showSettings() {
        if (this.elements.settingsModal) {
            this.elements.settingsModal.classList.remove('hidden');
        }
    }

    /**
     * Hide settings modal
     */
    hideSettings() {
        if (this.elements.settingsModal) {
            this.elements.settingsModal.classList.add('hidden');
        }
    }

    /**
     * Show instructions modal
     */
    showInstructions() {
        if (this.elements.instructionsModal) {
            this.elements.instructionsModal.classList.remove('hidden');
        }
        
        // Mark instructions as shown
        const settings = StorageUtils.load('settings', {});
        settings.showInstructions = false;
        StorageUtils.save('settings', settings);
    }

    /**
     * Hide instructions modal
     */
    hideInstructions() {
        if (this.elements.instructionsModal) {
            this.elements.instructionsModal.classList.add('hidden');
        }
    }

    /**
     * Show screen
     */
    showScreen(screenName) {
        this.currentScreen = screenName;
        
        // Hide all screens
        Object.values(this.elements).forEach(element => {
            if (element && element.classList.contains('main-menu') ||
                element && element.classList.contains('game-hud') ||
                element && element.classList.contains('game-over') ||
                element && element.classList.contains('pause-menu') ||
                element && element.classList.contains('loading-screen')) {
                element.classList.add('hidden');
            }
        });
        
        // Show target screen
        switch (screenName) {
            case 'loading':
                this.elements.loadingScreen?.classList.remove('hidden');
                break;
            case 'menu':
                this.elements.mainMenu?.classList.remove('hidden');
                break;
            case 'playing':
                this.elements.gameHud?.classList.remove('hidden');
                break;
            case 'gameover':
                this.elements.gameOver?.classList.remove('hidden');
                break;
            case 'paused':
                this.elements.pauseMenu?.classList.remove('hidden');
                break;
        }
    }

    /**
     * Start game
     */
    startGame() {
        DebugUtils.log('Starting game...');
        
        if (window.game) {
            window.game.start();
        }
        
        this.showGameHUD();
        this.hideInstructions();
    }

    /**
     * Restart game
     */
    restartGame() {
        if (window.game) {
            window.game.restart();
        }
        
        this.showGameHUD();
    }

    /**
     * Go to main menu
     */
    goToMenu() {
        if (window.game) {
            window.game.stop();
        }
        
        this.showMainMenu();
    }

    /**
     * Pause game
     */
    pauseGame() {
        if (window.game) {
            window.game.pause();
        }
        
        this.showPauseMenu();
    }

    /**
     * Resume game
     */
    resumeGame() {
        if (window.game) {
            window.game.resume();
        }
        
        this.hidePauseMenu();
        this.showGameHUD();
    }

    /**
     * Handle keyboard shortcuts
     */
    handleKeyPress(event) {
        switch (event.code) {
            case 'Escape':
                if (this.currentScreen === 'playing') {
                    this.pauseGame();
                } else if (this.currentScreen === 'paused') {
                    this.resumeGame();
                }
                break;
            case 'Enter':
            case 'Space':
                if (this.currentScreen === 'menu') {
                    this.startGame();
                } else if (this.currentScreen === 'gameover') {
                    this.restartGame();
                }
                break;
        }
    }

    /**
     * Update HUD
     */
    updateHUD(game) {
        if (!game || !game.player) return;
        
        const player = game.player;
        
        // Update score
        const newScore = Math.floor(player.score);
        if (newScore !== this.score) {
            this.score = newScore;
            if (this.elements.scoreDisplay) {
                const oldScore = parseInt(this.elements.scoreDisplay.textContent) || 0;
                this.elements.scoreDisplay.textContent = StringUtils.formatNumber(newScore);
                
                // Animate score increase
                if (newScore > oldScore) {
                    this.animateScoreIncrease();
                }
            }
        }
        
        // Update coins (if tracked separately)
        const newCoins = player.coins || 0;
        if (newCoins !== this.coins) {
            this.coins = newCoins;
            if (this.elements.coinsDisplay) {
                this.elements.coinsDisplay.textContent = StringUtils.formatNumber(newCoins);
            }
        }
        
        // Update multiplier
        const newMultiplier = player.multiplier || 1;
        if (newMultiplier !== this.multiplier) {
            this.multiplier = newMultiplier;
            if (this.elements.multiplierDisplay) {
                this.elements.multiplierDisplay.textContent = `x${newMultiplier.toFixed(1)}`;
                
                // Animate multiplier change
                if (newMultiplier > 1) {
                    this.animateCombo(this.multiplier);
                }
            }
        }
        
        // Update health
        const newHealth = player.health || 3;
        if (newHealth !== this.health) {
            this.health = newHealth;
            this.updateHealthDisplay();
        }
        
        // Update power-up indicators
        this.updatePowerUpIndicators();
    }

    /**
     * Update health display
     */
    updateHealthDisplay() {
        // Remove existing health indicators
        const existingIndicators = document.querySelectorAll('.health-indicator');
        existingIndicators.forEach(indicator => indicator.remove());
        
        // Create new health indicators
        for (let i = 0; i < this.health; i++) {
            const indicator = document.createElement('div');
            indicator.className = 'health-indicator';
            indicator.innerHTML = '❤️';
            indicator.style.cssText = `
                position: absolute;
                top: 20px;
                left: ${20 + i * 30}px;
                font-size: 24px;
                z-index: 100;
            `;
            
            document.body.appendChild(indicator);
        }
    }

    /**
     * Update power-up indicators
     */
    updatePowerUpIndicators() {
        const player = window.game?.player;
        if (!player) return;
        
        const powerUps = ['magnet', 'jetpack', 'shield', 'boost', 'invincibility'];
        
        powerUps.forEach(powerUp => {
            const isActive = player[`${powerUp}Active`] || false;
            
            if (isActive && !this.activePowerUps.has(powerUp)) {
                // Power-up activated
                this.activatePowerUpIndicator(powerUp);
            } else if (!isActive && this.activePowerUps.has(powerUp)) {
                // Power-up deactivated
                this.deactivatePowerUpIndicator(powerUp);
            }
        });
    }

    /**
     * Activate power-up indicator
     */
    activatePowerUpIndicator(powerUp) {
        this.activePowerUps.set(powerUp, true);
        
        const indicator = document.createElement('div');
        indicator.className = `powerup-indicator powerup-${powerUp}`;
        indicator.innerHTML = this.getPowerUpIcon(powerUp);
        indicator.style.cssText = `
            position: absolute;
            bottom: 20px;
            right: ${20 + this.activePowerUps.size * 60}px;
            font-size: 32px;
            z-index: 100;
            animation: powerupGlow 1.5s ease-in-out infinite;
        `;
        
        document.body.appendChild(indicator);
        
        // Add timer display
        const timer = document.createElement('div');
        timer.className = 'powerup-timer';
        timer.style.cssText = `
            position: absolute;
            bottom: -5px;
            right: 0;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 10px;
        `;
        
        indicator.appendChild(timer);
    }

    /**
     * Deactivate power-up indicator
     */
    deactivatePowerUpIndicator(powerUp) {
        this.activePowerUps.delete(powerUp);
        
        const indicator = document.querySelector(`.powerup-${powerUp}`);
        if (indicator) {
            indicator.remove();
        }
    }

    /**
     * Get power-up icon
     */
    getPowerUpIcon(powerUp) {
        const icons = {
            magnet: '🧲',
            jetpack: '🚀',
            shield: '🛡️',
            boost: '💨',
            invincibility: '⭐'
        };
        return icons[powerUp] || '⚡';
    }

    /**
     * Show notification
     */
    showNotification(message, type = 'info', duration = 3000) {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#4CAF50' : type === 'error' ? '#f44336' : '#2196F3'};
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            font-weight: 500;
            z-index: 1000;
            animation: slideInRight 0.3s ease-out;
            max-width: 300px;
            word-wrap: break-word;
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove
        setTimeout(() => {
            if (notification.parentNode) {
                notification.style.animation = 'slideOutRight 0.3s ease-in';
                setTimeout(() => notification.remove(), 300);
            }
        }, duration);
        
        this.notifications.push(notification);
    }

    /**
     * Show achievement notification
     */
    showAchievement(achievement) {
        if (this.unlockedAchievements.has(achievement.id)) return;
        
        this.unlockedAchievements.add(achievement.id);
        
        // Save to storage
        const unlockedAchievements = Array.from(this.unlockedAchievements);
        StorageUtils.save('unlockedAchievements', unlockedAchievements);
        
        // Show notification
        const notification = document.createElement('div');
        notification.className = 'achievement-popup';
        notification.innerHTML = `
            <div style="text-align: center;">
                <div style="font-size: 48px; margin-bottom: 10px;">${achievement.icon}</div>
                <div style="font-size: 18px; font-weight: bold;">${achievement.name}</div>
                <div style="font-size: 14px; opacity: 0.8;">${achievement.description}</div>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove after animation
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 3000);
        
        DebugUtils.log(`Achievement unlocked: ${achievement.name}`);
    }

    /**
     * Check achievements
     */
    checkAchievements(game) {
        if (!game) return;
        
        this.achievements.forEach(achievement => {
            if (!this.unlockedAchievements.has(achievement.id)) {
                try {
                    if (achievement.condition(game)) {
                        this.showAchievement(achievement);
                    }
                } catch (error) {
                    console.error('Error checking achievement:', achievement.id, error);
                }
            }
        });
    }

    /**
     * Animate play button
     */
    animatePlayButton() {
        if (!this.elements.playButton) return;
        
        const button = this.elements.playButton;
        
        // Add glow effect
        const glow = document.createElement('div');
        glow.className = 'button-glow';
        glow.style.cssText = `
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        `;
        
        button.appendChild(glow);
        
        // Animate glow
        setTimeout(() => {
            glow.style.left = '100%';
        }, 1000);
        
        // Remove glow after animation
        setTimeout(() => {
            if (glow.parentNode) {
                glow.remove();
            }
        }, 2000);
    }

    /**
     * Animate score increase
     */
    animateScoreIncrease() {
        if (!this.elements.scoreDisplay) return;
        
        const element = this.elements.scoreDisplay;
        element.classList.add('score-increase');
        
        setTimeout(() => {
            element.classList.remove('score-increase');
        }, 800);
    }

    /**
     * Animate combo
     */
    animateCombo(multiplier) {
        if (!this.elements.multiplierDisplay) return;
        
        const element = this.elements.multiplierDisplay;
        element.classList.add('combo-display');
        
        // Create floating combo text
        const comboText = document.createElement('div');
        comboText.className = 'combo-display';
        comboText.textContent = `${multiplier.toFixed(1)}x COMBO!`;
        comboText.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 48px;
            font-weight: 800;
            color: #FF8A24;
            text-shadow: 0 0 20px rgba(255, 138, 36, 0.8);
            pointer-events: none;
            z-index: 1000;
            animation: comboDisplay 1.5s ease-out forwards;
        `;
        
        document.body.appendChild(comboText);
        
        setTimeout(() => {
            if (comboText.parentNode) {
                comboText.remove();
            }
            element.classList.remove('combo-display');
        }, 1500);
    }

    /**
     * Reset HUD
     */
    resetHUD() {
        this.score = 0;
        this.coins = 0;
        this.multiplier = 1;
        this.combo = 0;
        this.health = 3;
        
        // Reset displays
        if (this.elements.scoreDisplay) {
            this.elements.scoreDisplay.textContent = '0';
        }
        if (this.elements.coinsDisplay) {
            this.elements.coinsDisplay.textContent = '0';
        }
        if (this.elements.multiplierDisplay) {
            this.elements.multiplierDisplay.textContent = 'x1.0';
        }
        
        // Remove power-up indicators
        this.activePowerUps.clear();
        document.querySelectorAll('.powerup-indicator').forEach(indicator => indicator.remove());
        
        // Remove health indicators
        document.querySelectorAll('.health-indicator').forEach(indicator => indicator.remove());
    }

    /**
     * Update high score
     */
    updateHighScore() {
        const highScore = StorageUtils.load('highScore', 0);
        if (this.elements.bestScoreDisplay) {
            this.elements.bestScoreDisplay.textContent = StringUtils.formatNumber(highScore);
        }
    }

    /**
     * Set volume
     */
    setVolume(volume) {
        // Update audio volume (implementation depends on audio system)
        const settings = StorageUtils.load('settings', {});
        settings.volume = volume;
        StorageUtils.save('settings', settings);
    }

    /**
     * Set quality
     */
    setQuality(quality) {
        // Apply quality settings
        const settings = StorageUtils.load('settings', {});
        settings.quality = quality;
        StorageUtils.save('settings', settings);
        
        // Apply to game if running
        if (window.game) {
            window.game.setQuality(quality);
        }
    }

    /**
     * Show leaderboard
     */
    showLeaderboard() {
        // Implementation for leaderboard modal
        this.showNotification('Liderlik tablosu yakında!', 'info');
    }

    /**
     * Get current screen
     */
    getCurrentScreen() {
        return this.currentScreen;
    }

    /**
     * Get UI info
     */
    getInfo() {
        return {
            currentScreen: this.currentScreen,
            score: this.score,
            coins: this.coins,
            multiplier: this.multiplier,
            health: this.health,
            activePowerUps: Array.from(this.activePowerUps.keys()),
            unlockedAchievements: Array.from(this.unlockedAchievements),
            notificationCount: this.notifications.length
        };
    }

    /**
     * Dispose UI manager
     */
    dispose() {
        // Clear all notifications
        this.notifications.forEach(notification => {
            if (notification.parentNode) {
                notification.remove();
            }
        });
        
        // Clear animations
        this.animations.clear();
        
        // Clear power-up timers
        this.powerUpTimers.forEach(timer => clearInterval(timer));
        this.powerUpTimers.clear();
        
        DebugUtils.log('UI Manager disposed');
    }
}

// Export for use in other modules
window.UIManager = UIManager;