// Main game class

class Game {
    constructor() {
        this.isRunning = false;
        this.isPaused = false;
        this.isInitialized = false;
        
        // Core components
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.canvas = null;
        
        // Game objects
        this.player = null;
        this.environment = null;
        this.trackManager = null;
        this.obstacleManager = null;
        this.collectibleManager = null;
        this.ui = null;
        
        // Game state
        this.state = 'loading'; // loading, menu, playing, paused, gameover
        this.gameTime = 0;
        this.lastTime = 0;
        this.fps = 0;
        this.frameCount = 0;
        this.fpsUpdateTime = 0;
        
        // Settings
        this.settings = {
            quality: 'medium',
            shadows: true,
            antialiasing: true,
            maxFPS: 60
        };
        
        // Event listeners
        this.eventListeners = [];
        
        this.init();
    }

    /**
     * Initialize game
     */
    async init() {
        try {
            this.canvas = document.getElementById('game-canvas');
            if (!this.canvas) {
                throw new Error('Game canvas not found');
            }
            
            // Setup Three.js
            this.setupThreeJS();
            
            // Create core components
            this.createComponents();
            
            // Setup game systems
            this.setupSystems();
            
            // Setup controls
            this.setupControls();
            
            // Load settings
            this.loadSettings();
            
            this.isInitialized = true;
            this.ui.hideLoadingScreen();
            
            DebugUtils.log('Game initialized successfully');
        } catch (error) {
            console.error('Failed to initialize game:', error);
            this.showError('Oyun başlatılamadı. Lütfen sayfayı yenileyin.');
        }
    }

    /**
     * Setup Three.js
     */
    setupThreeJS() {
        // Create scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x1a1a2e);
        this.scene.fog = new THREE.Fog(0x1a1a2e, 20, 200);
        
        // Create camera
        const aspect = window.innerWidth / window.innerHeight;
        this.camera = new THREE.PerspectiveCamera(75, aspect, 0.1, 1000);
        this.camera.position.set(0, 5, -10);
        this.camera.lookAt(0, 0, 10);
        
        // Create renderer
        this.renderer = new THREE.WebGLRenderer({
            canvas: this.canvas,
            antialias: this.settings.antialiasing,
            alpha: false,
            powerPreference: 'high-performance'
        });
        
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.shadowMap.enabled = this.settings.shadows;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        this.renderer.outputEncoding = THREE.sRGBEncoding;
        this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        this.renderer.toneMappingExposure = 1;
        
        // Handle window resize
        window.addEventListener('resize', () => this.handleResize());
    }

    /**
     * Create game components
     */
    createComponents() {
        // Create UI manager first
        this.ui = new UIManager();
        
        // Create environment
        this.environment = new Environment(this.scene);
        
        // Create player
        this.player = new Player(this.scene);
        
        // Create track manager
        this.trackManager = new TrackManager(this.scene, this.player);
        
        // Create obstacle manager
        this.obstacleManager = new ObstacleManager(this.scene);
        
        // Create collectible manager
        this.collectibleManager = new CollectibleManager(this.scene);
    }

    /**
     * Setup game systems
     */
    setupSystems() {
        // Setup physics
        if (physicsEngine) {
            physicsEngine.start();
        }
        
        // Setup controls
        if (window.controlsManager) {
            window.controlsManager.setGameState(this.state);
        }
        
        // Setup animations
        if (window.animationManager) {
            window.animationManager.start();
        }
    }

    /**
     * Setup controls
     */
    setupControls() {
        // Initialize controls manager
        if (!window.controlsManager) {
            window.controlsManager = new ControlsManager(this.canvas);
        }
        
        // Set up control callbacks
        window.controlsManager.on('swipeUp', () => this.handleInput('jump'));
        window.controlsManager.on('swipeDown', () => this.handleInput('slide'));
        window.controlsManager.on('swipeLeft', () => this.handleInput('left'));
        window.controlsManager.on('swipeRight', () => this.handleInput('right'));
    }

    /**
     * Handle input
     */
    handleInput(input) {
        if (!this.isRunning || this.isPaused) return;
        
        DebugUtils.log('Input received:', input);
        
        switch (input) {
            case 'jump':
                this.player.handleInput('jump');
                break;
            case 'slide':
                this.player.handleInput('slide');
                break;
            case 'left':
                this.player.handleInput('left');
                break;
            case 'right':
                this.player.handleInput('right');
                break;
        }
    }

    /**
     * Load settings
     */
    loadSettings() {
        const savedSettings = StorageUtils.load('settings', this.settings);
        this.settings = { ...this.settings, ...savedSettings };
        
        // Apply quality settings
        this.setQuality(this.settings.quality);
    }

    /**
     * Start game
     */
    start() {
        if (!this.isInitialized) {
            console.error('Game not initialized');
            return;
        }
        
        this.isRunning = true;
        this.isPaused = false;
        this.state = 'playing';
        this.gameTime = 0;
        this.lastTime = performance.now();
        
        // Reset game state
        this.reset();
        
        // Update UI
        this.ui.showGameHUD();
        
        // Start game loop
        this.gameLoop();
        
        DebugUtils.log('Game started');
    }

    /**
     * Stop game
     */
    stop() {
        this.isRunning = false;
        this.isPaused = false;
        this.state = 'menu';
        
        // Stop physics
        if (physicsEngine) {
            physicsEngine.stop();
        }
        
        DebugUtils.log('Game stopped');
    }

    /**
     * Pause game
     */
    pause() {
        if (!this.isRunning) return;
        
        this.isPaused = true;
        this.state = 'paused';
        
        // Pause physics
        if (physicsEngine) {
            physicsEngine.setPlaying(false);
        }
        
        // Pause animations
        if (window.animationManager) {
            window.animationManager.setPlaying(false);
        }
        
        // Update controls
        if (window.controlsManager) {
            window.controlsManager.setGameState('paused');
        }
        
        DebugUtils.log('Game paused');
    }

    /**
     * Resume game
     */
    resume() {
        if (!this.isRunning) return;
        
        this.isPaused = false;
        this.state = 'playing';
        
        // Resume physics
        if (physicsEngine) {
            physicsEngine.setPlaying(true);
        }
        
        // Resume animations
        if (window.animationManager) {
            window.animationManager.setPlaying(true);
        }
        
        // Update controls
        if (window.controlsManager) {
            window.controlsManager.setGameState('playing');
        }
        
        // Reset timing
        this.lastTime = performance.now();
        
        DebugUtils.log('Game resumed');
    }

    /**
     * Restart game
     */
    restart() {
        this.stop();
        setTimeout(() => this.start(), 100);
    }

    /**
     * Reset game state
     */
    reset() {
        // Reset player
        if (this.player) {
            this.player.reset();
        }
        
        // Reset track manager
        if (this.trackManager) {
            this.trackManager.clear();
            this.trackManager.generateInitialSegments();
        }
        
        // Reset obstacle manager
        if (this.obstacleManager) {
            this.obstacleManager.clear();
        }
        
        // Reset collectible manager
        if (this.collectibleManager) {
            this.collectibleManager.clear();
        }
        
        // Reset environment
        if (this.environment) {
            this.environment.setSpeed(1);
        }
        
        // Reset game time
        this.gameTime = 0;
        this.frameCount = 0;
        this.fpsUpdateTime = 0;
    }

    /**
     * Game loop
     */
    gameLoop() {
        if (!this.isRunning) return;
        
        const currentTime = performance.now();
        const deltaTime = Math.min((currentTime - this.lastTime) / 1000, 0.1); // Cap at 100ms
        
        this.lastTime = currentTime;
        this.gameTime += deltaTime;
        
        // Update FPS counter
        this.updateFPS(deltaTime);
        
        // Update game
        if (!this.isPaused) {
            this.update(deltaTime);
        }
        
        // Render
        this.render();
        
        // Continue loop
        requestAnimationFrame(() => this.gameLoop());
    }

    /**
     * Update FPS counter
     */
    updateFPS(deltaTime) {
        this.frameCount++;
        this.fpsUpdateTime += deltaTime;
        
        if (this.fpsUpdateTime >= 1) {
            this.fps = Math.round(this.frameCount / this.fpsUpdateTime);
            this.frameCount = 0;
            this.fpsUpdateTime = 0;
        }
    }

    /**
     * Update game
     */
    update(deltaTime) {
        try {
            // Update player
            if (this.player) {
                this.player.update(deltaTime);
                
                // Check if player died
                if (this.player.isDead) {
                    this.gameOver();
                    return;
                }
            }
            
            // Update environment
            if (this.environment) {
                this.environment.update(deltaTime, this.player);
            }
            
            // Update track manager
            if (this.trackManager) {
                this.trackManager.update(deltaTime);
            }
            
            // Update obstacle manager
            if (this.obstacleManager) {
                this.obstacleManager.update(deltaTime);
                
                // Check collisions
                if (this.player) {
                    this.obstacleManager.obstacles.forEach(obstacle => {
                        if (this.obstacleManager.checkCollision(this.player, obstacle)) {
                            this.obstacleManager.handleCollision(this.player, obstacle);
                        }
                    });
                }
            }
            
            // Update collectible manager
            if (this.collectibleManager) {
                this.collectibleManager.update(deltaTime);
            }
            
            // Update camera to follow player
            this.updateCamera(deltaTime);
            
            // Update physics
            if (physicsEngine) {
                physicsEngine.update(deltaTime);
            }
            
            // Update animations
            if (window.animationManager) {
                window.animationManager.update(deltaTime);
            }
            
            // Update UI
            if (this.ui) {
                this.ui.updateHUD(this);
            }
            
        } catch (error) {
            console.error('Error updating game:', error);
        }
    }

    /**
     * Update camera to follow player
     */
    updateCamera(deltaTime) {
        if (!this.player) return;
        
        const playerPos = this.player.group.position;
        const targetCameraPos = new THREE.Vector3(
            playerPos.x * 0.5, // Slight horizontal follow
            5 + Math.sin(this.gameTime * 2) * 0.5, // Slight bobbing
            playerPos.z - 10 // Stay behind player
        );
        
        // Smooth camera movement
        this.camera.position.lerp(targetCameraPos, deltaTime * 2);
        
        // Look ahead of player
        const lookAtTarget = new THREE.Vector3(
            playerPos.x,
            1,
            playerPos.z + 15
        );
        this.camera.lookAt(lookAtTarget);
    }

    /**
     * Render game
     */
    render() {
        try {
            if (this.renderer && this.scene && this.camera) {
                this.renderer.render(this.scene, this.camera);
            }
        } catch (error) {
            console.error('Error rendering game:', error);
        }
    }

    /**
     * Game over
     */
    gameOver() {
        this.isRunning = false;
        this.state = 'gameover';
        
        // Update high score
        const finalScore = Math.floor(this.player.score);
        const currentHighScore = StorageUtils.load('highScore', 0);
        const isNewRecord = finalScore > currentHighScore;
        
        if (isNewRecord) {
            StorageUtils.save('highScore', finalScore);
        }
        
        // Show game over screen
        if (this.ui) {
            this.ui.showGameOver(finalScore, isNewRecord);
        }
        
        // Stop physics and animations
        if (physicsEngine) {
            physicsEngine.stop();
        }
        
        if (window.animationManager) {
            window.animationManager.setPlaying(false);
        }
        
        DebugUtils.log(`Game over. Final score: ${finalScore}`);
    }

    /**
     * Handle window resize
     */
    handleResize() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        
        // Update camera aspect ratio
        if (this.camera) {
            this.camera.aspect = width / height;
            this.camera.updateProjectionMatrix();
        }
        
        // Update renderer size
        if (this.renderer) {
            this.renderer.setSize(width, height);
            this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        }
    }

    /**
     * Set quality settings
     */
    setQuality(quality) {
        this.settings.quality = quality;
        
        switch (quality) {
            case 'low':
                this.applyLowQualitySettings();
                break;
            case 'medium':
                this.applyMediumQualitySettings();
                break;
            case 'high':
                this.applyHighQualitySettings();
                break;
        }
        
        // Save settings
        StorageUtils.save('settings', this.settings);
    }

    /**
     * Apply low quality settings
     */
    applyLowQualitySettings() {
        if (this.renderer) {
            this.renderer.shadowMap.enabled = false;
            this.renderer.setPixelRatio(1);
        }
        
        if (this.environment) {
            this.environment.setSpeed(0.8); // Reduce particle effects
        }
    }

    /**
     * Apply medium quality settings
     */
    applyMediumQualitySettings() {
        if (this.renderer) {
            this.renderer.shadowMap.enabled = true;
            this.renderer.shadowMap.type = THREE.BasicShadowMap;
            this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
        }
    }

    /**
     * Apply high quality settings
     */
    applyHighQualitySettings() {
        if (this.renderer) {
            this.renderer.shadowMap.enabled = true;
            this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
            this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        }
    }

    /**
     * Show error message
     */
    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #f44336;
            color: white;
            padding: 20px;
            border-radius: 8px;
            font-size: 18px;
            text-align: center;
            z-index: 10000;
        `;
        errorDiv.textContent = message;
        
        document.body.appendChild(errorDiv);
    }

    /**
     * Get game info
     */
    getInfo() {
        return {
            isRunning: this.isRunning,
            isPaused: this.isPaused,
            state: this.state,
            gameTime: this.gameTime,
            fps: this.fps,
            player: this.player ? this.player.getInfo() : null,
            environment: this.environment ? this.environment.getInfo() : null,
            trackManager: this.trackManager ? this.trackManager.getInfo() : null,
            obstacleManager: this.obstacleManager ? this.obstacleManager.getInfo() : null,
            collectibleManager: this.collectibleManager ? this.collectibleManager.getInfo() : null,
            ui: this.ui ? this.ui.getInfo() : null
        };
    }

    /**
     * Dispose game
     */
    dispose() {
        this.stop();
        
        // Dispose components
        if (this.player) {
            this.player.dispose();
        }
        
        if (this.environment) {
            this.environment.dispose();
        }
        
        if (this.trackManager) {
            this.trackManager.clear();
        }
        
        if (this.obstacleManager) {
            this.obstacleManager.clear();
        }
        
        if (this.collectibleManager) {
            this.collectibleManager.clear();
        }
        
        if (this.ui) {
            this.ui.dispose();
        }
        
        // Dispose Three.js
        if (this.renderer) {
            this.renderer.dispose();
        }
        
        // Dispose systems
        if (physicsEngine) {
            physicsEngine.destroy();
        }
        
        if (window.animationManager) {
            window.animationManager.stopAll();
        }
        
        if (window.controlsManager) {
            window.controlsManager.destroy();
        }
        
        // Remove event listeners
        this.eventListeners.forEach(({ element, event, handler }) => {
            element.removeEventListener(event, handler);
        });
        
        this.eventListeners = [];
        
        DebugUtils.log('Game disposed');
    }
}

// Export for use in other modules
window.Game = Game;