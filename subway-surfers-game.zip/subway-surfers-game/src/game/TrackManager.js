// Track manager for infinite generation

class TrackManager {
    constructor(scene, player) {
        this.scene = scene;
        this.player = player;
        this.trackSegments = [];
        this.segmentLength = 50;
        this.maxSegments = 20;
        this.currentZ = 0;
        this.isGenerating = false;
        
        // Track properties
        this.laneWidth = 3;
        this.trackWidth = 9;
        this.platformHeight = 0;
        this.railOffset = 2.5;
        
        // Segment types
        this.segmentTypes = {
            normal: this.createNormalSegment,
            obstacle: this.createObstacleSegment,
            coin: this.createCoinSegment,
            powerup: this.createPowerupSegment,
            jump: this.createJumpSegment,
            slide: this.createSlideSegment,
            turn: this.createTurnSegment
        };
        
        // Difficulty scaling
        this.difficulty = 1;
        this.difficultyIncreaseRate = 0.001;
        
        this.init();
    }

    /**
     * Initialize track manager
     */
    init() {
        // Create initial segments
        this.generateInitialSegments();
        
        DebugUtils.log('Track manager initialized');
    }

    /**
     * Generate initial track segments
     */
    generateInitialSegments() {
        // Create 10 initial segments
        for (let i = 0; i < 10; i++) {
            const segment = this.createSegment('normal', i * this.segmentLength);
            this.trackSegments.push(segment);
            this.currentZ += this.segmentLength;
        }
        
        // Add some variety to the first few segments
        this.addEarlyGameVariety();
    }

    /**
     * Add variety to early game segments
     */
    addEarlyGameVariety() {
        if (this.trackSegments.length < 5) return;
        
        // Add coins to segment 2
        this.addCoinsToSegment(2, 5);
        
        // Add obstacle to segment 4
        this.addObstacleToSegment(4, 1);
    }

    /**
     * Create a track segment
     */
    createSegment(type, z) {
        const segment = {
            type: type,
            z: z,
            objects: [],
            obstacles: [],
            collectibles: [],
            decorations: []
        };
        
        const createFunction = this.segmentTypes[type];
        if (createFunction) {
            createFunction.call(this, segment);
        }
        
        return segment;
    }

    /**
     * Create normal segment (just track)
     */
    createNormalSegment(segment) {
        // Track is already created by Environment
        // Add some decorative elements
        this.addPlatformDecorations(segment);
    }

    /**
     * Create obstacle segment
     */
    createObstacleSegment(segment) {
        this.createNormalSegment(segment);
        
        // Add obstacles
        const obstacleCount = Random.int(1, 2 + Math.floor(this.difficulty));
        
        for (let i = 0; i < obstacleCount; i++) {
            const lane = Random.int(0, 2);
            const x = (lane - 1) * this.laneWidth;
            const obstacleType = Random.pick(['barrier', 'train', 'gap']);
            
            const obstacle = this.createObstacle(obstacleType, x, segment.z + Random.int(5, 15));
            segment.obstacles.push(obstacle);
        }
    }

    /**
     * Create coin segment
     */
    createCoinSegment(segment) {
        this.createNormalSegment(segment);
        
        // Add coin patterns
        const pattern = Random.pick(['line', 'arc', 'cluster']);
        this.createCoinPattern(segment, pattern);
    }

    /**
     * Create power-up segment
     */
    createPowerupSegment(segment) {
        this.createNormalSegment(segment);
        
        // Add power-ups
        const powerupCount = Random.int(1, 2);
        
        for (let i = 0; i < powerupCount; i++) {
            const lane = Random.int(0, 2);
            const x = (lane - 1) * this.laneWidth;
            const powerupType = Random.pick(['magnet', 'jetpack', 'shield']);
            
            const powerup = this.createPowerup(powerupType, x, segment.z + Random.int(10, 25));
            segment.collectibles.push(powerup);
        }
    }

    /**
     * Create jump segment
     */
    createJumpSegment(segment) {
        this.createNormalSegment(segment);
        
        // Create gap that requires jumping
        const gapWidth = Random.float(3, 6);
        const gapStart = segment.z + 10;
        
        this.createGap(gapStart, gapWidth);
    }

    /**
     * Create slide segment
     */
    createSlideSegment(segment) {
        this.createNormalSegment(segment);
        
        // Create overhead obstacle that requires sliding
        const overheadHeight = 1.5;
        const overheadStart = segment.z + 8;
        
        this.createOverheadObstacle(overheadStart, overheadHeight);
    }

    /**
     * Create turn segment
     */
    createTurnSegment(segment) {
        this.createNormalSegment(segment);
        
        // Create slight curve in the track
        const curveStart = segment.z + 5;
        this.createTrackCurve(curveStart, 10);
    }

    /**
     * Add platform decorations
     */
    addPlatformDecorations(segment) {
        // Add platform edge details
        for (let i = 0; i < 5; i++) {
            const x = Random.pick([-5.5, 5.5]);
            const detail = this.createPlatformDetail(x, segment.z + i * 2);
            segment.decorations.push(detail);
        }
    }

    /**
     * Create platform detail
     */
    createPlatformDetail(x, z) {
        const detailTypes = ['marking', 'vent', 'speaker'];
        const type = Random.pick(detailTypes);
        
        let geometry, material, scale = 1;
        
        switch (type) {
            case 'marking':
                geometry = new THREE.BoxGeometry(0.2, 0.02, 1);
                material = new THREE.MeshBasicMaterial({ color: 0xffff00 });
                break;
            case 'vent':
                geometry = new THREE.BoxGeometry(0.5, 0.1, 0.3);
                material = new THREE.MeshLambertMaterial({ color: 0x666666 });
                break;
            case 'speaker':
                geometry = new THREE.CylinderGeometry(0.1, 0.1, 0.3);
                material = new THREE.MeshLambertMaterial({ color: 0x333333 });
                break;
        }
        
        const detail = new THREE.Mesh(geometry, material);
        detail.position.set(x, 0.1, z);
        detail.castShadow = true;
        
        this.scene.add(detail);
        return detail;
    }

    /**
     * Create obstacle
     */
    createObstacle(type, x, z) {
        let geometry, material, scale = 1;
        
        switch (type) {
            case 'barrier':
                geometry = new THREE.BoxGeometry(2, 2, 0.5);
                material = new THREE.MeshLambertMaterial({ color: 0xe74c3c });
                break;
            case 'train':
                geometry = new THREE.BoxGeometry(2.5, 2.5, 4);
                material = new THREE.MeshLambertMaterial({ color: 0x34495e });
                break;
            case 'gap':
                geometry = new THREE.BoxGeometry(this.trackWidth, 1, 3);
                material = new THREE.MeshBasicMaterial({ color: 0x000000 });
                scale = 0.1; // Invisible gap
                break;
        }
        
        const obstacle = new THREE.Mesh(geometry, material);
        obstacle.position.set(x, 1, z);
        obstacle.scale.set(scale, scale, scale);
        obstacle.castShadow = true;
        obstacle.userData.type = type;
        obstacle.userData.isObstacle = true;
        
        this.scene.add(obstacle);
        
        // Add physics if not a gap
        if (type !== 'gap') {
            physicsEngine.addBody(`obstacle_${Date.now()}`, obstacle, {
                mass: 0,
                material: 'obstacle'
            });
        }
        
        return obstacle;
    }

    /**
     * Create coin
     */
    createCoin(x, z) {
        const geometry = new THREE.TorusGeometry(0.3, 0.1, 8, 16);
        const material = new THREE.MeshLambertMaterial({ color: 0xffd700 });
        
        const coin = new THREE.Mesh(geometry, material);
        coin.position.set(x, 1.5, z);
        coin.castShadow = true;
        coin.userData.type = 'coin';
        coin.userData.isCollectible = true;
        coin.userData.value = 10;
        
        // Add spinning animation
        const animateCoin = () => {
            if (coin.parent) {
                coin.rotation.y += 0.1;
                requestAnimationFrame(animateCoin);
            }
        };
        animateCoin();
        
        this.scene.add(coin);
        return coin;
    }

    /**
     * Create power-up
     */
    createPowerup(type, x, z) {
        let geometry, material, color;
        
        switch (type) {
            case 'magnet':
                geometry = new THREE.SphereGeometry(0.4);
                color = 0xff6b35;
                break;
            case 'jetpack':
                geometry = new THREE.ConeGeometry(0.3, 0.8);
                color = 0x9b59b6;
                break;
            case 'shield':
                geometry = new THREE.OctahedronGeometry(0.4);
                color = 0x3498db;
                break;
        }
        
        material = new THREE.MeshLambertMaterial({ color: color });
        
        const powerup = new THREE.Mesh(geometry, material);
        powerup.position.set(x, 2, z);
        powerup.castShadow = true;
        powerup.userData.type = type;
        powerup.userData.isCollectible = true;
        powerup.userData.powerupType = type;
        
        // Add floating animation
        const animatePowerup = () => {
            if (powerup.parent) {
                powerup.position.y = 2 + Math.sin(Date.now() * 0.003) * 0.3;
                powerup.rotation.y += 0.05;
                requestAnimationFrame(animatePowerup);
            }
        };
        animatePowerup();
        
        this.scene.add(powerup);
        return powerup;
    }

    /**
     * Create coin pattern
     */
    createCoinPattern(segment, pattern) {
        switch (pattern) {
            case 'line':
                this.createCoinLine(segment);
                break;
            case 'arc':
                this.createCoinArc(segment);
                break;
            case 'cluster':
                this.createCoinCluster(segment);
                break;
        }
    }

    /**
     * Create coin line
     */
    createCoinLine(segment) {
        const lane = Random.int(0, 2);
        const x = (lane - 1) * this.laneWidth;
        
        for (let i = 0; i < 8; i++) {
            const z = segment.z + 5 + i * 2;
            const coin = this.createCoin(x, z);
            segment.collectibles.push(coin);
        }
    }

    /**
     * Create coin arc
     */
    createCoinArc(segment) {
        const centerLane = Random.int(0, 2);
        const centerX = (centerLane - 1) * this.laneWidth;
        
        for (let i = 0; i < 6; i++) {
            const t = (i / 5) * Math.PI;
            const x = centerX + Math.sin(t) * this.laneWidth;
            const y = 1.5 + Math.cos(t) * 0.5;
            const z = segment.z + 5 + i * 3;
            
            const coin = this.createCoin(x, z);
            coin.position.y = y;
            segment.collectibles.push(coin);
        }
    }

    /**
     * Create coin cluster
     */
    createCoinCluster(segment) {
        const centerX = Random.pick([-this.laneWidth, 0, this.laneWidth]);
        
        for (let row = 0; row < 3; row++) {
            for (let col = 0; col < 3; col++) {
                const x = centerX + (col - 1) * 1;
                const z = segment.z + 8 + row * 1.5;
                const coin = this.createCoin(x, z);
                segment.collectibles.push(coin);
            }
        }
    }

    /**
     * Add coins to existing segment
     */
    addCoinsToSegment(segmentIndex, count) {
        if (segmentIndex >= this.trackSegments.length) return;
        
        const segment = this.trackSegments[segmentIndex];
        for (let i = 0; i < count; i++) {
            const lane = Random.int(0, 2);
            const x = (lane - 1) * this.laneWidth;
            const z = segment.z + Random.int(5, 15);
            
            const coin = this.createCoin(x, z);
            segment.collectibles.push(coin);
        }
    }

    /**
     * Add obstacle to existing segment
     */
    addObstacleToSegment(segmentIndex, count) {
        if (segmentIndex >= this.trackSegments.length) return;
        
        const segment = this.trackSegments[segmentIndex];
        for (let i = 0; i < count; i++) {
            const lane = Random.int(0, 2);
            const x = (lane - 1) * this.laneWidth;
            const z = segment.z + Random.int(8, 15);
            
            const obstacle = this.createObstacle('barrier', x, z);
            segment.obstacles.push(obstacle);
        }
    }

    /**
     * Create gap
     */
    createGap(z, width) {
        // Create visual gap in track
        const gapGeometry = new THREE.BoxGeometry(width, 0.1, 3);
        const gapMaterial = new THREE.MeshBasicMaterial({ color: 0x000000 });
        
        const gap = new THREE.Mesh(gapGeometry, gapMaterial);
        gap.position.set(0, -0.05, z);
        gap.userData.type = 'gap';
        gap.userData.isObstacle = true;
        
        this.scene.add(gap);
        
        // Warning signs
        const warningGeometry = new THREE.BoxGeometry(0.5, 1, 0.1);
        const warningMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });
        
        for (let side of [-1, 1]) {
            const warning = new THREE.Mesh(warningGeometry, warningMaterial);
            warning.position.set(side * (width / 2 + 1), 0.5, z - 2);
            this.scene.add(warning);
        }
    }

    /**
     * Create overhead obstacle
     */
    createOverheadObstacle(z, height) {
        const obstacleGeometry = new THREE.BoxGeometry(this.trackWidth, 0.3, 2);
        const obstacleMaterial = new THREE.MeshLambertMaterial({ color: 0xe67e22 });
        
        const obstacle = new THREE.Mesh(obstacleGeometry, obstacleMaterial);
        obstacle.position.set(0, height, z);
        obstacle.userData.type = 'overhead';
        obstacle.userData.isObstacle = true;
        
        this.scene.add(obstacle);
    }

    /**
     * Create track curve
     */
    createTrackCurve(z, length) {
        // This would require more complex geometry manipulation
        // For now, we'll skip this feature
        DebugUtils.log('Track curve creation not implemented yet');
    }

    /**
     * Update track manager
     */
    update(deltaTime) {
        // Increase difficulty over time
        this.difficulty += this.difficultyIncreaseRate;
        
        // Remove segments behind player
        this.removeOldSegments();
        
        // Generate new segments if needed
        this.generateNewSegments();
        
        // Update segment animations
        this.updateSegments(deltaTime);
    }

    /**
     * Remove old segments
     */
    removeOldSegments() {
        const playerZ = this.player.group.position.z;
        const removeThreshold = playerZ - 100;
        
        this.trackSegments = this.trackSegments.filter(segment => {
            if (segment.z < removeThreshold) {
                this.removeSegment(segment);
                return false;
            }
            return true;
        });
    }

    /**
     * Remove segment
     */
    removeSegment(segment) {
        // Remove all objects in segment
        [...segment.objects, ...segment.obstacles, ...segment.collectibles, ...segment.decorations].forEach(obj => {
            if (obj.parent) {
                obj.parent.remove(obj);
            }
        });
        
        DebugUtils.log(`Removed segment at z: ${segment.z}`);
    }

    /**
     * Generate new segments
     */
    generateNewSegments() {
        const playerZ = this.player.group.position.z;
        const generateDistance = playerZ + 500;
        
        while (this.currentZ < generateDistance && this.trackSegments.length < this.maxSegments) {
            // Determine segment type based on difficulty
            const segmentType = this.selectSegmentType();
            const segment = this.createSegment(segmentType, this.currentZ);
            
            this.trackSegments.push(segment);
            this.currentZ += this.segmentLength;
        }
    }

    /**
     * Select segment type based on difficulty
     */
    selectSegmentType() {
        const difficulty = Math.min(this.difficulty, 3);
        
        // Weighted random selection
        const weights = {
            normal: Math.max(0.4 - difficulty * 0.1, 0.1),
            obstacle: Math.min(difficulty * 0.15, 0.3),
            coin: Math.min(0.2 + difficulty * 0.05, 0.3),
            powerup: Math.min(difficulty * 0.05, 0.15),
            jump: Math.min(difficulty * 0.1, 0.2),
            slide: Math.min(difficulty * 0.1, 0.2),
            turn: Math.min(difficulty * 0.05, 0.1)
        };
        
        // Normalize weights
        const totalWeight = Object.values(weights).reduce((sum, weight) => sum + weight, 0);
        
        let random = Math.random() * totalWeight;
        
        for (const [type, weight] of Object.entries(weights)) {
            random -= weight;
            if (random <= 0) {
                return type;
            }
        }
        
        return 'normal';
    }

    /**
     * Update segments
     */
    updateSegments(deltaTime) {
        this.trackSegments.forEach(segment => {
            // Update collectibles
            segment.collectibles.forEach(collectible => {
                this.updateCollectible(collectible, deltaTime);
            });
            
            // Check collisions with player
            this.checkSegmentCollisions(segment);
        });
    }

    /**
     * Update collectible
     */
    updateCollectible(collectible, deltaTime) {
        // Add subtle rotation
        if (collectible.userData.type === 'coin') {
            collectible.rotation.y += deltaTime * 2;
        } else if (collectible.userData.powerupType) {
            collectible.rotation.y += deltaTime * 3;
            collectible.position.y = 2 + Math.sin(Date.now() * 0.005) * 0.3;
        }
    }

    /**
     * Check segment collisions
     */
    checkSegmentCollisions(segment) {
        const playerPos = this.player.group.position;
        const playerRadius = 0.5;
        
        // Check obstacle collisions
        segment.obstacles.forEach(obstacle => {
            const distance = Vector3Utils.distance(playerPos, obstacle.position);
            if (distance < playerRadius + 1) {
                this.handleObstacleCollision(obstacle);
            }
        });
        
        // Check collectible collisions
        segment.collectibles = segment.collectibles.filter(collectible => {
            const distance = Vector3Utils.distance(playerPos, collectible.position);
            
            if (distance < playerRadius + 0.5) {
                this.handleCollectibleCollection(collectible);
                return false; // Remove collectible
            }
            
            return true;
        });
    }

    /**
     * Handle obstacle collision
     */
    handleObstacleCollision(obstacle) {
        if (obstacle.userData.type === 'gap') {
            // Handle gap (falling)
            this.player.die();
        } else {
            // Handle physical obstacle
            this.player.takeDamage();
        }
        
        // Visual feedback
        this.createCollisionEffect(obstacle.position);
    }

    /**
     * Handle collectible collection
     */
    handleCollectibleCollection(collectible) {
        if (collectible.userData.type === 'coin') {
            // Add score
            const score = collectible.userData.value * this.player.multiplier;
            this.player.score += score;
            
            // Create collection effect
            this.createCoinCollectionEffect(collectible.position);
        } else if (collectible.userData.powerupType) {
            // Apply power-up effect
            this.applyPowerUp(collectible.userData.powerupType);
        }
        
        // Remove collectible
        if (collectible.parent) {
            collectible.parent.remove(collectible);
        }
    }

    /**
     * Apply power-up
     */
    applyPowerUp(type) {
        switch (type) {
            case 'magnet':
                this.activateMagnet();
                break;
            case 'jetpack':
                this.activateJetpack();
                break;
            case 'shield':
                this.activateShield();
                break;
        }
    }

    /**
     * Activate magnet power-up
     */
    activateMagnet() {
        // Increase coin collection range temporarily
        this.player.magnetActive = true;
        this.player.magnetDuration = 10; // seconds
        
        setTimeout(() => {
            this.player.magnetActive = false;
        }, 10000);
        
        DebugUtils.log('Magnet power-up activated');
    }

    /**
     * Activate jetpack power-up
     */
    activateJetpack() {
        // Enable auto-jumping
        this.player.jetpackActive = true;
        this.player.jetpackDuration = 8;
        
        setTimeout(() => {
            this.player.jetpackActive = false;
        }, 8000);
        
        DebugUtils.log('Jetpack power-up activated');
    }

    /**
     * Activate shield power-up
     */
    activateShield() {
        // Make player invincible temporarily
        this.player.shieldActive = true;
        this.player.shieldDuration = 12;
        
        setTimeout(() => {
            this.player.shieldActive = false;
        }, 12000);
        
        DebugUtils.log('Shield power-up activated');
    }

    /**
     * Create collision effect
     */
    createCollisionEffect(position) {
        const effectGeometry = new THREE.SphereGeometry(1);
        const effectMaterial = new THREE.MeshBasicMaterial({
            color: 0xff0000,
            transparent: true,
            opacity: 0.6
        });
        
        const effect = new THREE.Mesh(effectGeometry, effectMaterial);
        effect.position.copy(position);
        
        this.scene.add(effect);
        
        // Animate effect
        const animateEffect = () => {
            effect.scale.multiplyScalar(1.1);
            effect.material.opacity -= 0.02;
            
            if (effect.material.opacity > 0) {
                requestAnimationFrame(animateEffect);
            } else {
                if (effect.parent) {
                    effect.parent.remove(effect);
                }
            }
        };
        
        animateEffect();
    }

    /**
     * Create coin collection effect
     */
    createCoinCollectionEffect(position) {
        // Create particle burst
        for (let i = 0; i < 5; i++) {
            const particle = new THREE.Mesh(
                new THREE.SphereGeometry(0.1),
                new THREE.MeshBasicMaterial({ color: 0xffd700 })
            );
            
            particle.position.copy(position);
            
            // Random velocity
            particle.userData.velocity = new THREE.Vector3(
                (Math.random() - 0.5) * 4,
                Math.random() * 3,
                (Math.random() - 0.5) * 4
            );
            
            this.scene.add(particle);
            
            // Animate particle
            const animateParticle = () => {
                particle.position.add(particle.userData.velocity);
                particle.userData.velocity.y -= 9.8 * 0.016;
                particle.material.opacity -= 0.02;
                
                if (particle.material.opacity > 0) {
                    requestAnimationFrame(animateParticle);
                } else {
                    if (particle.parent) {
                        particle.parent.remove(particle);
                    }
                }
            };
            
            animateParticle();
        }
    }

    /**
     * Get nearest segments
     */
    getNearestSegments(playerZ, count = 5) {
        return this.trackSegments
            .filter(segment => segment.z >= playerZ - 50 && segment.z <= playerZ + 200)
            .sort((a, b) => Math.abs(a.z - playerZ) - Math.abs(b.z - playerZ))
            .slice(0, count);
    }

    /**
     * Clear all segments
     */
    clear() {
        this.trackSegments.forEach(segment => {
            this.removeSegment(segment);
        });
        
        this.trackSegments = [];
        this.currentZ = 0;
        this.difficulty = 1;
    }

    /**
     * Get track info
     */
    getInfo() {
        return {
            segmentCount: this.trackSegments.length,
            currentZ: this.currentZ,
            difficulty: this.difficulty,
            maxSegments: this.maxSegments,
            segmentLength: this.segmentLength
        };
    }
}

// Export for use in other modules
window.TrackManager = TrackManager;