// Environment and 3D world for the game

class Environment {
    constructor(scene) {
        this.scene = scene;
        this.objects = new Map();
        this.isLoaded = false;
        
        // Environment properties
        this.trackLength = 1000;
        this.laneWidth = 3;
        this.groundY = 0;
        this.environmentSpeed = 1;
        
        // Lighting
        this.ambientLight = null;
        this.directionalLight = null;
        this.spotLights = [];
        
        // Visual effects
        this.fog = null;
        this.skybox = null;
        this.particleSystems = [];
        
        // Background elements
        this.buildings = [];
        this.trains = [];
        this.decorations = [];
        this.lights = [];
        
        this.init();
    }

    /**
     * Initialize environment
     */
    init() {
        this.setupLighting();
        this.setupFog();
        this.createSkybox();
        this.createGround();
        this.createTrack();
        this.createBuildings();
        this.createTrains();
        this.createDecorations();
        this.createAtmosphericEffects();
        
        this.isLoaded = true;
        DebugUtils.log('Environment initialized');
    }

    /**
     * Setup lighting system
     */
    setupLighting() {
        // Ambient light
        this.ambientLight = new THREE.AmbientLight(0x404040, 0.4);
        this.scene.add(this.ambientLight);
        
        // Directional light (sun)
        this.directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        this.directionalLight.position.set(100, 100, 50);
        this.directionalLight.castShadow = true;
        this.directionalLight.shadow.mapSize.width = 2048;
        this.directionalLight.shadow.mapSize.height = 2048;
        this.directionalLight.shadow.camera.near = 0.5;
        this.directionalLight.shadow.camera.far = 500;
        this.directionalLight.shadow.camera.left = -100;
        this.directionalLight.shadow.camera.right = 100;
        this.directionalLight.shadow.camera.top = 100;
        this.directionalLight.shadow.camera.bottom = -100;
        this.scene.add(this.directionalLight);
        
        // Add additional lights for atmosphere
        this.createAtmosphericLights();
    }

    /**
     * Create atmospheric lights
     */
    createAtmosphericLights() {
        // Track lights
        for (let i = 0; i < 50; i++) {
            const light = new THREE.PointLight(0x4a90e2, 0.5, 20);
            const z = i * 20 - 100;
            light.position.set(-4, 3, z);
            this.scene.add(light);
            
            // Add light source visualization
            const lightBulb = new THREE.Mesh(
                new THREE.SphereGeometry(0.1),
                new THREE.MeshBasicMaterial({ color: 0x4a90e2 })
            );
            lightBulb.position.copy(light.position);
            this.scene.add(lightBulb);
            
            this.lights.push({ light, bulb: lightBulb });
        }
        
        // Warning lights for obstacles
        for (let i = 0; i < 20; i++) {
            const light = new THREE.PointLight(0xff6b35, 1, 15);
            const z = i * 50 + 50;
            light.position.set(0, 5, z);
            this.scene.add(light);
            
            const warningBulb = new THREE.Mesh(
                new THREE.SphereGeometry(0.15),
                new THREE.MeshBasicMaterial({ color: 0xff6b35 })
            );
            warningBulb.position.copy(light.position);
            this.scene.add(warningBulb);
            
            // Pulsing animation
            const animateWarningLight = () => {
                const intensity = Math.sin(Date.now() * 0.005) * 0.3 + 0.7;
                light.intensity = intensity;
                warningBulb.material.opacity = intensity;
                
                if (this.isLoaded) {
                    requestAnimationFrame(animateWarningLight);
                }
            };
            animateWarningLight();
            
            this.lights.push({ light, bulb: warningBulb });
        }
    }

    /**
     * Setup fog effect
     */
    setupFog() {
        this.fog = new THREE.Fog(0x1a1a2e, 20, 200);
        this.scene.fog = this.fog;
    }

    /**
     * Create skybox
     */
    createSkybox() {
        // Create gradient sky
        const skyGeometry = new THREE.SphereGeometry(500, 32, 32);
        const skyMaterial = new THREE.ShaderMaterial({
            uniforms: {
                topColor: { value: new THREE.Color(0x0077be) },
                bottomColor: { value: new THREE.Color(0x89b2eb) },
                offset: { value: 33 },
                exponent: { value: 0.6 }
            },
            vertexShader: `
                varying vec3 vWorldPosition;
                void main() {
                    vec4 worldPosition = modelMatrix * vec4(position, 1.0);
                    vWorldPosition = worldPosition.xyz;
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                }
            `,
            fragmentShader: `
                uniform vec3 topColor;
                uniform vec3 bottomColor;
                uniform float offset;
                uniform float exponent;
                varying vec3 vWorldPosition;
                void main() {
                    float h = normalize(vWorldPosition + offset).y;
                    gl_FragColor = vec4(mix(bottomColor, topColor, max(pow(max(h, 0.0), exponent), 0.0)), 1.0);
                }
            `,
            side: THREE.BackSide
        });
        
        this.skybox = new THREE.Mesh(skyGeometry, skyMaterial);
        this.scene.add(this.skybox);
    }

    /**
     * Create ground plane
     */
    createGround() {
        // Main ground
        const groundGeometry = new THREE.PlaneGeometry(50, this.trackLength);
        const groundMaterial = new THREE.MeshLambertMaterial({
            color: 0x2c3e50,
            transparent: true,
            opacity: 0.9
        });
        
        const ground = new THREE.Mesh(groundGeometry, groundMaterial);
        ground.rotation.x = -Math.PI / 2;
        ground.position.z = this.trackLength / 2 - 50;
        ground.receiveShadow = true;
        this.scene.add(ground);
        
        // Platform edges
        this.createPlatformEdges();
        
        // Track details
        this.createTrackDetails();
    }

    /**
     * Create platform edges
     */
    createPlatformEdges() {
        const edgeGeometry = new THREE.BoxGeometry(0.5, 1, this.trackLength);
        const edgeMaterial = new THREE.MeshLambertMaterial({ color: 0x34495e });
        
        // Left platform edge
        const leftEdge = new THREE.Mesh(edgeGeometry, edgeMaterial);
        leftEdge.position.set(-6.25, 0.5, this.trackLength / 2 - 50);
        leftEdge.castShadow = true;
        this.scene.add(leftEdge);
        
        // Right platform edge
        const rightEdge = new THREE.Mesh(edgeGeometry, edgeMaterial);
        rightEdge.position.set(6.25, 0.5, this.trackLength / 2 - 50);
        rightEdge.castShadow = true;
        this.scene.add(rightEdge);
        
        // Safety barriers
        this.createSafetyBarriers();
    }

    /**
     * Create safety barriers
     */
    createSafetyBarriers() {
        const barrierGeometry = new THREE.BoxGeometry(0.2, 1.2, 0.5);
        const barrierMaterial = new THREE.MeshLambertMaterial({ color: 0xe74c3c });
        
        for (let i = 0; i < 100; i++) {
            const z = i * 10 + 10;
            
            // Left barrier
            const leftBarrier = new THREE.Mesh(barrierGeometry, barrierMaterial);
            leftBarrier.position.set(-6, 0.6, z);
            leftBarrier.castShadow = true;
            this.scene.add(leftBarrier);
            
            // Right barrier
            const rightBarrier = new THREE.Mesh(barrierGeometry, barrierMaterial);
            rightBarrier.position.set(6, 0.6, z);
            rightBarrier.castShadow = true;
            this.scene.add(rightBarrier);
        }
    }

    /**
     * Create train tracks
     */
    createTrack() {
        this.createRailTracks();
        this.createRailTies();
        this.createRailDetails();
    }

    /**
     * Create rail tracks
     */
    createRailTracks() {
        const railGeometry = new THREE.BoxGeometry(0.2, 0.1, this.trackLength);
        const railMaterial = new THREE.MeshLambertMaterial({ color: 0x8b4513 });
        
        // Left rail
        const leftRail = new THREE.Mesh(railGeometry, railMaterial);
        leftRail.position.set(-2.5, -0.05, this.trackLength / 2 - 50);
        leftRail.castShadow = true;
        this.scene.add(leftRail);
        
        // Right rail
        const rightRail = new THREE.Mesh(railGeometry, railMaterial);
        rightRail.position.set(2.5, -0.05, this.trackLength / 2 - 50);
        rightRail.castShadow = true;
        this.scene.add(rightRail);
    }

    /**
     * Create rail ties
     */
    createRailTies() {
        const tieGeometry = new THREE.BoxGeometry(5, 0.2, 0.4);
        const tieMaterial = new THREE.MeshLambertMaterial({ color: 0x654321 });
        
        for (let i = 0; i < 200; i++) {
            const z = i * 2 + 5;
            const tie = new THREE.Mesh(tieGeometry, tieMaterial);
            tie.position.set(0, -0.1, z);
            tie.castShadow = true;
            this.scene.add(tie);
        }
    }

    /**
     * Create rail details
     */
    createRailDetails() {
        // Add rail connectors and details
        const connectorGeometry = new THREE.CylinderGeometry(0.1, 0.1, 0.5);
        const connectorMaterial = new THREE.MeshLambertMaterial({ color: 0x333333 });
        
        for (let i = 0; i < 50; i++) {
            const z = i * 10 + 10;
            
            // Connectors between rails
            for (let j = 0; j < 5; j++) {
                const x = -1.5 + j * 0.75;
                const connector = new THREE.Mesh(connectorGeometry, connectorMaterial);
                connector.position.set(x, -0.05, z);
                connector.rotation.z = Math.PI / 2;
                this.scene.add(connector);
            }
        }
    }

    /**
     * Create track details
     */
    createTrackDetails() {
        // Platform furniture
        this.createPlatformFurniture();
        this.createRailwaySigns();
    }

    /**
     * Create platform furniture
     */
    createPlatformFurniture() {
        // Benches
        this.createBenches();
        
        // Waste bins
        this.createWasteBins();
        
        // Information displays
        this.createInfoDisplays();
    }

    /**
     * Create benches
     */
    createBenches() {
        const benchGeometry = new THREE.BoxGeometry(2, 0.5, 0.4);
        const benchMaterial = new THREE.MeshLambertMaterial({ color: 0x8b4513 });
        
        for (let i = 0; i < 30; i++) {
            const z = i * 30 + 20;
            const x = Random.pick([-4, 4]);
            
            const bench = new THREE.Mesh(benchGeometry, benchMaterial);
            bench.position.set(x, 0.25, z);
            bench.castShadow = true;
            this.scene.add(bench);
            
            // Backrest
            const backrestGeometry = new THREE.BoxGeometry(2, 0.8, 0.1);
            const backrest = new THREE.Mesh(backrestGeometry, benchMaterial);
            backrest.position.set(x, 0.65, z - 0.25);
            this.scene.add(backrest);
        }
    }

    /**
     * Create waste bins
     */
    createWasteBins() {
        const binGeometry = new THREE.CylinderGeometry(0.3, 0.3, 1);
        const binMaterial = new THREE.MeshLambertMaterial({ color: 0x666666 });
        
        for (let i = 0; i < 50; i++) {
            const z = i * 20 + 15;
            const x = Random.pick([-5.5, 5.5]);
            
            const bin = new THREE.Mesh(binGeometry, binMaterial);
            bin.position.set(x, 0.5, z);
            bin.castShadow = true;
            this.scene.add(bin);
        }
    }

    /**
     * Create information displays
     */
    createInfoDisplays() {
        const displayGeometry = new THREE.BoxGeometry(1.5, 1, 0.1);
        const displayMaterial = new THREE.MeshBasicMaterial({
            color: 0x1e90ff,
            transparent: true,
            opacity: 0.8
        });
        
        for (let i = 0; i < 20; i++) {
            const z = i * 50 + 30;
            
            const display = new THREE.Mesh(displayGeometry, displayMaterial);
            display.position.set(-7.5, 2, z);
            this.scene.add(display);
            
            // Add screen content (simplified)
            const screenGeometry = new THREE.PlaneGeometry(1.3, 0.8);
            const screenMaterial = new THREE.MeshBasicMaterial({
                color: 0x000000,
                transparent: true,
                opacity: 0.9
            });
            const screen = new THREE.Mesh(screenGeometry, screenMaterial);
            screen.position.set(0, 0, 0.06);
            display.add(screen);
        }
    }

    /**
     * Create railway signs
     */
    createRailwaySigns() {
        const signGeometry = new THREE.BoxGeometry(0.1, 2, 1.5);
        const signMaterial = new THREE.MeshLambertMaterial({ color: 0xffffff });
        
        for (let i = 0; i < 25; i++) {
            const z = i * 40 + 25;
            
            const sign = new THREE.Mesh(signGeometry, signMaterial);
            sign.position.set(-7.5, 1, z);
            sign.castShadow = true;
            this.scene.add(sign);
            
            // Sign text area
            const textGeometry = new THREE.PlaneGeometry(1.3, 1.3);
            const textMaterial = new THREE.MeshBasicMaterial({
                color: 0x000000,
                transparent: true,
                opacity: 0.8
            });
            const textArea = new THREE.Mesh(textGeometry, textMaterial);
            textArea.position.set(0, 0, 0.06);
            sign.add(textArea);
        }
    }

    /**
     * Create buildings for background
     */
    createBuildings() {
        this.createBuildingSilhouettes();
        this.createDetailedBuildings();
    }

    /**
     * Create building silhouettes
     */
    createBuildingSilhouettes() {
        const buildingGeometry = new THREE.BoxGeometry(1, 1, 1);
        const buildingMaterial = new THREE.MeshLambertMaterial({
            color: 0x2c3e50,
            transparent: true,
            opacity: 0.3
        });
        
        for (let i = 0; i < 100; i++) {
            const height = Random.float(5, 30);
            const width = Random.float(3, 8);
            const depth = Random.float(8, 15);
            
            const building = new THREE.Mesh(buildingGeometry, buildingMaterial);
            building.scale.set(width, height, depth);
            building.position.set(
                Random.pick([-20, -15, 15, 20]),
                height / 2,
                i * 10 + 5
            );
            
            this.scene.add(building);
            this.buildings.push(building);
        }
    }

    /**
     * Create detailed buildings
     */
    createDetailedBuildings() {
        for (let i = 0; i < 20; i++) {
            this.createDetailedBuilding(i * 50 + 30);
        }
    }

    /**
     * Create a detailed building
     */
    createDetailedBuilding(z) {
        const baseHeight = 8;
        const sections = Random.int(2, 5);
        
        for (let section = 0; section < sections; section++) {
            const sectionHeight = Random.float(2, 4);
            const sectionWidth = Random.float(2, 4);
            
            const buildingGeometry = new THREE.BoxGeometry(sectionWidth, sectionHeight, 6);
            const buildingMaterial = new THREE.MeshLambertMaterial({
                color: Random.pick([0x34495e, 0x2c3e50, 0x1a252f])
            });
            
            const building = new THREE.Mesh(buildingGeometry, buildingMaterial);
            building.position.set(
                Random.pick([-18, -16, 16, 18]),
                baseHeight + section * sectionHeight + sectionHeight / 2,
                z
            );
            building.castShadow = true;
            this.scene.add(building);
            
            // Add windows
            this.addBuildingWindows(building, sectionWidth, sectionHeight);
        }
    }

    /**
     * Add windows to building
     */
    addBuildingWindows(building, width, height) {
        const windowGeometry = new THREE.PlaneGeometry(0.3, 0.4);
        const windowMaterial = new THREE.MeshBasicMaterial({
            color: 0x87ceeb,
            transparent: true,
            opacity: 0.6
        });
        
        const windowRows = Math.floor(height / 0.8);
        const windowCols = Math.floor(width / 0.6);
        
        for (let row = 0; row < windowRows; row++) {
            for (let col = 0; col < windowCols; col++) {
                const window = new THREE.Mesh(windowGeometry, windowMaterial);
                window.position.set(
                    -width / 2 + (col + 0.5) * (width / windowCols),
                    -height / 2 + (row + 0.5) * (height / windowRows),
                    0.31
                );
                building.add(window);
                
                // Random window lighting
                if (Random.boolean()) {
                    window.material.color.setHex(0xffff99);
                    window.material.opacity = 0.8;
                }
            }
        }
    }

    /**
     * Create trains
     */
    createTrains() {
        this.createBackgroundTrains();
    }

    /**
     * Create background trains
     */
    createBackgroundTrains() {
        for (let i = 0; i < 10; i++) {
            this.createTrain(i * 100 + 50, Random.pick([-20, 20]));
        }
    }

    /**
     * Create a train
     */
    createTrain(z, x) {
        const trainGroup = new THREE.Group();
        const carCount = Random.int(3, 6);
        
        for (let i = 0; i < carCount; i++) {
            const carGeometry = new THREE.BoxGeometry(3, 2.5, 1.5);
            const carMaterial = new THREE.MeshLambertMaterial({
                color: Random.pick([0xe74c3c, 0x3498db, 0x2ecc71, 0xf39c12])
            });
            
            const car = new THREE.Mesh(carGeometry, carMaterial);
            car.position.x = i * 3.5;
            car.castShadow = true;
            trainGroup.add(car);
            
            // Add windows to car
            this.addTrainWindows(car);
            
            // Add wheels
            this.addTrainWheels(car, i * 3.5);
        }
        
        trainGroup.position.set(x, 1.25, z);
        this.scene.add(trainGroup);
        this.trains.push(trainGroup);
    }

    /**
     * Add windows to train car
     */
    addTrainWindows(car) {
        const windowGeometry = new THREE.PlaneGeometry(0.4, 0.3);
        const windowMaterial = new THREE.MeshBasicMaterial({
            color: 0x87ceeb,
            transparent: true,
            opacity: 0.7
        });
        
        for (let i = 0; i < 6; i++) {
            const window = new THREE.Mesh(windowGeometry, windowMaterial);
            window.position.set(
                -1.2 + i * 0.4,
                0.5,
                0.76
            );
            car.add(window);
        }
    }

    /**
     * Add wheels to train car
     */
    addTrainWheels(car, xOffset) {
        const wheelGeometry = new THREE.CylinderGeometry(0.3, 0.3, 0.2);
        const wheelMaterial = new THREE.MeshLambertMaterial({ color: 0x333333 });
        
        const positions = [
            { x: -1, z: 0.6 },
            { x: 1, z: 0.6 },
            { x: -1, z: -0.6 },
            { x: 1, z: -0.6 }
        ];
        
        positions.forEach(pos => {
            const wheel = new THREE.Mesh(wheelGeometry, wheelMaterial);
            wheel.position.set(pos.x, -1, pos.z);
            wheel.rotation.z = Math.PI / 2;
            car.add(wheel);
        });
    }

    /**
     * Create decorations
     */
    createDecorations() {
        this.createPlants();
        this.createStreetFurniture();
    }

    /**
     * Create plants
     */
    createPlants() {
        for (let i = 0; i < 50; i++) {
            this.createPlant(i * 20 + 15);
        }
    }

    /**
     * Create a plant
     */
    createPlant(z) {
        const plantGroup = new THREE.Group();
        
        // Pot
        const potGeometry = new THREE.CylinderGeometry(0.3, 0.4, 0.4);
        const potMaterial = new THREE.MeshLambertMaterial({ color: 0x8b4513 });
        const pot = new THREE.Mesh(potGeometry, potMaterial);
        plantGroup.add(pot);
        
        // Plant
        const plantGeometry = new THREE.ConeGeometry(0.8, 2, 8);
        const plantMaterial = new THREE.MeshLambertMaterial({ color: 0x228b22 });
        const plant = new THREE.Mesh(plantGeometry, plantMaterial);
        plant.position.y = 1.2;
        plantGroup.add(plant);
        
        plantGroup.position.set(Random.pick([-5, 5]), 0.2, z);
        this.scene.add(plantGroup);
        this.decorations.push(plantGroup);
    }

    /**
     * Create street furniture
     */
    createStreetFurniture() {
        // Create lamp posts
        for (let i = 0; i < 30; i++) {
            const z = i * 35 + 25;
            const x = Random.pick([-7, 7]);
            this.createLampPost(x, z);
        }
    }

    /**
     * Create lamp post
     */
    createLampPost(x, z) {
        const postGroup = new THREE.Group();
        
        // Post
        const postGeometry = new THREE.CylinderGeometry(0.1, 0.1, 4);
        const postMaterial = new THREE.MeshLambertMaterial({ color: 0x333333 });
        const post = new THREE.Mesh(postGeometry, postMaterial);
        post.position.y = 2;
        postGroup.add(post);
        
        // Light fixture
        const fixtureGeometry = new THREE.SphereGeometry(0.3);
        const fixtureMaterial = new THREE.MeshBasicMaterial({
            color: 0xffffaa,
            transparent: true,
            opacity: 0.8
        });
        const fixture = new THREE.Mesh(fixtureGeometry, fixtureMaterial);
        fixture.position.y = 4.2;
        postGroup.add(fixture);
        
        postGroup.position.set(x, 0, z);
        this.scene.add(postGroup);
        
        // Add light
        const light = new THREE.PointLight(0xffffaa, 0.8, 8);
        light.position.set(x, 4.2, z);
        this.scene.add(light);
    }

    /**
     * Create atmospheric effects
     */
    createAtmosphericEffects() {
        this.createDustParticles();
        this.createSteam();
    }

    /**
     * Create dust particles
     */
    createDustParticles() {
        const particleCount = 100;
        const geometry = new THREE.BufferGeometry();
        const positions = new Float32Array(particleCount * 3);
        const velocities = new Float32Array(particleCount * 3);
        
        for (let i = 0; i < particleCount; i++) {
            const i3 = i * 3;
            positions[i3] = Random.float(-10, 10);
            positions[i3 + 1] = Random.float(0, 5);
            positions[i3 + 2] = Random.float(0, this.trackLength);
            
            velocities[i3] = Random.float(-0.1, 0.1);
            velocities[i3 + 1] = Random.float(0, 0.05);
            velocities[i3 + 2] = Random.float(-0.1, 0.1);
        }
        
        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geometry.setAttribute('velocity', new THREE.BufferAttribute(velocities, 3));
        
        const material = new THREE.PointsMaterial({
            color: 0xcccccc,
            size: 0.05,
            transparent: true,
            opacity: 0.6
        });
        
        const particles = new THREE.Points(geometry, material);
        this.scene.add(particles);
        
        this.particleSystems.push({
            system: particles,
            update: (deltaTime) => {
                const positions = particles.geometry.attributes.position.array;
                const velocities = particles.geometry.attributes.velocity.array;
                
                for (let i = 0; i < particleCount; i++) {
                    const i3 = i * 3;
                    
                    positions[i3] += velocities[i3] * deltaTime;
                    positions[i3 + 1] += velocities[i3 + 1] * deltaTime;
                    positions[i3 + 2] += velocities[i3 + 2] * deltaTime;
                    
                    // Reset particles that go too high
                    if (positions[i3 + 1] > 10) {
                        positions[i3 + 1] = 0;
                    }
                }
                
                particles.geometry.attributes.position.needsUpdate = true;
            }
        });
    }

    /**
     * Create steam effect
     */
    createSteam() {
        // Steam from train tracks
        for (let i = 0; i < 10; i++) {
            const steamGroup = new THREE.Group();
            const z = i * 100 + 50;
            
            for (let j = 0; j < 5; j++) {
                const steamGeometry = new THREE.SphereGeometry(0.5);
                const steamMaterial = new THREE.MeshBasicMaterial({
                    color: 0xcccccc,
                    transparent: true,
                    opacity: 0.3
                });
                
                const steam = new THREE.Mesh(steamGeometry, steamMaterial);
                steam.position.set(Random.float(-1, 1), 0, j * 2);
                steamGroup.add(steam);
            }
            
            steamGroup.position.set(0, 0.5, z);
            this.scene.add(steamGroup);
            
            this.particleSystems.push({
                system: steamGroup,
                update: (deltaTime) => {
                    steamGroup.children.forEach((steam, index) => {
                        steam.position.y += 0.5 * deltaTime;
                        steam.material.opacity -= 0.02 * deltaTime;
                        
                        if (steam.material.opacity <= 0) {
                            steam.material.opacity = 0.3;
                            steam.position.y = 0;
                        }
                    });
                }
            });
        }
    }

    /**
     * Update environment
     */
    update(deltaTime, playerPosition) {
        // Update particle systems
        this.particleSystems.forEach(particleSystem => {
            particleSystem.update(deltaTime);
        });
        
        // Update building animations
        this.updateBuildings(deltaTime);
        
        // Update train movements
        this.updateTrains(deltaTime);
        
        // Update atmospheric lighting
        this.updateLighting(deltaTime);
        
        // Update fog based on player speed
        this.updateFog(playerPosition);
    }

    /**
     * Update buildings
     */
    updateBuildings(deltaTime) {
        // Subtle building animations (flickering lights, etc.)
        this.buildings.forEach((building, index) => {
            // Random light flickering
            if (Math.random() < 0.001) {
                building.material.opacity = Random.float(0.2, 0.4);
            }
        });
    }

    /**
     * Update trains
     */
    updateTrains(deltaTime) {
        this.trains.forEach(train => {
            train.position.z -= 2 * deltaTime;
            
            // Reset train position when it goes off screen
            if (train.position.z < -50) {
                train.position.z = this.trackLength + 50;
            }
        });
    }

    /**
     * Update lighting
     */
    updateLighting(deltaTime) {
        // Animate light intensities
        this.lights.forEach((lightData, index) => {
            if (index < 20) {
                // Track lights - subtle pulsing
                const intensity = 0.3 + Math.sin(Date.now() * 0.001 + index) * 0.1;
                lightData.light.intensity = intensity;
                lightData.bulb.material.opacity = intensity;
            }
        });
    }

    /**
     * Update fog
     */
    updateFog(playerPosition) {
        if (!this.fog) return;
        
        // Adjust fog based on speed
        const speedFactor = Math.min(playerPosition.speed / 10, 1);
        this.fog.near = 20 + speedFactor * 10;
        this.fog.far = 200 + speedFactor * 50;
    }

    /**
     * Set environment speed
     */
    setSpeed(speed) {
        this.environmentSpeed = speed;
    }

    /**
     * Get environment bounds
     */
    getBounds() {
        return {
            width: this.laneWidth * 3,
            height: 10,
            length: this.trackLength,
            groundY: this.groundY
        };
    }

    /**
     * Check if object should be visible
     */
    isObjectVisible(object, playerZ) {
        const distance = Math.abs(object.position.z - playerZ);
        return distance < 100; // Render objects within 100 units
    }

    /**
     * Dispose environment
     */
    dispose() {
        // Remove all objects
        this.objects.forEach(object => {
            if (object.parent) {
                object.parent.remove(object);
            }
        });
        
        // Dispose geometries and materials
        this.scene.traverse((object) => {
            if (object.geometry) {
                object.geometry.dispose();
            }
            if (object.material) {
                if (Array.isArray(object.material)) {
                    object.material.forEach(material => material.dispose());
                } else {
                    object.material.dispose();
                }
            }
        });
        
        this.isLoaded = false;
        DebugUtils.log('Environment disposed');
    }

    /**
     * Get environment info
     */
    getInfo() {
        return {
            isLoaded: this.isLoaded,
            bounds: this.getBounds(),
            buildingCount: this.buildings.length,
            trainCount: this.trains.length,
            decorationCount: this.decorations.length,
            lightCount: this.lights.length,
            particleSystemCount: this.particleSystems.length
        };
    }
}

// Export for use in other modules
window.Environment = Environment;