// Obstacle system for the game

class ObstacleManager {
    constructor(scene) {
        this.scene = scene;
        this.obstacles = [];
        this.activeObstacles = new Map();
        this.obstacleTypes = {
            barrier: this.createBarrier,
            train: this.createTrainObstacle,
            gap: this.createGap,
            overhead: this.createOverheadObstacle,
            moving: this.createMovingObstacle,
            rotating: this.createRotatingObstacle
        };
        
        this.pool = {
            barrier: [],
            train: [],
            gap: [],
            overhead: [],
            moving: [],
            rotating: []
        };
        
        // Animation properties
        this.animatingObstacles = new Set();
        
        this.init();
    }

    /**
     * Initialize obstacle manager
     */
    init() {
        DebugUtils.log('Obstacle manager initialized');
    }

    /**
     * Create obstacle
     */
    createObstacle(type, position, options = {}) {
        const createFunction = this.obstacleTypes[type];
        if (!createFunction) {
            console.warn(`Unknown obstacle type: ${type}`);
            return null;
        }
        
        const obstacle = createFunction.call(this, position, options);
        if (obstacle) {
            this.obstacles.push(obstacle);
            this.activeObstacles.set(obstacle.id, obstacle);
            
            // Add to scene
            this.scene.add(obstacle.mesh);
            
            // Add physics if needed
            if (obstacle.physics) {
                physicsEngine.addBody(obstacle.id, obstacle.mesh, obstacle.physics);
            }
            
            DebugUtils.log(`Created ${type} obstacle at`, position);
        }
        
        return obstacle;
    }

    /**
     * Create barrier obstacle
     */
    createBarrier(position, options = {}) {
        const width = options.width || 2;
        const height = options.height || 2;
        const depth = options.depth || 0.5;
        
        const geometry = new THREE.BoxGeometry(width, height, depth);
        const material = new THREE.MeshLambertMaterial({ 
            color: options.color || 0xe74c3c,
            transparent: true,
            opacity: 0.9
        });
        
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.copy(position);
        mesh.castShadow = true;
        
        const obstacle = {
            id: `barrier_${Date.now()}_${Math.random()}`,
            type: 'barrier',
            mesh: mesh,
            position: position.clone(),
            physics: {
                mass: 0,
                material: 'obstacle',
                position: { x: position.x, y: position.y, z: position.z }
            },
            isActive: true,
            damage: options.damage || 1,
            animation: null
        };
        
        // Add warning animation
        this.addWarningEffect(obstacle);
        
        return obstacle;
    }

    /**
     * Create train obstacle
     */
    createTrainObstacle(position, options = {}) {
        const carCount = options.carCount || Random.int(2, 4);
        const group = new THREE.Group();
        
        for (let i = 0; i < carCount; i++) {
            const carGeometry = new THREE.BoxGeometry(2.5, 2.5, 4);
            const carMaterial = new THREE.MeshLambertMaterial({
                color: options.color || Random.pick([0x34495e, 0x2c3e50, 0x1a252f])
            });
            
            const car = new THREE.Mesh(carGeometry, carMaterial);
            car.position.x = i * 3;
            car.castShadow = true;
            
            // Add windows
            this.addTrainWindows(car);
            
            // Add wheels
            this.addTrainWheels(car, i * 3);
            
            group.add(car);
        }
        
        group.position.copy(position);
        
        const obstacle = {
            id: `train_${Date.now()}_${Math.random()}`,
            type: 'train',
            mesh: group,
            position: position.clone(),
            physics: {
                mass: 0,
                material: 'obstacle',
                position: { x: position.x, y: position.y, z: position.z }
            },
            isActive: true,
            damage: options.damage || 2,
            animation: null,
            speed: options.speed || 2,
            direction: options.direction || 1
        };
        
        // Add movement animation
        this.addTrainMovement(obstacle);
        
        return obstacle;
    }

    /**
     * Create gap obstacle
     */
    createGap(position, options = {}) {
        const width = options.width || this.trackWidth || 9;
        const depth = options.depth || 3;
        
        // Create invisible collision area
        const geometry = new THREE.BoxGeometry(width, 1, depth);
        const material = new THREE.MeshBasicMaterial({ 
            color: 0x000000,
            transparent: true,
            opacity: 0.1
        });
        
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.copy(position);
        mesh.position.y = -0.5; // Hidden below ground
        mesh.visible = false; // Invisible
        
        const obstacle = {
            id: `gap_${Date.now()}_${Math.random()}`,
            type: 'gap',
            mesh: mesh,
            position: position.clone(),
            physics: null, // No physics, handled by player falling
            isActive: true,
            damage: 999, // Instant death
            animation: null,
            width: width,
            depth: depth
        };
        
        // Add warning signs
        this.addGapWarning(obstacle);
        
        return obstacle;
    }

    /**
     * Create overhead obstacle
     */
    createOverheadObstacle(position, options = {}) {
        const width = options.width || (this.trackWidth || 9);
        const height = options.height || 1.5;
        const depth = options.depth || 2;
        
        const geometry = new THREE.BoxGeometry(width, 0.3, depth);
        const material = new THREE.MeshLambertMaterial({
            color: options.color || 0xe67e22,
            transparent: true,
            opacity: 0.8
        });
        
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.copy(position);
        mesh.castShadow = true;
        
        const obstacle = {
            id: `overhead_${Date.now()}_${Math.random()}`,
            type: 'overhead',
            mesh: mesh,
            position: position.clone(),
            physics: {
                mass: 0,
                material: 'obstacle',
                position: { x: position.x, y: position.y, z: position.z }
            },
            isActive: true,
            damage: options.damage || 1,
            animation: null,
            requiredSlide: true
        };
        
        // Add warning effect
        this.addOverheadWarning(obstacle);
        
        return obstacle;
    }

    /**
     * Create moving obstacle
     */
    createMovingObstacle(position, options = {}) {
        const width = options.width || 2;
        const height = options.height || 2;
        const depth = options.depth || 0.5;
        
        const geometry = new THREE.BoxGeometry(width, height, depth);
        const material = new THREE.MeshLambertMaterial({ 
            color: options.color || 0x9b59b6
        });
        
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.copy(position);
        mesh.castShadow = true;
        
        const obstacle = {
            id: `moving_${Date.now()}_${Math.random()}`,
            type: 'moving',
            mesh: mesh,
            position: position.clone(),
            originalPosition: position.clone(),
            physics: {
                mass: 0,
                material: 'obstacle',
                position: { x: position.x, y: position.y, z: position.z }
            },
            isActive: true,
            damage: options.damage || 1,
            animation: null,
            movementPattern: options.movementPattern || 'horizontal',
            amplitude: options.amplitude || 2,
            speed: options.speed || 1,
            phase: Math.random() * Math.PI * 2
        };
        
        // Add movement animation
        this.addMovingAnimation(obstacle);
        
        return obstacle;
    }

    /**
     * Create rotating obstacle
     */
    createRotatingObstacle(position, options = {}) {
        const radius = options.radius || 2;
        const armCount = options.armCount || 3;
        
        const group = new THREE.Group();
        
        // Create rotating arms
        for (let i = 0; i < armCount; i++) {
            const angle = (i / armCount) * Math.PI * 2;
            const armGeometry = new THREE.BoxGeometry(radius * 1.5, 0.5, 0.5);
            const armMaterial = new THREE.MeshLambertMaterial({ color: 0xe74c3c });
            
            const arm = new THREE.Mesh(armGeometry, armMaterial);
            arm.position.x = Math.cos(angle) * radius;
            arm.position.z = Math.sin(angle) * radius;
            arm.rotation.y = angle;
            arm.castShadow = true;
            
            group.add(arm);
        }
        
        group.position.copy(position);
        
        const obstacle = {
            id: `rotating_${Date.now()}_${Math.random()}`,
            type: 'rotating',
            mesh: group,
            position: position.clone(),
            physics: {
                mass: 0,
                material: 'obstacle',
                position: { x: position.x, y: position.y, z: position.z }
            },
            isActive: true,
            damage: options.damage || 1,
            animation: null,
            rotationSpeed: options.rotationSpeed || 1,
            rotationAxis: options.rotationAxis || 'y'
        };
        
        // Add rotation animation
        this.addRotationAnimation(obstacle);
        
        return obstacle;
    }

    /**
     * Add windows to train car
     */
    addTrainWindows(car) {
        const windowGeometry = new THREE.PlaneGeometry(0.4, 0.3);
        const windowMaterial = new THREE.MeshBasicMaterial({
            color: 0x87ceeb,
            transparent: true,
            opacity: 0.7
        });
        
        for (let i = 0; i < 6; i++) {
            const window = new THREE.Mesh(windowGeometry, windowMaterial);
            window.position.set(
                -1.2 + i * 0.4,
                0.5,
                2.01
            );
            car.add(window);
        }
    }

    /**
     * Add wheels to train car
     */
    addTrainWheels(car, xOffset) {
        const wheelGeometry = new THREE.CylinderGeometry(0.3, 0.3, 0.2);
        const wheelMaterial = new THREE.MeshLambertMaterial({ color: 0x333333 });
        
        const positions = [
            { x: -1, z: 1.6 },
            { x: 1, z: 1.6 },
            { x: -1, z: -1.6 },
            { x: 1, z: -1.6 }
        ];
        
        positions.forEach(pos => {
            const wheel = new THREE.Mesh(wheelGeometry, wheelMaterial);
            wheel.position.set(pos.x, -1, pos.z);
            wheel.rotation.z = Math.PI / 2;
            car.add(wheel);
        });
    }

    /**
     * Add warning effect to obstacle
     */
    addWarningEffect(obstacle) {
        if (obstacle.mesh.material) {
            // Store original material
            obstacle.originalMaterial = obstacle.mesh.material.clone();
            
            // Add warning pulse
            const warningPulse = () => {
                if (obstacle.isActive && obstacle.mesh.material) {
                    const intensity = Math.sin(Date.now() * 0.005) * 0.3 + 0.7;
                    if (obstacle.mesh.material.emissive) {
                        obstacle.mesh.material.emissive.setHex(0xff0000);
                        obstacle.mesh.material.emissiveIntensity = intensity;
                    }
                    requestAnimationFrame(warningPulse);
                }
            };
            warningPulse();
        }
    }

    /**
     * Add train movement animation
     */
    addTrainMovement(obstacle) {
        const animateTrain = () => {
            if (obstacle.isActive) {
                obstacle.mesh.position.z += obstacle.direction * obstacle.speed * 0.016;
                
                // Reset position when out of bounds
                if (obstacle.mesh.position.z > 100 || obstacle.mesh.position.z < -100) {
                    obstacle.mesh.position.z = -obstacle.direction * 100;
                }
                
                requestAnimationFrame(animateTrain);
            }
        };
        animateTrain();
    }

    /**
     * Add gap warning signs
     */
    addGapWarning(obstacle) {
        const warningGeometry = new THREE.BoxGeometry(0.8, 1.5, 0.1);
        const warningMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });
        
        const warningPositions = [
            { x: -obstacle.width / 2 - 1, z: obstacle.depth / 2 + 1 },
            { x: obstacle.width / 2 + 1, z: obstacle.depth / 2 + 1 },
            { x: -obstacle.width / 2 - 1, z: -obstacle.depth / 2 - 1 },
            { x: obstacle.width / 2 + 1, z: -obstacle.depth / 2 - 1 }
        ];
        
        warningPositions.forEach(pos => {
            const warning = new THREE.Mesh(warningGeometry, warningMaterial);
            warning.position.set(pos.x, 0.75, pos.z);
            
            // Add exclamation mark
            const exclamationGeometry = new THREE.PlaneGeometry(0.5, 1);
            const exclamationMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff });
            const exclamation = new THREE.Mesh(exclamationGeometry, exclamationMaterial);
            exclamation.position.set(0, 0, 0.06);
            warning.add(exclamation);
            
            this.scene.add(warning);
        });
    }

    /**
     * Add overhead warning effect
     */
    addOverheadWarning(obstacle) {
        // Add warning lights
        const light1 = new THREE.PointLight(0xff6b35, 1, 5);
        const light2 = new THREE.PointLight(0xff6b35, 1, 5);
        
        light1.position.set(-obstacle.mesh.geometry.parameters.width / 2, obstacle.mesh.position.y + 1, obstacle.mesh.position.z);
        light2.position.set(obstacle.mesh.geometry.parameters.width / 2, obstacle.mesh.position.y + 1, obstacle.mesh.position.z);
        
        this.scene.add(light1);
        this.scene.add(light2);
        
        // Pulse warning lights
        const pulseLights = () => {
            if (obstacle.isActive) {
                const intensity = Math.sin(Date.now() * 0.01) * 0.5 + 0.5;
                light1.intensity = intensity;
                light2.intensity = intensity;
                requestAnimationFrame(pulseLights);
            }
        };
        pulseLights();
    }

    /**
     * Add moving animation
     */
    addMovingAnimation(obstacle) {
        const animateMovement = () => {
            if (obstacle.isActive) {
                const time = Date.now() * 0.001 * obstacle.speed + obstacle.phase;
                
                switch (obstacle.movementPattern) {
                    case 'horizontal':
                        obstacle.mesh.position.x = obstacle.originalPosition.x + Math.sin(time) * obstacle.amplitude;
                        break;
                    case 'vertical':
                        obstacle.mesh.position.y = obstacle.originalPosition.y + Math.sin(time) * obstacle.amplitude;
                        break;
                    case 'diagonal':
                        obstacle.mesh.position.x = obstacle.originalPosition.x + Math.sin(time) * obstacle.amplitude;
                        obstacle.mesh.position.y = obstacle.originalPosition.y + Math.cos(time) * obstacle.amplitude;
                        break;
                    case 'circular':
                        obstacle.mesh.position.x = obstacle.originalPosition.x + Math.cos(time) * obstacle.amplitude;
                        obstacle.mesh.position.z = obstacle.originalPosition.z + Math.sin(time) * obstacle.amplitude;
                        break;
                }
                
                requestAnimationFrame(animateMovement);
            }
        };
        animateMovement();
    }

    /**
     * Add rotation animation
     */
    addRotationAnimation(obstacle) {
        const animateRotation = () => {
            if (obstacle.isActive) {
                const time = Date.now() * 0.001 * obstacle.rotationSpeed;
                
                switch (obstacle.rotationAxis) {
                    case 'x':
                        obstacle.mesh.rotation.x = time;
                        break;
                    case 'y':
                        obstacle.mesh.rotation.y = time;
                        break;
                    case 'z':
                        obstacle.mesh.rotation.z = time;
                        break;
                }
                
                requestAnimationFrame(animateRotation);
            }
        };
        animateRotation();
    }

    /**
     * Update obstacles
     */
    update(deltaTime) {
        // Update animated obstacles
        this.animatingObstacles.forEach(obstacleId => {
            const obstacle = this.activeObstacles.get(obstacleId);
            if (obstacle && obstacle.animation) {
                obstacle.animation.update(deltaTime);
            }
        });
        
        // Remove obstacles that are too far behind player
        const playerZ = window.game?.player?.group?.position?.z || 0;
        const removeThreshold = playerZ - 50;
        
        this.obstacles = this.obstacles.filter(obstacle => {
            if (obstacle.position.z < removeThreshold) {
                this.removeObstacle(obstacle);
                return false;
            }
            return true;
        });
    }

    /**
     * Remove obstacle
     */
    removeObstacle(obstacle) {
        if (obstacle.mesh.parent) {
            obstacle.mesh.parent.remove(obstacle.mesh);
        }
        
        if (obstacle.physics) {
            physicsEngine.removeBody(obstacle.id);
        }
        
        this.activeObstacles.delete(obstacle.id);
        this.animatingObstacles.delete(obstacle.id);
        
        DebugUtils.log(`Removed obstacle: ${obstacle.type}`);
    }

    /**
     * Check collision with player
     */
    checkCollision(player, obstacle) {
        if (!obstacle.isActive) return false;
        
        const playerPos = player.group.position;
        const obstaclePos = obstacle.mesh.position;
        const distance = Vector3Utils.distance(playerPos, obstaclePos);
        
        switch (obstacle.type) {
            case 'barrier':
            case 'train':
            case 'moving':
            case 'rotating':
                return distance < 1.5; // Collision radius
                
            case 'gap':
                // Check if player is over the gap
                const gapHalfWidth = obstacle.width / 2;
                const gapHalfDepth = obstacle.depth / 2;
                return Math.abs(playerPos.x - obstaclePos.x) < gapHalfWidth &&
                       Math.abs(playerPos.z - obstaclePos.z) < gapHalfDepth;
                
            case 'overhead':
                // Check if player is at the right height
                const overheadBottom = obstaclePos.y - 0.15;
                const playerTop = playerPos.y + 1; // Approximate player height
                return Math.abs(playerPos.z - obstaclePos.z) < 1 &&
                       playerTop > overheadBottom;
        }
        
        return false;
    }

    /**
     * Handle obstacle collision
     */
    handleCollision(player, obstacle) {
        DebugUtils.log(`Player hit ${obstacle.type} obstacle`);
        
        switch (obstacle.type) {
            case 'gap':
                // Player falls
                player.die();
                this.createFallEffect(player.group.position);
                break;
                
            case 'overhead':
                // Player needs to slide
                if (!player.isSliding) {
                    player.takeDamage();
                    this.createCollisionEffect(obstacle.mesh.position);
                }
                break;
                
            default:
                // Standard obstacle collision
                player.takeDamage();
                this.createCollisionEffect(obstacle.mesh.position);
                
                // Destroy obstacle after collision
                obstacle.isActive = false;
                setTimeout(() => {
                    this.removeObstacle(obstacle);
                }, 100);
                break;
        }
    }

    /**
     * Create collision effect
     */
    createCollisionEffect(position) {
        const effectGeometry = new THREE.SphereGeometry(1);
        const effectMaterial = new THREE.MeshBasicMaterial({
            color: 0xff0000,
            transparent: true,
            opacity: 0.8
        });
        
        const effect = new THREE.Mesh(effectGeometry, effectMaterial);
        effect.position.copy(position);
        
        this.scene.add(effect);
        
        // Screen shake
        document.body.classList.add('screen-shake');
        setTimeout(() => {
            document.body.classList.remove('screen-shake');
        }, 500);
        
        // Animate effect
        const animateEffect = () => {
            effect.scale.multiplyScalar(1.1);
            effect.material.opacity -= 0.02;
            
            if (effect.material.opacity > 0) {
                requestAnimationFrame(animateEffect);
            } else {
                if (effect.parent) {
                    effect.parent.remove(effect);
                }
            }
        };
        
        animateEffect();
    }

    /**
     * Create fall effect
     */
    createFallEffect(position) {
        // Create falling particles
        for (let i = 0; i < 10; i++) {
            const particle = new THREE.Mesh(
                new THREE.SphereGeometry(0.2),
                new THREE.MeshBasicMaterial({ color: 0x87ceeb })
            );
            
            particle.position.copy(position);
            particle.userData.velocity = new THREE.Vector3(
                (Math.random() - 0.5) * 2,
                Math.random() * 2,
                (Math.random() - 0.5) * 2
            );
            
            this.scene.add(particle);
            
            // Animate particle
            const animateParticle = () => {
                particle.position.add(particle.userData.velocity);
                particle.userData.velocity.y -= 9.8 * 0.016;
                particle.material.opacity -= 0.01;
                
                if (particle.material.opacity > 0) {
                    requestAnimationFrame(animateParticle);
                } else {
                    if (particle.parent) {
                        particle.parent.remove(particle);
                    }
                }
            };
            
            animateParticle();
        }
    }

    /**
     * Create obstacle pattern
     */
    createObstaclePattern(patternType, startPosition, options = {}) {
        const patterns = {
            zigzag: this.createZigzagPattern,
            staircase: this.createStaircasePattern,
            wave: this.createWavePattern,
            random: this.createRandomPattern
        };
        
        const patternFunction = patterns[patternType];
        if (patternFunction) {
            patternFunction.call(this, startPosition, options);
        }
    }

    /**
     * Create zigzag pattern
     */
    createZigzagPattern(startPosition, options = {}) {
        const segments = options.segments || 5;
        const spacing = options.spacing || 10;
        const laneWidth = options.laneWidth || 3;
        
        for (let i = 0; i < segments; i++) {
            const lane = i % 2 === 0 ? -1 : 1;
            const x = lane * laneWidth;
            const z = startPosition.z + i * spacing;
            const position = new THREE.Vector3(x, 0, z);
            
            this.createObstacle('barrier', position, options);
        }
    }

    /**
     * Create staircase pattern
     */
    createStaircasePattern(startPosition, options = {}) {
        const steps = options.steps || 4;
        const spacing = options.spacing || 8;
        
        for (let i = 0; i < steps; i++) {
            const x = -i * 1.5; // Move left each step
            const z = startPosition.z + i * spacing;
            const position = new THREE.Vector3(x, 0, z);
            
            this.createObstacle('barrier', position, options);
        }
    }

    /**
     * Create wave pattern
     */
    createWavePattern(startPosition, options = {}) {
        const waves = options.waves || 3;
        const pointsPerWave = options.pointsPerWave || 5;
        const spacing = options.spacing || 6;
        
        for (let wave = 0; wave < waves; wave++) {
            for (let i = 0; i < pointsPerWave; i++) {
                const t = i / (pointsPerWave - 1);
                const x = Math.sin(t * Math.PI * 2) * 2;
                const z = startPosition.z + wave * 30 + i * spacing;
                const position = new THREE.Vector3(x, 0, z);
                
                this.createObstacle('moving', position, {
                    ...options,
                    movementPattern: 'vertical',
                    amplitude: 1,
                    speed: 2
                });
            }
        }
    }

    /**
     * Create random pattern
     */
    createRandomPattern(startPosition, options = {}) {
        const count = options.count || 8;
        const spacing = options.spacing || 8;
        
        for (let i = 0; i < count; i++) {
            const x = Random.pick([-3, 0, 3]);
            const z = startPosition.z + i * spacing;
            const position = new THREE.Vector3(x, 0, z);
            const type = Random.pick(['barrier', 'moving', 'overhead']);
            
            this.createObstacle(type, position, options);
        }
    }

    /**
     * Clear all obstacles
     */
    clear() {
        this.obstacles.forEach(obstacle => {
            this.removeObstacle(obstacle);
        });
        
        this.obstacles = [];
        this.activeObstacles.clear();
        this.animatingObstacles.clear();
        
        // Clear object pools
        Object.keys(this.pool).forEach(type => {
            this.pool[type] = [];
        });
    }

    /**
     * Get obstacle count by type
     */
    getObstacleCountByType() {
        const counts = {};
        this.obstacles.forEach(obstacle => {
            counts[obstacle.type] = (counts[obstacle.type] || 0) + 1;
        });
        return counts;
    }

    /**
     * Get obstacle info
     */
    getInfo() {
        return {
            totalObstacles: this.obstacles.length,
            activeObstacles: this.activeObstacles.size,
            animatingObstacles: this.animatingObstacles.size,
            countsByType: this.getObstacleCountByType()
        };
    }
}

// Export for use in other modules
window.ObstacleManager = ObstacleManager;