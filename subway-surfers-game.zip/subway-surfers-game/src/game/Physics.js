// Physics engine for the game using Cannon.js

class PhysicsEngine {
    constructor() {
        this.world = null;
        this.objects = new Map();
        this.isRunning = false;
        this.fixedTimeStep = 1 / 60;
        this.maxSubSteps = 3;
        
        this.gravity = new CANNON.Vec3(0, -9.82, 0);
        this.enabled = true;
        
        this.init();
    }

    /**
     * Initialize physics world
     */
    init() {
        try {
            // Create physics world
            this.world = new CANNON.World();
            this.world.gravity = this.gravity;
            this.world.broadphase = new CANNON.SAPBroadphase(this.world);
            this.world.allowSleep = true;
            
            // Configure solver
            this.world.solver.iterations = 10;
            this.world.solver.tolerance = 0.1;
            
            // Add default materials
            this.setupDefaultMaterials();
            
            DebugUtils.log('Physics engine initialized');
        } catch (error) {
            console.error('Failed to initialize physics engine:', error);
            this.enabled = false;
        }
    }

    /**
     * Setup default physics materials
     */
    setupDefaultMaterials() {
        // Create default materials
        this.materials = {
            default: new CANNON.Material('default'),
            player: new CANNON.Material('player'),
            obstacle: new CANNON.Material('obstacle'),
            ground: new CANNON.Material('ground'),
            coin: new CANNON.Material('coin'),
            powerup: new CANNON.Material('powerup')
        };

        // Create contact materials
        this.world.defaultContactMaterial = new CANNON.ContactMaterial(
            this.materials.default,
            this.materials.default,
            {
                friction: 0.4,
                restitution: 0.3
            }
        );

        // Player vs ground
        this.world.addContactMaterial(new CANNON.ContactMaterial(
            this.materials.player,
            this.materials.ground,
            {
                friction: 0.1,
                restitution: 0.1
            }
        ));

        // Player vs obstacle
        this.world.addContactMaterial(new CANNON.ContactMaterial(
            this.materials.player,
            this.materials.obstacle,
            {
                friction: 0.2,
                restitution: 0.1
            }
        ));

        // Coin collisions (no collision)
        this.world.addContactMaterial(new CANNON.ContactMaterial(
            this.materials.coin,
            this.materials.default,
            {
                friction: 0.0,
                restitution: 0.0
            }
        ));
    }

    /**
     * Start physics simulation
     */
    start() {
        this.isRunning = true;
        DebugUtils.log('Physics simulation started');
    }

    /**
     * Stop physics simulation
     */
    stop() {
        this.isRunning = false;
        DebugUtils.log('Physics simulation stopped');
    }

    /**
     * Update physics simulation
     */
    update(deltaTime) {
        if (!this.enabled || !this.isRunning) return;
        
        // Step physics world
        this.world.step(this.fixedTimeStep, deltaTime, this.maxSubSteps);
        
        // Update Three.js objects with physics body positions
        this.syncObjects();
    }

    /**
     * Sync physics bodies with Three.js objects
     */
    syncObjects() {
        this.objects.forEach((physicsData, objectId) => {
            const { threeObject, body } = physicsData;
            
            if (threeObject && body) {
                threeObject.position.copy(body.position);
                threeObject.quaternion.copy(body.quaternion);
            }
        });
    }

    /**
     * Add physics body to object
     */
    addBody(objectId, threeObject, bodyOptions) {
        if (!this.enabled || !threeObject) return null;

        try {
            // Create physics body based on geometry
            const body = this.createBody(threeObject, bodyOptions);
            if (!body) return null;

            // Add to physics world
            this.world.addBody(body);
            
            // Store mapping
            this.objects.set(objectId, {
                threeObject: threeObject,
                body: body,
                bodyOptions: bodyOptions
            });

            DebugUtils.log(`Physics body added for object: ${objectId}`);
            return body;
        } catch (error) {
            console.error(`Failed to add physics body for ${objectId}:`, error);
            return null;
        }
    }

    /**
     * Create physics body from Three.js object
     */
    createBody(threeObject, options = {}) {
        const geometry = threeObject.geometry;
        const material = threeObject.material;
        
        if (!geometry) {
            console.warn('Object has no geometry for physics body');
            return null;
        }

        // Get material type
        const materialType = options.material || 'default';
        const physicsMaterial = this.materials[materialType] || this.materials.default;

        // Create body based on geometry type
        let body = null;

        if (geometry instanceof THREE.BoxGeometry || geometry instanceof THREE.BoxBufferGeometry) {
            // Box shape
            const parameters = geometry.parameters;
            const halfExtents = new CANNON.Vec3(
                parameters.width / 2,
                parameters.height / 2,
                parameters.depth / 2
            );
            
            body = new CANNON.Body({
                mass: options.mass !== undefined ? options.mass : 0,
                material: physicsMaterial
            });
            body.addShape(new CANNON.Box(halfExtents));

        } else if (geometry instanceof THREE.SphereGeometry || geometry instanceof THREE.SphereBufferGeometry) {
            // Sphere shape
            const parameters = geometry.parameters;
            
            body = new CANNON.Body({
                mass: options.mass !== undefined ? options.mass : 0,
                material: physicsMaterial
            });
            body.addShape(new CANNON.Sphere(parameters.radius));

        } else if (geometry instanceof THREE.CylinderGeometry || geometry instanceof THREE.CylinderBufferGeometry) {
            // Cylinder shape
            const parameters = geometry.parameters;
            
            body = new CANNON.Body({
                mass: options.mass !== undefined ? options.mass : 0,
                material: physicsMaterial
            });
            body.addShape(new CANNON.Cylinder(parameters.radiusTop, parameters.radiusBottom, parameters.height, 8));

        } else if (geometry instanceof THREE.PlaneGeometry || geometry instanceof THREE.PlaneBufferGeometry) {
            // Plane shape
            body = new CANNON.Body({
                mass: options.mass !== undefined ? options.mass : 0,
                material: physicsMaterial
            });
            body.addShape(new CANNON.Plane());

        } else {
            // Default to box with approximate dimensions
            const boundingBox = new THREE.Box3().setFromObject(threeObject);
            const size = new THREE.Vector3();
            boundingBox.getSize(size);

            const halfExtents = new CANNON.Vec3(
                size.x / 2 || 0.5,
                size.y / 2 || 0.5,
                size.z / 2 || 0.5
            );

            body = new CANNON.Body({
                mass: options.mass !== undefined ? options.mass : 0,
                material: physicsMaterial
            });
            body.addShape(new CANNON.Box(halfExtents));
        }

        // Set initial position and rotation
        body.position.copy(threeObject.position);
        body.quaternion.copy(threeObject.quaternion);

        // Set physics properties
        if (options.mass !== undefined) {
            body.mass = options.mass;
        }
        
        if (options.position) {
            body.position.set(options.position.x, options.position.y, options.position.z);
        }
        
        if (options.rotation) {
            body.quaternion.setFromEuler(options.rotation.x, options.rotation.y, options.rotation.z);
        }

        if (options.fixedRotation !== undefined) {
            body.fixedRotation = options.fixedRotation;
        }

        if (options.linearDamping !== undefined) {
            body.linearDamping = options.linearDamping;
        }

        if (options.angularDamping !== undefined) {
            body.angularDamping = options.angularDamping;
        }

        if (options.sleepSpeedLimit !== undefined) {
            body.sleepSpeedLimit = options.sleepSpeedLimit;
        }

        if (options.sleepTimeLimit !== undefined) {
            body.sleepTimeLimit = options.sleepTimeLimit;
        }

        return body;
    }

    /**
     * Remove physics body
     */
    removeBody(objectId) {
        const physicsData = this.objects.get(objectId);
        if (physicsData && physicsData.body) {
            this.world.removeBody(physicsData.body);
            this.objects.delete(objectId);
            DebugUtils.log(`Physics body removed for object: ${objectId}`);
        }
    }

    /**
     * Apply force to body
     */
    applyForce(objectId, force, point = null) {
        const physicsData = this.objects.get(objectId);
        if (physicsData && physicsData.body) {
            const body = physicsData.body;
            
            if (point) {
                body.applyForce(new CANNON.Vec3(force.x, force.y, force.z), new CANNON.Vec3(point.x, point.y, point.z));
            } else {
                body.applyForce(new CANNON.Vec3(force.x, force.y, force.z), body.position);
            }
        }
    }

    /**
     * Apply impulse to body
     */
    applyImpulse(objectId, impulse, point = null) {
        const physicsData = this.objects.get(objectId);
        if (physicsData && physicsData.body) {
            const body = physicsData.body;
            
            if (point) {
                body.applyImpulse(new CANNON.Vec3(impulse.x, impulse.y, impulse.z), new CANNON.Vec3(point.x, point.y, point.z));
            } else {
                body.applyImpulse(new CANNON.Vec3(impulse.x, impulse.y, impulse.z), body.position);
            }
        }
    }

    /**
     * Set body velocity
     */
    setVelocity(objectId, velocity) {
        const physicsData = this.objects.get(objectId);
        if (physicsData && physicsData.body) {
            physicsData.body.velocity.set(velocity.x, velocity.y, velocity.z);
        }
    }

    /**
     * Get body velocity
     */
    getVelocity(objectId) {
        const physicsData = this.objects.get(objectId);
        if (physicsData && physicsData.body) {
            return {
                x: physicsData.body.velocity.x,
                y: physicsData.body.velocity.y,
                z: physicsData.body.velocity.z
            };
        }
        return { x: 0, y: 0, z: 0 };
    }

    /**
     * Set body position
     */
    setPosition(objectId, position) {
        const physicsData = this.objects.get(objectId);
        if (physicsData && physicsData.body) {
            physicsData.body.position.set(position.x, position.y, position.z);
        }
    }

    /**
     * Set body rotation
     */
    setRotation(objectId, rotation) {
        const physicsData = this.objects.get(objectId);
        if (physicsData && physicsData.body) {
            physicsData.body.quaternion.setFromEuler(rotation.x, rotation.y, rotation.z);
        }
    }

    /**
     * Check collision between two objects
     */
    checkCollision(objectId1, objectId2) {
        const data1 = this.objects.get(objectId1);
        const data2 = this.objects.get(objectId2);
        
        if (!data1 || !data2 || !data1.body || !data2.body) {
            return false;
        }

        // Simple AABB collision check
        const pos1 = data1.body.position;
        const pos2 = data2.body.position;
        const size1 = this.getObjectSize(objectId1);
        const size2 = this.getObjectSize(objectId2);

        return (
            Math.abs(pos1.x - pos2.x) < (size1.x + size2.x) / 2 &&
            Math.abs(pos1.y - pos2.y) < (size1.y + size2.y) / 2 &&
            Math.abs(pos1.z - pos2.z) < (size1.z + size2.z) / 2
        );
    }

    /**
     * Get object size for collision detection
     */
    getObjectSize(objectId) {
        const physicsData = this.objects.get(objectId);
        if (physicsData && physicsData.threeObject) {
            const boundingBox = new THREE.Box3().setFromObject(physicsData.threeObject);
            const size = new THREE.Vector3();
            boundingBox.getSize(size);
            return size;
        }
        return { x: 1, y: 1, z: 1 };
    }

    /**
     * Enable/disable gravity
     */
    setGravity(gravity) {
        if (typeof gravity === 'number') {
            this.world.gravity.set(0, -gravity, 0);
        } else {
            this.world.gravity.set(gravity.x, gravity.y, gravity.z);
        }
    }

    /**
     * Raycast for object detection
     */
    raycast(from, to, options = {}) {
        const fromVec = new CANNON.Vec3(from.x, from.y, from.z);
        const toVec = new CANNON.Vec3(to.x, to.y, to.z);
        
        const result = new CANNON.RaycastResult();
        this.world.raycastClosest(fromVec, toVec, options, result);
        
        return result;
    }

    /**
     * Create ground plane
     */
    createGround(size = { width: 100, height: 100 }, position = { x: 0, y: 0, z: 0 }) {
        const groundMaterial = new CANNON.Material('ground');
        
        const groundShape = new CANNON.Plane();
        const groundBody = new CANNON.Body({
            mass: 0,
            material: groundMaterial
        });
        
        groundBody.addShape(groundShape);
        groundBody.quaternion.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), -Math.PI / 2);
        groundBody.position.set(position.x, position.y, position.z);
        
        this.world.addBody(groundBody);
        
        return groundBody;
    }

    /**
     * Create boundary walls
     */
    createBoundaries(bounds = { left: -10, right: 10, back: -50, front: 50 }) {
        // Left wall
        const leftWall = new CANNON.Body({ mass: 0 });
        leftWall.addShape(new CANNON.Plane());
        leftWall.position.set(bounds.left, 0, 0);
        leftWall.quaternion.setFromAxisAngle(new CANNON.Vec3(0, 0, 1), Math.PI / 2);
        this.world.addBody(leftWall);

        // Right wall
        const rightWall = new CANNON.Body({ mass: 0 });
        rightWall.addShape(new CANNON.Plane());
        rightWall.position.set(bounds.right, 0, 0);
        rightWall.quaternion.setFromAxisAngle(new CANNON.Vec3(0, 0, 1), -Math.PI / 2);
        this.world.addBody(rightWall);

        // Back wall
        const backWall = new CANNON.Body({ mass: 0 });
        backWall.addShape(new CANNON.Plane());
        backWall.position.set(0, 0, bounds.back);
        this.world.addBody(backWall);
    }

    /**
     * Get physics world info
     */
    getInfo() {
        return {
            isRunning: this.isRunning,
            enabled: this.enabled,
            objectCount: this.objects.size,
            gravity: {
                x: this.world.gravity.x,
                y: this.world.gravity.y,
                z: this.world.gravity.z
            },
            timeStep: this.fixedTimeStep,
            objects: Array.from(this.objects.keys())
        };
    }

    /**
     * Reset physics world
     */
    reset() {
        // Remove all bodies
        this.objects.forEach((data, objectId) => {
            if (data.body) {
                this.world.removeBody(data.body);
            }
        });
        this.objects.clear();
        
        // Recreate world
        this.init();
    }

    /**
     * Destroy physics engine
     */
    destroy() {
        this.stop();
        
        // Remove all bodies
        this.objects.forEach((data) => {
            if (data.body) {
                this.world.removeBody(data.body);
            }
        });
        
        this.objects.clear();
        this.world = null;
        
        DebugUtils.log('Physics engine destroyed');
    }
}

// Global physics engine instance
window.physicsEngine = new PhysicsEngine();

// Export for use in other modules
window.PhysicsEngine = PhysicsEngine;