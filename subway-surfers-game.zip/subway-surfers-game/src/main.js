// Main entry point for the game

// Global game instance
let game = null;

// Initialize game when DOM is loaded
document.addEventListener('DOMContentLoaded', async () => {
    try {
        DebugUtils.setEnabled(false); // Set to true for debugging
        
        console.log('🚀 Initializing Subway Surfers 3D...');
        
        // Initialize global systems
        await initializeGlobalSystems();
        
        // Create game instance
        game = new Game();
        
        // Make game globally available
        window.game = game;
        
        console.log('✅ Game initialized successfully!');
        
        // Handle page visibility changes
        handleVisibilityChange();
        
        // Handle page unload
        handlePageUnload();
        
    } catch (error) {
        console.error('❌ Failed to initialize game:', error);
        showInitializationError(error);
    }
});

/**
 * Initialize global systems
 */
async function initializeGlobalSystems() {
    console.log('🔧 Setting up global systems...');
    
    // Enable performance monitoring
    if (PerformanceUtils) {
        // Set up performance monitoring
        window.addEventListener('load', () => {
            const perfData = performance.getEntriesByType('navigation')[0];
            console.log(`📊 Page load time: ${perfData.loadEventEnd - perfData.loadEventStart}ms`);
        });
    }
    
    // Setup error handling
    setupErrorHandling();
    
    // Setup console enhancements
    setupConsoleEnhancements();
    
    console.log('✅ Global systems initialized');
}

/**
 * Setup error handling
 */
function setupErrorHandling() {
    // Global error handler
    window.addEventListener('error', (event) => {
        console.error('💥 Global error:', event.error);
        
        // Show user-friendly error message
        if (game && game.ui) {
            game.ui.showNotification('Bir hata oluştu. Sayfa yenilenecek...', 'error', 2000);
        }
        
        // Reload page after delay
        setTimeout(() => {
            window.location.reload();
        }, 3000);
    });
    
    // Unhandled promise rejection handler
    window.addEventListener('unhandledrejection', (event) => {
        console.error('💥 Unhandled promise rejection:', event.reason);
        event.preventDefault();
    });
    
    // WebGL context lost handler
    const canvas = document.getElementById('game-canvas');
    if (canvas) {
        canvas.addEventListener('webglcontextlost', (event) => {
            event.preventDefault();
            console.warn('⚠️ WebGL context lost');
            
            if (game && game.ui) {
                game.ui.showNotification('Grafik bağlantısı kesildi. Yeniden bağlanıyor...', 'warning');
            }
        });
        
        canvas.addEventListener('webglcontextrestored', () => {
            console.log('✅ WebGL context restored');
            
            if (game && game.ui) {
                game.ui.showNotification('Grafik bağlantısı yenilendi!', 'success');
            }
        });
    }
}

/**
 * Setup console enhancements
 */
function setupConsoleEnhancements() {
    // Add game-specific console methods
    console.game = {
        info: () => console.log('🎮 Game Info:', game?.getInfo()),
        performance: () => {
            const perf = performance.getEntriesByType('navigation')[0];
            console.log('⚡ Performance:', {
                loadTime: perf.loadEventEnd - perf.loadEventStart,
                domContentLoaded: perf.domContentLoadedEventEnd - perf.domContentLoadedEventStart,
                memory: performance.memory ? {
                    used: Math.round(performance.memory.usedJSHeapSize / 1024 / 1024) + ' MB',
                    total: Math.round(performance.memory.totalJSHeapSize / 1024 / 1024) + ' MB'
                } : 'N/A'
            });
        },
        components: () => {
            console.log('🏗️ Game Components:', {
                scene: !!game?.scene,
                camera: !!game?.camera,
                renderer: !!game?.renderer,
                player: !!game?.player,
                environment: !!game?.environment,
                trackManager: !!game?.trackManager,
                obstacleManager: !!game?.obstacleManager,
                collectibleManager: !!game?.collectibleManager,
                ui: !!game?.ui,
                physics: !!window.physicsEngine,
                animations: !!window.animationManager,
                controls: !!window.controlsManager
            });
        },
        debug: (enabled = true) => {
            DebugUtils.setEnabled(enabled);
            console.log(`🐛 Debug mode: ${enabled ? 'enabled' : 'disabled'}`);
        }
    };
    
    // Add ASCII art
    console.log(`
    ╔══════════════════════════════════════╗
    ║         🚀 Subway Surfers 3D 🚀        ║
    ║                                      ║
    ║     3D Sonsuz Koşu Oyunu             ║
    ║     Three.js + Cannon.js             ║
    ║                                      ║
    ║  Konsol komutları:                   ║
    ║  • console.game.info()               ║
    ║  • console.game.performance()        ║
    ║  • console.game.components()         ║
    ║  • console.game.debug(true/false)    ║
    ╚══════════════════════════════════════╝
    `);
}

/**
 * Handle page visibility changes
 */
function handleVisibilityChange() {
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            // Page is hidden, pause game if running
            if (game && game.isRunning && !game.isPaused) {
                game.pause();
                console.log('⏸️ Game paused due to page visibility change');
            }
        } else {
            // Page is visible, resume if needed
            if (game && game.state === 'paused') {
                // Show notification to user
                if (game.ui) {
                    game.ui.showNotification('Oyun duraklatıldı. Devam etmek için tıklayın.', 'info');
                }
            }
        }
    });
}

/**
 * Handle page unload
 */
function handlePageUnload() {
    window.addEventListener('beforeunload', (event) => {
        if (game && game.isRunning) {
            // Save game state
            saveGameState();
            
            // Show confirmation dialog
            event.preventDefault();
            event.returnValue = 'Oyun devam ediyor. Çıkmak istediğinizden emin misiniz?';
            return event.returnValue;
        }
    });
    
    // Save game state periodically
    setInterval(() => {
        if (game && game.isRunning && !game.isPaused) {
            saveGameState();
        }
    }, 10000); // Save every 10 seconds
}

/**
 * Save current game state
 */
function saveGameState() {
    if (!game || !game.player) return;
    
    const gameState = {
        score: Math.floor(game.player.score),
        distance: game.player.distance,
        comboCount: game.player.comboCount,
        multiplier: game.player.multiplier,
        health: game.player.health,
        timestamp: Date.now()
    };
    
    StorageUtils.save('currentGameState', gameState);
}

/**
 * Load saved game state
 */
function loadGameState() {
    const savedState = StorageUtils.load('currentGameState');
    
    if (savedState && game && game.player) {
        // Check if save is recent (within 1 hour)
        const timeDiff = Date.now() - savedState.timestamp;
        if (timeDiff < 3600000) { // 1 hour in milliseconds
            return savedState;
        }
    }
    
    return null;
}

/**
 * Show initialization error
 */
function showInitializationError(error) {
    const errorContainer = document.createElement('div');
    errorContainer.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #101828 0%, #1D2939 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
        font-family: 'Arial', sans-serif;
        color: #F2F4F7;
    `;
    
    errorContainer.innerHTML = `
        <div style="text-align: center; max-width: 500px; padding: 40px;">
            <h1 style="font-size: 48px; margin-bottom: 20px; color: #FF8A24;">😵</h1>
            <h2 style="font-size: 24px; margin-bottom: 20px;">Oyun Yüklenemedi</h2>
            <p style="font-size: 16px; margin-bottom: 30px; line-height: 1.5; color: #98A2B3;">
                Oyun başlatılırken bir hata oluştu. Bu durumun nedenleri:
            </p>
            <ul style="text-align: left; margin-bottom: 30px; color: #98A2B3;">
                <li>Tarayıcınız WebGL'i desteklemiyor</li>
                <li>JavaScript devre dışı</li>
                <li>İnternet bağlantınız yavaş</li>
                <li>Tarayıcı önbelleği bozuk</li>
            </ul>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <button onclick="location.reload()" style="
                    padding: 12px 24px;
                    background: #FF8A24;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    font-size: 16px;
                    cursor: pointer;
                    transition: background 0.3s;
                " onmouseover="this.style.background='#E56A00'" onmouseout="this.style.background='#FF8A24'">
                    Tekrar Dene
                </button>
                <button onclick="clearCacheAndReload()" style="
                    padding: 12px 24px;
                    background: transparent;
                    color: #FF8A24;
                    border: 2px solid #FF8A24;
                    border-radius: 8px;
                    font-size: 16px;
                    cursor: pointer;
                    transition: all 0.3s;
                " onmouseover="this.style.background='#FF8A24'; this.style.color='white'" onmouseout="this.style.background='transparent'; this.style.color='#FF8A24'">
                    Önbelleği Temizle
                </button>
            </div>
            <p style="margin-top: 20px; font-size: 14px; color: #98A2B3;">
                Destek için tarayıcınızı güncellemeyi deneyin.
            </p>
        </div>
    `;
    
    document.body.appendChild(errorContainer);
    
    // Add clear cache function to global scope
    window.clearCacheAndReload = () => {
        if ('caches' in window) {
            caches.keys().then(names => {
                names.forEach(name => {
                    caches.delete(name);
                });
            });
        }
        localStorage.clear();
        sessionStorage.clear();
        location.reload();
    };
}

/**
 * Check system requirements
 */
function checkSystemRequirements() {
    const requirements = {
        webgl: !!window.WebGLRenderingContext,
        webgl2: !!window.WebGL2RenderingContext,
        canvas: !!document.createElement('canvas').getContext,
        es6: (() => {
            try {
                eval('class Test {}');
                return true;
            } catch (e) {
                return false;
            }
        })(),
        fetch: !!window.fetch,
        promises: !!window.Promise,
        localStorage: !!window.localStorage
    };
    
    const unsupported = Object.entries(requirements)
        .filter(([key, supported]) => !supported)
        .map(([key]) => key);
    
    if (unsupported.length > 0) {
        console.warn('⚠️ Unsupported features:', unsupported);
        return false;
    }
    
    return true;
}

/**
 * Optimize for mobile devices
 */
function optimizeForMobile() {
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    
    if (isMobile) {
        // Disable right-click context menu
        document.addEventListener('contextmenu', (e) => {
            e.preventDefault();
        });
        
        // Prevent pull-to-refresh
        document.addEventListener('touchmove', (e) => {
            if (e.touches.length > 1) {
                e.preventDefault();
            }
        }, { passive: false });
        
        // Optimize for touch
        document.body.style.touchAction = 'manipulation';
        
        console.log('📱 Mobile optimizations applied');
    }
    
    return isMobile;
}

// Initialize mobile optimizations
optimizeForMobile();

// Export main functions for global access
window.GameUtils = window.GameUtils || {};
window.initializeGame = () => {
    if (!game) {
        game = new Game();
        window.game = game;
    }
    return game;
};

window.disposeGame = () => {
    if (game) {
        game.dispose();
        game = null;
        window.game = null;
    }
};

// Make sure all systems are ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        console.log('📄 DOM Content Loaded');
    });
} else {
    console.log('📄 DOM already loaded');
}

console.log('🎮 Main script loaded successfully!');