// Touch and mouse controls for the game

class ControlsManager {
    constructor(canvas) {
        this.canvas = canvas;
        this.isEnabled = true;
        this.touchStart = null;
        this.touchEnd = null;
        this.mouseStart = null;
        this.mouseEnd = null;
        this.swipeThreshold = 50; // Minimum distance for swipe
        this.doubleTapThreshold = 300; // Time for double tap detection
        this.lastTapTime = 0;
        this.lastTapPosition = { x: 0, y: 0 };
        
        // Touch events
        this.touchStartEvent = this.onTouchStart.bind(this);
        this.touchMoveEvent = this.onTouchMove.bind(this);
        this.touchEndEvent = this.onTouchEnd.bind(this);
        
        // Mouse events
        this.mouseDownEvent = this.onMouseDown.bind(this);
        this.mouseMoveEvent = this.onMouseMove.bind(this);
        this.mouseUpEvent = this.onMouseUp.bind(this);
        this.wheelEvent = this.onWheel.bind(this);
        
        // Keyboard events
        this.keyDownEvent = this.onKeyDown.bind(this);
        this.keyUpEvent = this.onKeyUp.bind(this);
        
        // Game state
        this.gameState = null;
        this.controlCallbacks = {
            swipeUp: [],
            swipeDown: [],
            swipeLeft: [],
            swipeRight: [],
            tap: [],
            doubleTap: [],
            hold: [],
            pinchIn: [],
            pinchOut: [],
            rotate: []
        };
        
        // Multi-touch support
        this.touches = new Map();
        this.pinchStartDistance = 0;
        this.pinchStartScale = 1;
        
        this.init();
    }

    /**
     * Initialize controls
     */
    init() {
        if (!this.canvas) {
            console.warn('Canvas element not found for controls');
            return;
        }

        // Touch events
        this.canvas.addEventListener('touchstart', this.touchStartEvent, { passive: false });
        this.canvas.addEventListener('touchmove', this.touchMoveEvent, { passive: false });
        this.canvas.addEventListener('touchend', this.touchEndEvent, { passive: false });
        
        // Mouse events
        this.canvas.addEventListener('mousedown', this.mouseDownEvent);
        this.canvas.addEventListener('mousemove', this.mouseMoveEvent);
        this.canvas.addEventListener('mouseup', this.mouseUpEvent);
        this.canvas.addEventListener('wheel', this.wheelEvent);
        
        // Prevent context menu on canvas
        this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());
        
        // Keyboard events
        window.addEventListener('keydown', this.keyDownEvent);
        window.addEventListener('keyup', this.keyUpEvent);
        
        DebugUtils.log('Controls initialized');
    }

    /**
     * Destroy controls and clean up events
     */
    destroy() {
        // Touch events
        this.canvas.removeEventListener('touchstart', this.touchStartEvent);
        this.canvas.removeEventListener('touchmove', this.touchMoveEvent);
        this.canvas.removeEventListener('touchend', this.touchEndEvent);
        
        // Mouse events
        this.canvas.removeEventListener('mousedown', this.mouseDownEvent);
        this.canvas.removeEventListener('mousemove', this.mouseMoveEvent);
        this.canvas.removeEventListener('mouseup', this.mouseUpEvent);
        this.canvas.removeEventListener('wheel', this.wheelEvent);
        
        // Keyboard events
        window.removeEventListener('keydown', this.keyDownEvent);
        window.removeEventListener('keyup', this.keyUpEvent);
        
        this.touches.clear();
    }

    /**
     * Touch start handler
     */
    onTouchStart(event) {
        if (!this.isEnabled) return;
        
        event.preventDefault();
        
        const touch = event.changedTouches[0];
        const position = this.getCanvasPosition(touch.clientX, touch.clientY);
        
        // Store touch
        this.touches.set(touch.identifier, {
            startTime: Date.now(),
            startPosition: position,
            currentPosition: position
        });
        
        // Update touch start for single touch gestures
        if (this.touches.size === 1) {
            this.touchStart = position;
            this.lastTapPosition = position;
            
            // Check for double tap
            const currentTime = Date.now();
            const distance = MathUtils.distance(position, this.lastTapPosition);
            
            if (currentTime - this.lastTapTime < this.doubleTapThreshold && distance < 20) {
                this.triggerCallbacks('doubleTap', position);
            }
            
            this.lastTapTime = currentTime;
        }
        
        // Initialize pinch gesture
        if (this.touches.size === 2) {
            this.initializePinch();
        }
        
        this.createTouchFeedback(position.x, position.y);
    }

    /**
     * Touch move handler
     */
    onTouchMove(event) {
        if (!this.isEnabled) return;
        
        event.preventDefault();
        
        for (let i = 0; i < event.changedTouches.length; i++) {
            const touch = event.changedTouches[i];
            const touchData = this.touches.get(touch.identifier);
            
            if (touchData) {
                const position = this.getCanvasPosition(touch.clientX, touch.clientY);
                touchData.currentPosition = position;
            }
        }
        
        // Handle pinch gesture
        if (this.touches.size === 2) {
            this.handlePinch();
        }
    }

    /**
     * Touch end handler
     */
    onTouchEnd(event) {
        if (!this.isEnabled) return;
        
        event.preventDefault();
        
        for (let i = 0; i < event.changedTouches.length; i++) {
            const touch = event.changedTouches[i];
            const touchData = this.touches.get(touch.identifier);
            
            if (touchData) {
                this.handleGesture(touchData);
                this.touches.delete(touch.identifier);
            }
        }
    }

    /**
     * Mouse down handler
     */
    onMouseDown(event) {
        if (!this.isEnabled) return;
        
        const position = this.getCanvasPosition(event.clientX, event.clientY);
        this.mouseStart = position;
        
        this.createTouchFeedback(position.x, position.y);
    }

    /**
     * Mouse move handler
     */
    onMouseMove(event) {
        if (!this.isEnabled || !this.mouseStart) return;
        
        // Update mouse position
        this.mouseEnd = this.getCanvasPosition(event.clientX, event.clientY);
    }

    /**
     * Mouse up handler
     */
    onMouseUp(event) {
        if (!this.isEnabled || !this.mouseStart) return;
        
        const position = this.getCanvasPosition(event.clientX, event.clientY);
        this.mouseEnd = position;
        
        this.handleMouseGesture();
        this.mouseStart = null;
        this.mouseEnd = null;
    }

    /**
     * Wheel handler
     */
    onWheel(event) {
        if (!this.isEnabled) return;
        
        event.preventDefault();
        
        if (event.deltaY > 0) {
            this.triggerCallbacks('swipeDown', { x: event.clientX, y: event.clientY });
        } else {
            this.triggerCallbacks('swipeUp', { x: event.clientX, y: event.clientY });
        }
    }

    /**
     * Keyboard down handler
     */
    onKeyDown(event) {
        if (!this.isEnabled) return;
        
        switch (event.code) {
            case 'Space':
            case 'ArrowUp':
                event.preventDefault();
                this.triggerCallbacks('swipeUp', { x: 0, y: 0 });
                break;
            case 'ArrowDown':
                event.preventDefault();
                this.triggerCallbacks('swipeDown', { x: 0, y: 0 });
                break;
            case 'ArrowLeft':
                event.preventDefault();
                this.triggerCallbacks('swipeLeft', { x: 0, y: 0 });
                break;
            case 'ArrowRight':
                event.preventDefault();
                this.triggerCallbacks('swipeRight', { x: 0, y: 0 });
                break;
            case 'Escape':
                event.preventDefault();
                if (this.gameState === 'playing') {
                    this.game.pause();
                } else if (this.gameState === 'paused') {
                    this.game.resume();
                }
                break;
        }
    }

    /**
     * Keyboard up handler
     */
    onKeyUp(event) {
        // Handle key release if needed
    }

    /**
     *
     */
    Handle gesture detection handleGesture(touchData) {
        const deltaX = touchData.currentPosition.x - touchData.startPosition.x;
        const deltaY = touchData.currentPosition.y - touchData.startPosition.y;
        const distance = MathUtils.distance(touchData.startPosition, touchData.currentPosition);
        const duration = Date.now() - touchData.startTime;
        
        // Check if it's a swipe
        if (distance > this.swipeThreshold) {
            const angle = Math.atan2(deltaY, deltaX) * 180 / Math.PI;
            
            if (angle > -45 && angle < 45) {
                // Right swipe
                this.triggerCallbacks('swipeRight', touchData.currentPosition);
            } else if (angle > 135 || angle < -135) {
                // Left swipe
                this.triggerCallbacks('swipeLeft', touchData.currentPosition);
            } else if (angle > -135 && angle < -45) {
                // Down swipe
                this.triggerCallbacks('swipeDown', touchData.currentPosition);
            } else if (angle > 45 && angle < 135) {
                // Up swipe
                this.triggerCallbacks('swipeUp', touchData.currentPosition);
            }
        } else {
            // It's a tap
            this.triggerCallbacks('tap', touchData.currentPosition);
        }
    }

    /**
     * Handle mouse gesture
     */
    handleMouseGesture() {
        if (!this.mouseStart || !this.mouseEnd) return;
        
        const deltaX = this.mouseEnd.x - this.mouseStart.x;
        const deltaY = this.mouseEnd.y - this.mouseStart.y;
        const distance = MathUtils.distance(this.mouseStart, this.mouseEnd);
        
        if (distance > this.swipeThreshold) {
            const angle = Math.atan2(deltaY, deltaX) * 180 / Math.PI;
            
            if (angle > -45 && angle < 45) {
                this.triggerCallbacks('swipeRight', this.mouseEnd);
            } else if (angle > 135 || angle < -135) {
                this.triggerCallbacks('swipeLeft', this.mouseEnd);
            } else if (angle > -135 && angle < -45) {
                this.triggerCallbacks('swipeDown', this.mouseEnd);
            } else if (angle > 45 && angle < 135) {
                this.triggerCallbacks('swipeUp', this.mouseEnd);
            }
        } else {
            this.triggerCallbacks('tap', this.mouseEnd);
        }
    }

    /**
     * Initialize pinch gesture
     */
    initializePinch() {
        if (this.touches.size < 2) return;
        
        const touches = Array.from(this.touches.values());
        const touch1 = touches[0];
        const touch2 = touches[1];
        
        this.pinchStartDistance = MathUtils.distance(
            touch1.startPosition,
            touch2.startPosition
        );
        this.pinchStartScale = 1;
    }

    /**
     * Handle pinch gesture
     */
    handlePinch() {
        if (this.touches.size < 2) return;
        
        const touches = Array.from(this.touches.values());
        const touch1 = touches[0];
        const touch2 = touches[1];
        
        const currentDistance = MathUtils.distance(
            touch1.currentPosition,
            touch2.currentPosition
        );
        
        const scale = currentDistance / this.pinchStartDistance;
        
        if (scale > 1.1) {
            // Pinch out (zoom in)
            this.triggerCallbacks('pinchOut', scale);
        } else if (scale < 0.9) {
            // Pinch in (zoom out)
            this.triggerCallbacks('pinchIn', scale);
        }
    }

    /**
     * Convert client coordinates to canvas coordinates
     */
    getCanvasPosition(clientX, clientY) {
        const rect = this.canvas.getBoundingClientRect();
        return {
            x: clientX - rect.left,
            y: clientY - rect.top
        };
    }

    /**
     * Create visual touch feedback
     */
    createTouchFeedback(x, y) {
        const feedback = document.createElement('div');
        feedback.className = 'touch-feedback';
        feedback.style.left = (x - 25) + 'px';
        feedback.style.top = (y - 25) + 'px';
        feedback.style.width = '50px';
        feedback.style.height = '50px';
        
        document.body.appendChild(feedback);
        
        // Remove after animation
        setTimeout(() => {
            if (feedback.parentNode) {
                feedback.parentNode.removeChild(feedback);
            }
        }, 600);
    }

    /**
     * Trigger registered callbacks
     */
    triggerCallbacks(eventType, data) {
        const callbacks = this.controlCallbacks[eventType];
        if (callbacks) {
            callbacks.forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error('Error in control callback:', error);
                }
            });
        }
        
        DebugUtils.log(`Control event: ${eventType}`, data);
    }

    /**
     * Register event callback
     */
    on(eventType, callback) {
        if (this.controlCallbacks[eventType]) {
            this.controlCallbacks[eventType].push(callback);
        }
    }

    /**
     * Remove event callback
     */
    off(eventType, callback) {
        if (this.controlCallbacks[eventType]) {
            const index = this.controlCallbacks[eventType].indexOf(callback);
            if (index > -1) {
                this.controlCallbacks[eventType].splice(index, 1);
            }
        }
    }

    /**
     * Clear all callbacks for an event type
     */
    clearCallbacks(eventType) {
        if (this.controlCallbacks[eventType]) {
            this.controlCallbacks[eventType] = [];
        }
    }

    /**
     * Set game state
     */
    setGameState(state) {
        this.gameState = state;
        this.isEnabled = state === 'playing';
    }

    /**
     * Enable/disable controls
     */
    setEnabled(enabled) {
        this.isEnabled = enabled;
    }

    /**
     * Set swipe threshold
     */
    setSwipeThreshold(threshold) {
        this.swipeThreshold = threshold;
    }

    /**
     * Set double tap threshold
     */
    setDoubleTapThreshold(threshold) {
        this.doubleTapThreshold = threshold;
    }

    /**
     * Get current touch count
     */
    getTouchCount() {
        return this.touches.size;
    }

    /**
     * Check if touch is active
     */
    isTouchActive() {
        return this.touches.size > 0 || this.mouseStart !== null;
    }

    /**
     * Get debug info
     */
    getDebugInfo() {
        return {
            enabled: this.isEnabled,
            touchCount: this.touches.size,
            swipeThreshold: this.swipeThreshold,
            doubleTapThreshold: this.doubleTapThreshold,
            callbacks: Object.keys(this.controlCallbacks).reduce((acc, key) => {
                acc[key] = this.controlCallbacks[key].length;
                return acc;
            }, {})
        };
    }
}

// Global controls manager instance
window.controlsManager = null;

// Export for use in other modules
window.ControlsManager = ControlsManager;