// Animation system for the game

class AnimationManager {
    constructor() {
        this.animations = [];
        this.playing = true;
        this.time = 0;
        this.speed = 1;
        
        // Predefined animations
        this.animationPresets = {
            // Character animations
            idle: this.createIdleAnimation(),
            run: this.createRunAnimation(),
            jump: this.createJumpAnimation(),
            slide: this.createSlideAnimation(),
            fall: this.createFallAnimation(),
            land: this.createLandAnimation(),
            
            // Object animations
            coinSpin: this.createCoinSpinAnimation(),
            coinCollect: this.createCoinCollectAnimation(),
            powerupGlow: this.createPowerupGlowAnimation(),
            obstacleWarning: this.createObstacleWarningAnimation(),
            trainMove: this.createTrainMoveAnimation(),
            
            // UI animations
            scoreIncrease: this.createScoreIncreaseAnimation(),
            comboFlash: this.createComboFlashAnimation(),
            pause: this.createPauseAnimation(),
            
            // Environment animations
            particleFloat: this.createParticleFloatAnimation(),
            platformGlow: this.createPlatformGlowAnimation(),
            speedLines: this.createSpeedLinesAnimation()
        };
    }

    /**
     * Add animation to the manager
     */
    add(animation) {
        this.animations.push(animation);
        return animation.id;
    }

    /**
     * Remove animation by ID
     */
    remove(id) {
        this.animations = this.animations.filter(anim => anim.id !== id);
    }

    /**
     * Get animation by ID
     */
    get(id) {
        return this.animations.find(anim => anim.id === id);
    }

    /**
     * Update all animations
     */
    update(deltaTime) {
        if (!this.playing) return;

        this.time += deltaTime * this.speed;

        // Update all active animations
        this.animations = this.animations.filter(animation => {
            const isComplete = animation.update(deltaTime * this.speed, this.time);
            if (isComplete && !animation.loop) {
                if (animation.onComplete) animation.onComplete();
                return false;
            }
            return true;
        });
    }

    /**
     * Play predefined animation
     */
    playPreset(presetName, target, options = {}) {
        const preset = this.animationPresets[presetName];
        if (!preset) {
            console.warn(`Animation preset "${presetName}" not found`);
            return null;
        }

        const animation = {
            id: GameUtils.generateId(),
            target: target,
            ...preset,
            loop: options.loop || preset.loop || false,
            speed: options.speed || 1,
            onComplete: options.onComplete,
            startTime: this.time
        };

        return this.add(animation);
    }

    /**
     * Create custom animation
     */
    create(target, properties, duration, easing = 'linear', loop = false, onUpdate = null, onComplete = null) {
        const animation = {
            id: GameUtils.generateId(),
            target: target,
            properties: properties,
            duration: duration,
            easing: easing,
            loop: loop,
            onUpdate: onUpdate,
            onComplete: onComplete,
            startTime: this.time,
            startValues: {},
            endValues: {},
            update: function(deltaTime, currentTime) {
                const elapsed = currentTime - this.startTime;
                const progress = Math.min(elapsed / this.duration, 1);
                
                // Calculate easing
                const easedProgress = AnimationManager.ease(progress, this.easing);
                
                // Update each property
                this.properties.forEach(prop => {
                    const currentValue = AnimationManager.interpolate(
                        this.startValues[prop.key],
                        this.endValues[prop.key],
                        easedProgress
                    );
                    
                    // Apply to target
                    if (prop.type === 'position') {
                        this.target.position[prop.axis] = currentValue;
                    } else if (prop.type === 'rotation') {
                        this.target.rotation[prop.axis] = currentValue;
                    } else if (prop.type === 'scale') {
                        this.target.scale[prop.axis] = currentValue;
                    } else if (prop.type === 'material') {
                        this.target.material[prop.property] = currentValue;
                    }
                });

                if (this.onUpdate) this.onUpdate(easedProgress, currentValue);
                
                return progress >= 1 && !this.loop;
            }
        };

        // Store start and end values
        this.properties.forEach(prop => {
            if (prop.type === 'position') {
                this.startValues[prop.key] = target.position[prop.axis];
            } else if (prop.type === 'rotation') {
                this.startValues[prop.key] = target.rotation[prop.axis];
            } else if (prop.type === 'scale') {
                this.startValues[prop.key] = target.scale[prop.axis];
            } else if (prop.type === 'material') {
                this.startValues[prop.key] = target.material[prop.property];
            }
            
            this.endValues[prop.key] = prop.to;
        });

        return this.add(animation);
    }

    /**
     * Interpolate between two values
     */
    static interpolate(start, end, factor) {
        return start + (end - start) * factor;
    }

    /**
     * Easing functions
     */
    static ease(progress, type = 'linear') {
        const easing = {
            linear: (t) => t,
            easeInQuad: (t) => t * t,
            easeOutQuad: (t) => t * (2 - t),
            easeInOutQuad: (t) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
            easeInCubic: (t) => t * t * t,
            easeOutCubic: (t) => (--t) * t * t + 1,
            easeInOutCubic: (t) => t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,
            easeOutBack: (t) => {
                const c1 = 1.70158;
                const c3 = c1 + 1;
                return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
            },
            easeOutElastic: (t) => {
                const c4 = (2 * Math.PI) / 3;
                return t === 0 ? 0 : t === 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1;
            }
        };

        return easing[type] ? easing[type](progress) : progress;
    }

    /**
     * Animation preset definitions
     */
    createIdleAnimation() {
        return {
            type: 'position',
            properties: [
                { key: 'idle', from: 0, to: 0.02, axis: 'y', type: 'position' }
            ],
            duration: 2,
            loop: true,
            easing: 'easeInOutQuad',
            update: function(deltaTime, currentTime) {
                const idleOffset = Math.sin(currentTime * 2) * 0.02;
                this.target.position.y = 0 + idleOffset;
                return false;
            }
        };
    }

    createRunAnimation() {
        return {
            type: 'complex',
            properties: [
                { key: 'run_cycle', from: 0, to: Math.PI * 2, axis: 'y', type: 'rotation' }
            ],
            duration: 0.6,
            loop: true,
            easing: 'linear',
            update: function(deltaTime, currentTime) {
                const runCycle = Math.sin(currentTime * 10) * 0.1;
                this.target.position.y = Math.abs(runCycle) * 0.5;
                
                // Add slight forward lean
                this.target.rotation.z = runCycle * 0.1;
                
                return false;
            }
        };
    }

    createJumpAnimation() {
        return {
            type: 'position',
            properties: [
                { key: 'jump', from: 0, to: -3, axis: 'y', type: 'position' },
                { key: 'jump_rotation', from: 0, to: 0.2, axis: 'z', type: 'rotation' }
            ],
            duration: 0.8,
            loop: false,
            easing: 'easeOutQuad',
            update: function(deltaTime, currentTime) {
                const elapsed = currentTime - this.startTime;
                const progress = Math.min(elapsed / this.duration, 1);
                
                // Parabolic jump arc
                const jumpHeight = -3 * Math.sin(progress * Math.PI);
                this.target.position.y = Math.max(0, jumpHeight);
                
                // Rotation during jump
                const rotation = 0.2 * Math.sin(progress * Math.PI);
                this.target.rotation.z = rotation;
                
                return progress >= 1;
            }
        };
    }

    createSlideAnimation() {
        return {
            type: 'scale',
            properties: [
                { key: 'slide_scale', from: 1, to: 0.6, axis: 'y', type: 'scale' }
            ],
            duration: 0.3,
            loop: false,
            easing: 'easeOutQuad',
            update: function(deltaTime, currentTime) {
                const elapsed = currentTime - this.startTime;
                const progress = Math.min(elapsed / this.duration, 1);
                
                // Scale down during slide
                const scale = 1 - (1 - 0.6) * progress;
                this.target.scale.y = scale;
                
                return progress >= 1;
            }
        };
    }

    createFallAnimation() {
        return {
            type: 'position',
            properties: [
                { key: 'fall', from: 0, to: -10, axis: 'y', type: 'position' },
                { key: 'fall_rotation', from: 0, to: Math.PI * 2, axis: 'z', type: 'rotation' }
            ],
            duration: 1.5,
            loop: false,
            easing: 'easeInQuad',
            update: function(deltaTime, currentTime) {
                const elapsed = currentTime - this.startTime;
                const progress = Math.min(elapsed / this.duration, 1);
                
                // Falling motion
                this.target.position.y = -progress * 10;
                this.target.rotation.z = progress * Math.PI * 2;
                
                return progress >= 1;
            }
        };
    }

    createLandAnimation() {
        return {
            type: 'position',
            properties: [
                { key: 'land_bounce', from: -1, to: 0, axis: 'y', type: 'position' }
            ],
            duration: 0.4,
            loop: false,
            easing: 'easeOutQuad',
            update: function(deltaTime, currentTime) {
                const elapsed = currentTime - this.startTime;
                const progress = Math.min(elapsed / this.duration, 1);
                
                // Bounce effect on landing
                const bounceHeight = -Math.abs(Math.sin(progress * Math.PI)) * 0.5;
                this.target.position.y = bounceHeight;
                
                return progress >= 1;
            }
        };
    }

    createCoinSpinAnimation() {
        return {
            type: 'rotation',
            properties: [
                { key: 'spin', from: 0, to: Math.PI * 2, axis: 'y', type: 'rotation' }
            ],
            duration: 1,
            loop: true,
            easing: 'linear',
            update: function(deltaTime, currentTime) {
                // Continuous spinning
                this.target.rotation.y = currentTime * 2;
                return false;
            }
        };
    }

    createCoinCollectAnimation() {
        return {
            type: 'complex',
            duration: 0.6,
            loop: false,
            easing: 'easeOutBack',
            update: function(deltaTime, currentTime) {
                const elapsed = currentTime - this.startTime;
                const progress = Math.min(elapsed / this.duration, 1);
                
                // Scale up and fade out
                const scale = 1 + progress * 0.5;
                this.target.scale.set(scale, scale, scale);
                
                // Fade out (if material has opacity)
                if (this.target.material && this.target.material.opacity !== undefined) {
                    this.target.material.opacity = 1 - progress;
                }
                
                return progress >= 1;
            }
        };
    }

    createPowerupGlowAnimation() {
        return {
            type: 'material',
            properties: [
                { key: 'glow', from: 0.5, to: 1.0, property: 'emissiveIntensity', type: 'material' }
            ],
            duration: 1.5,
            loop: true,
            easing: 'easeInOutQuad',
            update: function(deltaTime, currentTime) {
                // Pulsing glow effect
                const glow = 0.5 + Math.sin(currentTime * 3) * 0.3;
                if (this.target.material && this.target.material.emissiveIntensity !== undefined) {
                    this.target.material.emissiveIntensity = glow;
                }
                return false;
            }
        };
    }

    createObstacleWarningAnimation() {
        return {
            type: 'material',
            properties: [
                { key: 'warning', from: 0.3, to: 1.0, property: 'emissiveIntensity', type: 'material' }
            ],
            duration: 0.5,
            loop: true,
            easing: 'linear',
            update: function(deltaTime, currentTime) {
                // Warning flash
                const flash = Math.sin(currentTime * 8) * 0.5 + 0.5;
                if (this.target.material && this.target.material.emissiveIntensity !== undefined) {
                    this.target.material.emissiveIntensity = 0.3 + flash * 0.7;
                }
                return false;
            }
        };
    }

    createTrainMoveAnimation() {
        return {
            type: 'position',
            properties: [
                { key: 'train_move', from: -20, to: 20, axis: 'x', type: 'position' }
            ],
            duration: 4,
            loop: true,
            easing: 'linear',
            update: function(deltaTime, currentTime) {
                const elapsed = (currentTime - this.startTime) % 4;
                const progress = elapsed / 4;
                
                // Continuous movement across screen
                this.target.position.x = -20 + (progress * 40);
                return false;
            }
        };
    }

    createScoreIncreaseAnimation() {
        return {
            type: 'complex',
            duration: 0.8,
            loop: false,
            easing: 'easeOutBack',
            update: function(deltaTime, currentTime) {
                const elapsed = currentTime - this.startTime;
                const progress = Math.min(elapsed / this.duration, 1);
                
                // Scale bounce effect
                const scale = 1 + Math.sin(progress * Math.PI) * 0.2;
                this.target.style.transform = `scale(${scale})`;
                
                return progress >= 1;
            }
        };
    }

    createComboFlashAnimation() {
        return {
            type: 'complex',
            duration: 1.5,
            loop: false,
            easing: 'easeOutQuad',
            update: function(deltaTime, currentTime) {
                const elapsed = currentTime - this.startTime;
                const progress = Math.min(elapsed / this.duration, 1);
                
                // Fade out effect
                this.target.style.opacity = 1 - progress;
                this.target.style.transform = `translateY(-${progress * 50}px)`;
                
                return progress >= 1;
            }
        };
    }

    createPauseAnimation() {
        return {
            type: 'complex',
            duration: 0.3,
            loop: false,
            easing: 'easeOutQuad',
            update: function(deltaTime, currentTime) {
                // Subtle scale effect for pause button
                const elapsed = currentTime - this.startTime;
                const progress = Math.min(elapsed / this.duration, 1);
                
                const scale = 1 + Math.sin(progress * Math.PI) * 0.05;
                this.target.style.transform = `scale(${scale})`;
                
                return progress >= 1;
            }
        };
    }

    createParticleFloatAnimation() {
        return {
            type: 'position',
            properties: [
                { key: 'float', from: 0, to: -5, axis: 'y', type: 'position' }
            ],
            duration: 3,
            loop: false,
            easing: 'easeOutQuad',
            update: function(deltaTime, currentTime) {
                const elapsed = currentTime - this.startTime;
                const progress = Math.min(elapsed / this.duration, 1);
                
                // Float upward and fade
                this.target.position.y = progress * -5;
                this.target.material.opacity = 1 - progress;
                
                return progress >= 1;
            }
        };
    }

    createPlatformGlowAnimation() {
        return {
            type: 'material',
            properties: [
                { key: 'platform_glow', from: 0.1, to: 0.5, property: 'emissiveIntensity', type: 'material' }
            ],
            duration: 2,
            loop: true,
            easing: 'easeInOutQuad',
            update: function(deltaTime, currentTime) {
                // Breathing glow effect
                const glow = 0.1 + Math.sin(currentTime * 2) * 0.2;
                if (this.target.material && this.target.material.emissiveIntensity !== undefined) {
                    this.target.material.emissiveIntensity = glow;
                }
                return false;
            }
        };
    }

    createSpeedLinesAnimation() {
        return {
            type: 'complex',
            properties: [
                { key: 'speed_lines', from: 0, to: 1, axis: 'x', type: 'position' }
            ],
            duration: 0.5,
            loop: true,
            easing: 'linear',
            update: function(deltaTime, currentTime) {
                // Move lines across screen
                const speed = currentTime * 20;
                this.target.children.forEach((line, index) => {
                    line.position.x = (speed + index * 50) % (window.innerWidth + 100);
                    line.position.x -= window.innerWidth / 2;
                });
                return false;
            }
        };
    }

    /**
     * Stop all animations
     */
    stopAll() {
        this.animations = [];
    }

    /**
     * Pause/resume all animations
     */
    setPlaying(playing) {
        this.playing = playing;
    }

    /**
     * Set animation speed
     */
    setSpeed(speed) {
        this.speed = speed;
    }

    /**
     * Get animation count
     */
    getCount() {
        return this.animations.length;
    }

    /**
     * Clear completed animations
     */
    cleanup() {
        this.animations = this.animations.filter(anim => !anim.completed);
    }
}

// Global animation manager instance
window.animationManager = new AnimationManager();

// Export for use in other modules
window.AnimationManager = AnimationManager;