// Utility functions and helpers for the game

/**
 * Random number generator
 */
class Random {
    /**
     * Generate a random float between min and max
     */
    static float(min = 0, max = 1) {
        return Math.random() * (max - min) + min;
    }

    /**
     * Generate a random integer between min and max (inclusive)
     */
    static int(min = 0, max = 1) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    /**
     * Generate a random boolean
     */
    static boolean() {
        return Math.random() < 0.5;
    }

    /**
     * Pick a random element from an array
     */
    static pick(array) {
        return array[Math.floor(Math.random() * array.length)];
    }

    /**
     * Generate a random color
     */
    static color() {
        return new THREE.Color(
            Math.random(),
            Math.random(),
            Math.random()
        );
    }
}

/**
 * Math utilities
 */
class MathUtils {
    /**
     * Clamp a value between min and max
     */
    static clamp(value, min, max) {
        return Math.min(Math.max(value, min), max);
    }

    /**
     * Linear interpolation
     */
    static lerp(start, end, factor) {
        return start + (end - start) * factor;
    }

    /**
     * Smooth step interpolation
     */
    static smoothstep(edge0, edge1, x) {
        const t = MathUtils.clamp((x - edge0) / (edge1 - edge0), 0, 1);
        return t * t * (3 - 2 * t);
    }

    /**
     * Convert degrees to radians
     */
    static degToRad(degrees) {
        return degrees * Math.PI / 180;
    }

    /**
     * Convert radians to degrees
     */
    static radToDeg(radians) {
        return radians * 180 / Math.PI;
    }

    /**
     * Get distance between two points
     */
    static distance(pos1, pos2) {
        const dx = pos1.x - pos2.x;
        const dy = pos1.y - pos2.y;
        const dz = pos1.z - pos2.z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /**
     * Get angle between two points
     */
    static angle(from, to) {
        return Math.atan2(to.z - from.z, to.x - from.x);
    }
}

/**
 * String utilities
 */
class StringUtils {
    /**
     * Format number with commas
     */
    static formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    /**
     * Format time in MM:SS format
     */
    static formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }

    /**
     * Capitalize first letter
     */
    static capitalize(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
}

/**
 * Array utilities
 */
class ArrayUtils {
    /**
     * Shuffle array in place
     */
    static shuffle(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    /**
     * Remove element from array by value
     */
    static remove(array, element) {
        const index = array.indexOf(element);
        if (index > -1) {
            array.splice(index, 1);
        }
        return array;
    }

    /**
     * Get random subset of array
     */
    static sample(array, size) {
        const shuffled = [...array];
        ArrayUtils.shuffle(shuffled);
        return shuffled.slice(0, size);
    }

    /**
     * Group array into chunks
     */
    static chunk(array, size) {
        const chunks = [];
        for (let i = 0; i < array.length; i += size) {
            chunks.push(array.slice(i, i + size));
        }
        return chunks;
    }
}

/**
 * Object utilities
 */
class ObjectUtils {
    /**
     * Deep clone object
     */
    static clone(obj) {
        if (obj === null || typeof obj !== 'object') return obj;
        if (obj instanceof Date) return new Date(obj.getTime());
        if (obj instanceof Array) return obj.map(item => ObjectUtils.clone(item));
        if (typeof obj === 'object') {
            const clonedObj = {};
            for (const key in obj) {
                if (obj.hasOwnProperty(key)) {
                    clonedObj[key] = ObjectUtils.clone(obj[key]);
                }
            }
            return clonedObj;
        }
    }

    /**
     * Merge objects deeply
     */
    static merge(target, ...sources) {
        if (!sources.length) return target;
        const source = sources.shift();

        if (ObjectUtils.isObject(target) && ObjectUtils.isObject(source)) {
            for (const key in source) {
                if (ObjectUtils.isObject(source[key])) {
                    if (!target[key]) Object.assign(target, { [key]: {} });
                    ObjectUtils.merge(target[key], source[key]);
                } else {
                    Object.assign(target, { [key]: source[key] });
                }
            }
        }

        return ObjectUtils.merge(target, ...sources);
    }

    /**
     * Check if value is object
     */
    static isObject(item) {
        return item && typeof item === 'object' && !Array.isArray(item);
    }

    /**
     * Get nested property value
     */
    static get(obj, path, defaultValue = undefined) {
        const keys = path.split('.');
        let result = obj;

        for (const key of keys) {
            if (result === null || result === undefined || !(key in result)) {
                return defaultValue;
            }
            result = result[key];
        }

        return result;
    }

    /**
     * Set nested property value
     */
    static set(obj, path, value) {
        const keys = path.split('.');
        let current = obj;

        for (let i = 0; i < keys.length - 1; i++) {
            const key = keys[i];
            if (!(key in current) || typeof current[key] !== 'object') {
                current[key] = {};
            }
            current = current[key];
        }

        current[keys[keys.length - 1]] = value;
        return obj;
    }
}

/**
 * Performance utilities
 */
class PerformanceUtils {
    /**
     * Throttle function calls
     */
    static throttle(func, wait) {
        let timeout;
        let previous = 0;

        return function executedFunction(...args) {
            const now = Date.now();
            const remaining = wait - (now - previous);

            if (remaining <= 0 || remaining > wait) {
                if (timeout) {
                    clearTimeout(timeout);
                    timeout = null;
                }
                previous = now;
                func.apply(this, args);
            } else if (!timeout) {
                timeout = setTimeout(() => {
                    previous = Date.now();
                    timeout = null;
                    func.apply(this, args);
                }, remaining);
            }
        };
    }

    /**
     * Debounce function calls
     */
    static debounce(func, wait, immediate = false) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                timeout = null;
                if (!immediate) func.apply(this, args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(this, args);
        };
    }

    /**
     * Frame rate independent interpolation
     */
    static lerpAlpha(speed, deltaTime) {
        return 1 - Math.pow(1 - speed, deltaTime * 60);
    }
}

/**
 * Storage utilities
 */
class StorageUtils {
    /**
     * Save data to localStorage
     */
    static save(key, data) {
        try {
            localStorage.setItem(key, JSON.stringify(data));
            return true;
        } catch (error) {
            console.warn('Failed to save to localStorage:', error);
            return false;
        }
    }

    /**
     * Load data from localStorage
     */
    static load(key, defaultValue = null) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (error) {
            console.warn('Failed to load from localStorage:', error);
            return defaultValue;
        }
    }

    /**
     * Remove data from localStorage
     */
    static remove(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (error) {
            console.warn('Failed to remove from localStorage:', error);
            return false;
        }
    }

    /**
     * Clear all localStorage data
     */
    static clear() {
        try {
            localStorage.clear();
            return true;
        } catch (error) {
            console.warn('Failed to clear localStorage:', error);
            return false;
        }
    }
}

/**
 * Vector utilities for 3D math
 */
class Vector3Utils {
    /**
     * Create vector from object
     */
    static fromObject(obj) {
        return new THREE.Vector3(obj.x || 0, obj.y || 0, obj.z || 0);
    }

    /**
     * Convert vector to object
     */
    static toObject(vector) {
        return { x: vector.x, y: vector.y, z: vector.z };
    }

    /**
     * Calculate vector length
     */
    static length(vector) {
        return Math.sqrt(vector.x * vector.x + vector.y * vector.y + vector.z * vector.z);
    }

    /**
     * Normalize vector
     */
    static normalize(vector) {
        const length = Vector3Utils.length(vector);
        if (length > 0) {
            return new THREE.Vector3(
                vector.x / length,
                vector.y / length,
                vector.z / length
            );
        }
        return new THREE.Vector3(0, 0, 0);
    }

    /**
     * Calculate dot product
     */
    static dot(v1, v2) {
        return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
    }

    /**
     * Calculate cross product
     */
    static cross(v1, v2) {
        return new THREE.Vector3(
            v1.y * v2.z - v1.z * v2.y,
            v1.z * v2.x - v1.x * v2.z,
            v1.x * v2.y - v1.y * v2.x
        );
    }

    /**
     * Distance between two vectors
     */
    static distance(v1, v2) {
        return Math.sqrt(
            Math.pow(v1.x - v2.x, 2) +
            Math.pow(v1.y - v2.y, 2) +
            Math.pow(v1.z - v2.z, 2)
        );
    }

    /**
     * Linear interpolation between two vectors
     */
    static lerp(v1, v2, t) {
        return new THREE.Vector3(
            MathUtils.lerp(v1.x, v2.x, t),
            MathUtils.lerp(v1.y, v2.y, t),
            MathUtils.lerp(v1.z, v2.z, t)
        );
    }
}

/**
 * Debug utilities
 */
class DebugUtils {
    static enabled = false;

    /**
     * Enable/disable debug mode
     */
    static setEnabled(enabled) {
        DebugUtils.enabled = enabled;
    }

    /**
     * Log debug message
     */
    static log(message, ...args) {
        if (DebugUtils.enabled) {
            console.log(`[Game Debug] ${message}`, ...args);
        }
    }

    /**
     * Log warning
     */
    static warn(message, ...args) {
        if (DebugUtils.enabled) {
            console.warn(`[Game Warning] ${message}`, ...args);
        }
    }

    /**
     * Log error
     */
    static error(message, ...args) {
        if (DebugUtils.enabled) {
            console.error(`[Game Error] ${message}`, ...args);
        }
    }

    /**
     * Create debug helper for THREE.js objects
     */
    static createHelper(object, color = 0x00ff00) {
        if (!DebugUtils.enabled) return null;
        
        if (object instanceof THREE.Object3D) {
            const helper = new THREE.BoxHelper(object, color);
            helper.visible = true;
            return helper;
        }
        return null;
    }

    /**
     * Performance monitoring
     */
    static monitor(name, fn) {
        if (!DebugUtils.enabled) return fn();

        const start = performance.now();
        const result = fn();
        const end = performance.now();
        console.log(`[Performance] ${name}: ${end - start}ms`);
        return result;
    }
}

/**
 * Game-specific utilities
 */
class GameUtils {
    /**
     * Calculate score based on distance and speed
     */
    static calculateScore(distance, speed, multiplier = 1) {
        return Math.floor(distance * 0.1 * speed * multiplier);
    }

    /**
     * Calculate combo multiplier based on consecutive actions
     */
    static calculateCombo(comboCount) {
        return Math.min(1 + (comboCount * 0.1), 5);
    }

    /**
     * Generate unique ID
     */
    static generateId() {
        return Math.random().toString(36).substr(2, 9);
    }

    /**
     * Check if object is on screen
     */
    static isOnScreen(object, camera, canvas) {
        const vector = object.position.clone().project(camera);
        const x = (vector.x + 1) / 2 * canvas.width;
        const y = (-vector.y + 1) / 2 * canvas.height;
        
        return x >= 0 && x <= canvas.width && y >= 0 && y <= canvas.height;
    }

    /**
     * Convert screen coordinates to world coordinates
     */
    static screenToWorld(screenX, screenY, camera, canvas) {
        const vector = new THREE.Vector3(
            (screenX / canvas.width) * 2 - 1,
            -(screenY / canvas.height) * 2 + 1,
            0.5
        );
        
        vector.unproject(camera);
        return vector;
    }
}

// Export utilities for use in other modules
window.Random = Random;
window.MathUtils = MathUtils;
window.StringUtils = StringUtils;
window.ArrayUtils = ArrayUtils;
window.ObjectUtils = ObjectUtils;
window.PerformanceUtils = PerformanceUtils;
window.StorageUtils = StorageUtils;
window.Vector3Utils = Vector3Utils;
window.DebugUtils = DebugUtils;
window.GameUtils = GameUtils;