# Subway Surfers 3D 🚀

Modern web teknolojileri kullanarak geliştirilmiş 3D sonsuz koşucu oyunu. Three.js ve Cannon.js ile oluşturulmuş, tam işlevsel ve gerçekçi bir oyun deneyimi.

## 🎮 Özellikler

### ✨ Oyun Mekanikleri
- **3D Sonsuz Koşu**: Gerçekçi 3D ortamda sonsuz koşu deneyimi
- **Karakter Hareketleri**: Koşma, zıplama, eğilme, sağa/sola hareket
- **Engeller ve Challenge'lar**: Çeşitli engeller ve zorluklar
- **Toplanabilir Objeler**: Paralar, güçlendirmeler ve değerli objeler
- **Skor Sistemi**: Distance, coin ve combo tabanlı puanlama
- **Multiplicator Sistemi**: Combo artışıyla çarpan sistemi

### 🎯 Güçlendirmeler (Power-ups)
- **🧲 Manyetik**: Paraları kendine çeker
- **🚀 Jetpack**: Otomatik zıplama özelliği
- **🛡️ Kalkan**: Geçici olarak hasar almaz
- **💨 Hızlandırma**: Geçici hız artışı
- **⭐ Yenilmezlik**: Kısa süreli yenilmezlik

### 🎨 Görsel Özellikler
- **Gerçekçi 3D Ortam**: Detaylı istasyon ve tren rayları
- **Dinamik Aydınlatma**: Gün ışığı ve yapay aydınlatma
- **Parçacık Efektleri**: Toz, buhar ve diğer atmosferik efektler
- **Animasyonlar**: Akıcı karakter ve obje animasyonları
- **Optimize Grafikler**: Kalite ayarlarına göre render optimizasyonu

### 📱 Kontroller
- **Touch Gestures**: Dokunmatik ekranlar için kaydırma hareketleri
  - Yukarı kaydır → Zıpla
  - Aşağı kaydır → Eğil
  - Sola kaydır → Sola hareket
  - Sağa kaydır → Sağa hareket
- **Klavye Kontrolleri**: Alternatif kontrol seçenekleri
  - Space/↑ → Zıpla
  - ↓ → Eğil
  - ← → Sola hareket
  - → → Sağa hareket
  - Esc → Duraklat/Devam et

### 🏆 Sistem Özellikleri
- **Başarım Sistemi**: 6 farklı başarım
- **Yüksek Skor**: LocalStorage ile kayıt
- **Ayarlar**: Ses seviyesi, grafik kalitesi
- **Responsive Tasarım**: Mobil ve masaüstü uyumlu
- **Performans Optimizasyonu**: FPS kontrolü ve LOD sistemi

## 🛠️ Teknolojiler

### Frontend
- **HTML5**: Temel yapı ve Canvas
- **CSS3**: Modern styling ve animasyonlar
- **JavaScript ES6+**: Oyun mantığı ve interaktivite

### 3D Grafik ve Fizik
- **Three.js r158**: 3D grafik rendering
- **Cannon.js**: Fizik motoru
- **WebGL**: Hardware acceleration

### Yardımcı Kütüphaneler
- **GSAP**: Animasyon yönetimi
- **Popper.js**: UI positioning
- **Google Fonts (Poppins)**: Typography

## 🚀 Kurulum ve Çalıştırma

### Gereksinimler
- Modern web tarayıcı (Chrome 70+, Firefox 65+, Safari 12+)
- WebGL desteği
- JavaScript etkin

### Adımlar
1. **Projeyi indirin**
   ```bash
   # Git ile
   git clone <repository-url>
   cd subway-surfers-3d
   ```

2. **Bağımlılıkları yükleyin** (opsiyonel)
   ```bash
   npm install
   ```

3. **Yerel sunucu başlatın**
   ```bash
   # npm serve ile (önerilen)
   npm run start
   
   # Python ile
   python -m http.server 3000
   
   # Node.js serve ile
   npx serve -s . -l 3000
   ```

4. **Tarayıcıda açın**
   - `http://localhost:3000` adresine gidin

### Production Build
```bash
# Minified build oluşturma
npm run build

# Static dosyaları deploy etme
npm run deploy
```

## 🎯 Oyun Rehberi

### Temel Kontroller
1. **Oyunu başlat**: Ana menüde "OYNA" butonuna tıklayın
2. **Hareket et**: Kaydırma hareketleriyle karakteri yönlendirin
3. **Engellerden kaçın**: Çarpışmalardan kaçının
4. **Objeleri toplayın**: Paraları ve güçlendirmeleri toplayın
5. **Skoru maksimize edin**: Combo yaparak çarpan artırın

### İpuçları
- **Combo sistemi**: Kesintisiz aksiyon combosu artırır
- **Power-up'ları akıllıca kullanın**: Doğru zamanda aktivasyon
- **Çevreyi izleyin**: Gelen engelleri önceden görün
- **Hız artışı**: Oyun ilerledikçe hızlanır

### Başarımlar
- **İlk Koşu**: İlk oyunu tamamlayın
- **Para Toplayıcı**: 100 para toplayın
- **Hız Şeytanı**: Maksimum hıza ulaşın
- **Combo Ustası**: 10 combo yapın
- **Hayatta Kalan**: 5000 puan alın
- **Güç Kullanıcısı**: Tüm power-up'ları deneyin

## 📁 Proje Yapısı

```
subway-surfers-3d/
├── index.html              # Ana HTML dosyası
├── package.json            # Bağımlılıklar
├── src/
│   ├── main.js            # Giriş noktası
│   ├── utils/
│   │   ├── helpers.js     # Yardımcı fonksiyonlar
│   │   ├── animations.js  # Animasyon sistemi
│   │   └── controls.js    # Kontrol yönetimi
│   └── game/
│       ├── Game.js        # Ana oyun sınıfı
│       ├── Player.js      # Karakter kontrolleri
│       ├── Environment.js # 3D ortam
│       ├── TrackManager.js # Sonsuz track
│       ├── Obstacles.js   # Engeller
│       ├── Collectibles.js # Toplanabilirler
│       ├── Physics.js     # Fizik motoru
│       └── UI.js          # Kullanıcı arayüzü
└── styles/
    ├── main.css          # Ana stiller
    └── components.css    # Bileşen stilleri
```

## ⚙️ Ayarlar

### Grafik Kalitesi
- **Düşük**: Mobil cihazlar için optimize edilmiş
- **Orta**: Dengeli performans ve kalite
- **Yüksek**: En iyi görsel deneyim

### Ses Ayarları
- Ses seviyesi 0-100 arası ayarlanabilir
- Mute seçeneği mevcut

### Performans
- FPS limiti: 30/60 FPS seçeneği
- Particle efekti yoğunluğu
- Shadow quality ayarları

## 🐛 Debugging

### Konsol Komutları
```javascript
console.game.info()        // Oyun bilgileri
console.game.performance() // Performans metrikleri
console.game.components()  // Bileşen durumu
console.game.debug(true)   // Debug modunu aç
```

### Hata Ayıklama
- F12 ile Developer Tools açın
- Console sekmesinde hata mesajlarını kontrol edin
- Network sekmesinde asset yüklemelerini izleyin
- Application sekmesinde LocalStorage'ı kontrol edin

## 📈 Performance Optimizasyonları

### Otomatik Optimizasyonlar
- **LOD (Level of Detail)**: Uzak objeler düşük detay
- **Frustum Culling**: Görüş alanı dışı objeler gizli
- **Object Pooling**: Obje yeniden kullanımı
- **Texture Compression**: Optimize edilmiş dokular

### Manuel Optimizasyonlar
- Grafik kalitesini düşürün
- Particle efektlerini azaltın
- FPS limitini 30'a düşürün
- Browser cache'ini temizleyin

## 🔧 Geliştirme

### Yeni Özellik Ekleme
1. İlgili modülü genişletin
2. UI güncellemelerini ekleyin
3. Test edin ve optimize edin

### Örnek: Yeni Power-up
```javascript
// Collectibles.js'e ekle
createNewPowerup(position, options) {
    // Power-up oluşturma mantığı
}

// UI.js'e ekle
showNewPowerupActivation() {
    // UI bildirimi
}
```

## 📝 Lisans

MIT License - Detaylar için LICENSE dosyasını inceleyin.

## 🤝 Katkıda Bulunma

1. Fork yapın
2. Feature branch oluşturun (`git checkout -b feature/AmazingFeature`)
3. Değişikliklerinizi commit edin (`git commit -m 'Add AmazingFeature'`)
4. Branch'inizi push edin (`git push origin feature/AmazingFeature`)
5. Pull Request açın

## 📞 Destek

Sorularınız için:
- Issues bölümünü kullanın
- Documentation'u inceleyin
- Community forum'a katılın

## 🎮 Demo

Canlı demo: [Game URL]

---

**Not**: Bu proje eğitim amaçlı geliştirilmiştir. Ticari kullanım için lisans alınması gerekebilir.

Made with ❤️ by MiniMax Agent